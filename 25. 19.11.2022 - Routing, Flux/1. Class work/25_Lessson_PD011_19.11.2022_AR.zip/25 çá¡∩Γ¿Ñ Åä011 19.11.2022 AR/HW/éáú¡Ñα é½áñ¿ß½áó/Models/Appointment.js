class Appointment {
    constructor(id, date, doctorSnp, patientSnp, speciality, price, percentage, roomNum, incomeTax = 13) {
        this.id = id;
        this.date = date;
        this.doctorSnp = doctorSnp;
        this.patientSnp = patientSnp;
        this.speciality = speciality;
        this.price = price;
        this.percentage = percentage;
        this.roomNum = roomNum;
        this.incomeTax = incomeTax;
    }

    //Вычисление зарплаты доктора
    countSalary() {
        if (this.price < 0 || this.percentage > 100)
            return;
        let salary = this.price * (this.percentage / 100);
        return salary - salary * this.incomeTax/100;
    }

    //Вывод в строку таблицы
    toTableRow() {
        console.log(`Date: ${typeof(this.date)}`)
        return <tr key={this.id}>
            <td>{this.id}</td>
            <td>{this.date}</td>
            <td>{this.doctorSnp}</td>
            <td>{this.patientSnp}</td>
            <td>{this.speciality}</td>
            <td>{this.price}</td>
            <td className={'text-center'}>
                <Link className="btn btn-outline-success" to={`/componentOutlet/details/${this.id}`}>Подробнее</Link>
            </td>
        </tr>
    }

    assign(appointment) {
        Object.assign(this, appointment);
        return this;
    }

    //Чтение из локального хранилища
    static loadFromLocalStore(key) {
        let parsed = JSON.parse(localStorage.getItem(key));
        return Array(parsed.length).fill(0).map((el, i) => new Appointment().assign(parsed[i]))
    }
}