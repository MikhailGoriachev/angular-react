// Компонент 3 - Определить является ли простым числом число a.
// Пропсы: начальное значение a.
// Стейт: a, результат проверки. По клику на кнопку меняем стейт
function Component3(props) {

    //Задание состояний
    const [states, setStates] = React.useState({salary: NaN, price: 1000, isValidPrice: undefined});

    //Ref для полей ввода
    const priceRef = React.useRef(null);

    //Валдация
    function isValid(value) {
        return value > 100 && value < 1_000_000;
    }

    //Submit обработчик
    function submitHandler(e) {
        e.preventDefault();

        let isValidFlag = states.isValidPrice;

        if (!isValidFlag && isValidFlag !== undefined)
            return;

        let priceVal = +priceRef.current.value;

        setStates({
            ...states,
            price: priceVal,
            salary: countSalary(priceVal, props.percentage)
        });

    }

    function onChangePrice(e) {
        let priceVal = Number(e.target.value);

        //Изменение state
        setStates({...states, price: priceVal, salary: NaN, isValidPrice: isValid(priceVal)})
    }

    //Формирование разметки
    return (
        <div className="mx-auto w-75 mt-4 py-4 mb-5 shadow-sm rounded border bg-light ">
            <b><p className="text-center text-Big">Компонент 3</p></b>

            <ul className="list-group list-group-flush mb-3">
                <li className="list-group-item">ФИО врача: <b>{props.doctorSnp}</b></li>
                <li className="list-group-item">Специальность врача: <b>{props.specialization}</b></li>
                <li className="list-group-item">% отчислений врачу: <b>{props.percentage}</b></li>
            </ul>

            <form onSubmit={submitHandler}>
                <div className={"row"}>
                    <div className={"col-8 ms-3"}>
                        <label className={"mb-2"} htmlFor={"input_a"}>Введите значение</label>

                        <input type="number" ref={priceRef} id="input_a" step="any"
                               className={`form-control col-3 ${states.isValidPrice !== undefined ? (states.isValidPrice ? "is-valid" : "is-invalid") : ""}`}
                               value={states.price}
                               onChange={onChangePrice}
                        />
                    </div>
                </div>
                <div className={"my-3 ms-3"}>
                    <p>
                        Заработная плата врача: <b>{!isNaN(states.salary) ? states.salary.toFixed(2) : "---"}</b>
                    </p>
                </div>
                <div className={"my-2 ms-3"}>
                    <input className={"btn btn-outline-success"} type="submit" value="Вычислить"/>
                </div>
            </form>
        </div>)


} //Component3