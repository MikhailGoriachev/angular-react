/*
//Компонент 1 - .Отображение данных о банковском переводе: фамилия и инициалы отправителя, номер телефона отправителя,
// фамилия и инициалы получателя, номер телефона получателя, дата и время перевода
// (момент создания компонента), банковские отчисления за операцию перевода (1,2% от суммы перевода).
// Вводить сумму перевода (от 1 до 50000 руб.), вычислять отчисления банку.
// Остальные параметры задавать атрибутами компонента.
function Component1(props) {

    //Задание состояний
    const [states, setStates] = React.useState({summ: 1, assessments: NaN, isValid: undefined});

    //Ref для полей ввода
    const summRef = React.useRef(null);

    //Валдиация
    function isValid(value) {
        return value >= 1 && value <= 50000;
    }

    //Submit обработчик
    function submitHandler(e) {
        e.preventDefault();

        let isValidFlag = states.isValid;

        if (!isValidFlag && isValidFlag !== undefined)
            return;

        let summVal = +summRef.current.value;

        //Изменение состояний
        setStates({
            ...states,
            summ: summVal,
            assessments: getAssessments(props.percentage, summVal)
        });

    }

    function onChangeSumm(e) {
        let summVal = Number(e.target.value);

        //Изменение state
        /!*this.setState({summ: summVal, assessments: NaN,isValid: this.isValid(summVal)})*!/

        //Изменение состояний
        setStates({
            ...states,
            summ: summVal,
            assessments: NaN,
            isValid: isValid(summVal)
        });
    }

    //Формирование разметки
    return (
        <div className="ms-auto mt-4 py-4 mb-5 shadow-sm rounded border bg-light ">
            <b><p className="text-center text-Big">Компонент 1</p></b>
            <ul className="list-group list-group-flush mb-3">
                <li className="list-group-item">ФИО отправителя: <b>{props.senderSnp}</b></li>
                <li className="list-group-item">Номер телефона отправителя: <b>{props.senderPhone}</b></li>
                <li className="list-group-item">ФИО получателя: <b>{props.recipientSnp}</b></li>
                <li className="list-group-item">Номер телефона получателя: <b>{props.recipientPhone}</b></li>
                <li className="list-group-item">Дата и время перевода: <b>{props.transactionTime}</b></li>
                <li className="list-group-item">% отчислений банку: <b>{props.percentage}</b></li>
            </ul>

            <form className={" mx-auto"} onSubmit={submitHandler}>
                <div className={"row"}>
                    <div className={"col-8"}>
                        <label htmlFor={"input_a"} className={"mb-2"}>Введите сумму</label>

                        <input type="number" ref={summRef} id={"input_a"} step="any"
                               className={`form-control ${states.isValid !== undefined ? (states.isValid ? "is-valid" : "is-invalid") : ""}`}
                               value={states.summ}
                               onChange={onChangeSumm}
                        />
                    </div>
                </div>
                <div className={"my-3"}>
                    <p>
                        Сумма отчислений
                        банку: <b>{!isNaN(states.assessments) ? states.assessments.toFixed(3) : "---"}</b>
                    </p>
                </div>
                <div className={"my-2"}>
                    <input className={"btn btn-outline-success"} type="submit" value="Вычислить"/>
                </div>
            </form>
        </div>
    )


} //Component1

// Компонент 2 - Требуется вычислять нормальную массу тела человека по его росту (по формуле Лоренца):
// Масса (кг) = (Рост (см) - 100) - (Рост (см) - 150)/2.
// Вводите исходные данные в форму, выполняйте валидацию данных.
function Component2(props) {

    //Задание состояний
    const [states, setStates] = React.useState({mass: NaN, height: props.height, isValid: undefined});

    //Ref для полей ввода
    const heightRef = React.createRef();

    //Валидация
    function isValid(height) {
        return height > 100 && height < 231;
    }

    const onChangedH = (e) => {
        let inputVal = +e.target.value;

        //Изменение state через spread
        setStates({
            ...states,
            height: inputVal,
            isValid: isValid(inputVal),
            mass: NaN
        });
    }

    //Submit обработчик
    const submitHandler = (e) => {
        e.preventDefault();

        let isValidFlag = states.isValid;

        if (!isValidFlag && isValidFlag !== undefined)
            return;

        //Получение значений
        let heightVal = +heightRef.current.value;


        setStates({
            ...states,
            height: heightVal,
            mass: getMassFromHeight(heightVal)
        });

    }

    //Формирование разметки
    return (
        <div className="ms-auto mt-4 py-4 mb-5 shadow-sm rounded border bg-light ">
            <b><p className="text-center text-Big">Компонент 2</p></b>

            <form className={"mt-auto"} onSubmit={submitHandler}>
                <div className={"row"}>
                    <div className={"col-9"}>
                        <label className={"mb-2"} htmlFor={"input_a"}>Введите рост</label>

                        <input type="number" ref={heightRef} id="input_height"
                               className={`form-control ${states.isValid !== undefined ? (states.isValid ? "is-valid" : "is-invalid") : ""}`}
                               value={states.height}
                               onChange={onChangedH}
                        />
                    </div>
                </div>
                <div className={"my-3"}>
                    <p>
                        Нормальная масса человека: <b>{isNaN(states.mass) ? "---" : states.mass}</b>
                    </p>
                </div>
                <div className={"my-2"}>
                    <input className={"btn btn-outline-success"} type="submit" value="Вычислить"/>
                </div>
            </form>
        </div>)


} //Component2

// Компонент 3 - Определить является ли простым числом число a.
// Пропсы: начальное значение a.
// Стейт: a, результат проверки. По клику на кнопку меняем стейт
function Component3(props) {

    //Задание состояний
    const [states, setStates] = React.useState({salary: NaN, price: 1000, isValidPrice: undefined});

    //Ref для полей ввода
    const priceRef = React.useRef(null);

    //Валдация
    function isValid(value) {
        return value > 100 && value < 1_000_000;
    }

    //Submit обработчик
    function submitHandler(e) {
        e.preventDefault();

        let isValidFlag = states.isValidPrice;

        if (!isValidFlag && isValidFlag !== undefined)
            return;

        let priceVal = +priceRef.current.value;

        setStates({
            ...states,
            price: priceVal,
            salary: countSalary(priceVal, props.percentage)
        });

    }

    function onChangePrice(e) {
        let priceVal = Number(e.target.value);

        //Изменение state
        setStates({...states, price: priceVal, salary: NaN, isValidPrice: isValid(priceVal)})
    }

    //Формирование разметки
    return (
        <div className="ms-auto mt-4 py-4 mb-5 shadow-sm rounded border bg-light ">
            <b><p className="text-center text-Big">Компонент 3</p></b>

            <ul className="list-group list-group-flush mb-3">
                <li className="list-group-item">ФИО врача: <b>{props.doctorSnp}</b></li>
                <li className="list-group-item">Специальность врача: <b>{props.specialization}</b></li>
                <li className="list-group-item">% отчислений врачу: <b>{props.percentage}</b></li>
            </ul>

            <form onSubmit={submitHandler}>
                <div className={"row"}>
                    <div className={"col-8"}>
                        <label className={"mb-2"} htmlFor={"input_a"}>Введите значение</label>

                        <input type="number" ref={priceRef} id="input_a" step="any"
                               className={`form-control col-3 ${states.isValidPrice !== undefined ? (states.isValidPrice ? "is-valid" : "is-invalid") : ""}`}
                               value={states.price}
                               onChange={onChangePrice}
                        />
                    </div>
                </div>
                <div className={"my-3"}>
                    <p>
                        Заработная плата врача: <b>{!isNaN(states.salary) ? states.salary.toFixed(2) : "---"}</b>
                    </p>
                </div>
                <div className={"my-2"}>
                    <input className={"btn btn-outline-success"} type="submit" value="Вычислить"/>
                </div>
            </form>
        </div>)


} //Component3


//region Рендеринг
function callComponent1() {

    let date = new Date();
    let minutes = date.getMinutes();
    ReactDOM.createRoot($("component1"))
        .render(
            <Component1 senderSnp={"Пелых А.О."}
                        senderPhone={"+38 071 366 653"}
                        recipientSnp={"Яковчук А.В."}
                        recipientPhone={"+38 071 435 235"}
                        transactionTime={`[${date.getDay()}.${date.getMonth() + 1}.${date.getFullYear()}] ${date.getHours()}:${minutes < 10 ? "0" + minutes : minutes}`}
                        percentage={1.2}
            />
        )
}

function callComponent2() {

    ReactDOM.createRoot($("component2"))
        .render(
            <Component2 height={getRandomInt(140, 210)}/>
        )
}

function callComponent3() {

    ReactDOM.createRoot($("component3"))
        .render(
            <Component3 doctorSnp={"Морозова Е.К."}
                        specialization={getSpecialization()}
                        percentage={getRandomInt(8, 20)}
            />
        )
}

(() => {
    callComponent1();
    callComponent2();
    callComponent3();
})()
//endregion
*/
