// Компонент 2 - Требуется вычислять нормальную массу тела человека по его росту (по формуле Лоренца):
// Масса (кг) = (Рост (см) - 100) - (Рост (см) - 150)/2.
// Вводите исходные данные в форму, выполняйте валидацию данных.
function Component2(props) {

    //Задание состояний
    const [states, setStates] = React.useState({mass: NaN, height: props.height, isValid: undefined});

    //Ref для полей ввода
    const heightRef = React.createRef();

    //Валидация
    function isValid(height) {
        return height > 100 && height < 231;
    }

    const onChangedH = (e) => {
        let inputVal = +e.target.value;

        //Изменение state через spread
        setStates({
            ...states,
            height: inputVal,
            isValid: isValid(inputVal),
            mass: NaN
        });
    }

    //Submit обработчик
    const submitHandler = (e) => {
        e.preventDefault();

        let isValidFlag = states.isValid;

        if (!isValidFlag && isValidFlag !== undefined)
            return;

        //Получение значений
        let heightVal = +heightRef.current.value;


        setStates({
            ...states,
            height: heightVal,
            mass: getMassFromHeight(heightVal)
        });

    }

    //Формирование разметки
    return (
        <div className="mx-auto w-75 mt-4 py-4 mb-5 shadow-sm rounded border bg-light ">
            <b><p className="text-center text-Big">Компонент 2</p></b>

            <form className={"mt-auto"} onSubmit={submitHandler}>
                <div className={"row"}>
                    <div className={"col-9 ms-3"}>
                        <label className={"mb-2"} htmlFor={"input_a"}>Введите рост</label>

                        <input type="number" ref={heightRef} id="input_height"
                               className={`form-control ${states.isValid !== undefined ? (states.isValid ? "is-valid" : "is-invalid") : ""}`}
                               value={states.height}
                               onChange={onChangedH}
                        />
                    </div>
                </div>
                <div className={"my-3 ms-3"}>
                    <p>
                        Нормальная масса человека: <b>{isNaN(states.mass) ? "---" : states.mass}</b>
                    </p>
                </div>
                <div className={"my-2 ms-3"}>
                    <input className={"btn btn-outline-success"} type="submit" value="Вычислить"/>
                </div>
            </form>
        </div>)


} //Component2