//Компонент 5
function Component5(props) {

    //Параметры
    const params = useParams();
    const appointId = params.id;

    const data = Appointment.loadFromLocalStore(dataName);
    const appointment = data.find((a) => a.id == appointId);

    //Формирование разметки
    return (<>
            <Link  className="btn btn-primary mt-4 ms-4" to={`/componentOutlet`}>Назад</Link>
            <ul className="list-group list-group-flush mx-auto w-75 mt-4 py-4 mb-5 shadow-sm rounded border bg-light ">
                <li className="list-group-item">ФИО врача: <b>{appointment.doctorSnp}</b></li>
                <li className="list-group-item">ФИО Пациента: <b>{appointment.patientSnp}</b></li>
                <li className="list-group-item">Кабинет N: <b>{appointment.roomNum}</b></li>
                <li className="list-group-item">Специальность врача: <b>{appointment.speciality}</b></li>
                <li className="list-group-item">% отчислений врачу: <b>{appointment.percentage}</b></li>
                <li className="list-group-item">цена приема: <b>{appointment.price}</b></li>
                <li className="list-group-item">зарплата докторая: <b>{appointment.countSalary().toFixed(2)}</b></li>
            </ul>
        </>
    )


} //Component5