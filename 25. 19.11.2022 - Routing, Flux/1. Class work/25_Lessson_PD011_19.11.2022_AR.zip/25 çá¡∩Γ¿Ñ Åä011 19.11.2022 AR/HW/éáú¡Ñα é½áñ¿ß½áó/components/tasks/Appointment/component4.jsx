//Компонент 4 - Компонент для вывода сведений о врачебных приемах: дата,
// фамилия и инициалы пациента, фамилия и инициалы доктора, специальность доктора,
// стоимость приема (требуется также хранить процент отчислений на зарплату врача,
// номер кабинета в котором велся прием). Выведите также общую стоимость врачебных
// приемов по данным коллекции. Коллекцию данных сформируйте присваиванием или сгенерируйте.
// Коллекция должна быть сохранена в локальном хранилище, загружать коллекцию также стоит из
// локального хранилища. По клику на ссылку «Детали» выводить в компоненте 5 эти же сведения,
// процент отчислений от стоимости приема на зарплату врача, сумму к выдаче заработной платы
// врача за прием и номер кабинета, в котором велся прием.

function Component4(props) {

    //Название коллекции в локальном хранилище

    const [appointmentsList, setAppointments] = React.useState()

    //Работа с локальным хранилищем. UseEffect отработает при создании компонента
    //Корректно не работает
    /*React.useEffect(() => {
        //Получить запись из локального хранилища
        let list = localStorage.getItem(dataName);

        if (list === null){
            //Записать в JSON формате список
            list = JSON.stringify(appointments);
            localStorage.setItem(dataName,list);
        }

        setAppointments(Appointment.loadFromLocalStore(dataName));

    },[])*/


    //Получить запись из локального хранилища
    let list = localStorage.getItem(dataName);

    if (list === null){
        //Записать в JSON формате список
        list = JSON.stringify(appointments);
        localStorage.setItem(dataName,list);
    }

    list = Appointment.loadFromLocalStore(dataName);
    /*setAppointments(Appointment.loadFromLocalStore(dataName));*/


    let row = list.map((el) => el.toTableRow());

    let thClasses = `text-center`

    //Формирование разметки
    return (
        <table className="table table-bordered  shadow bg-white w-75 mx-auto mt-5">
            <tr>
                <th className={"text-center"}>ID</th>
                <th className={thClasses}>Дата приема</th>
                <th className={thClasses}>Доктор</th>
                <th className={thClasses}>Пациент</th>
                <th className={thClasses}>Специальность</th>
                <th className={thClasses}>Цена</th>
                <th className={thClasses}>Подробности</th>
            </tr>

            <tbody>
            {row}
            </tbody>
        </table>
    )


} //Component4