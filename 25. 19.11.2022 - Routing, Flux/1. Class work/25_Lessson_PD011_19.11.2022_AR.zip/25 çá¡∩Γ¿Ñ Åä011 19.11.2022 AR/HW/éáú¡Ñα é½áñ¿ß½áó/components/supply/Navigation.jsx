function Nav() {

    // callback для NavLink
    const setActive = ({ isActive }) => "nav-link " + (isActive ? "active" : "");

    return  (
        <nav className="navbar navbar-expand-sm navbar-dark bg-dark sticky-top shadow">
            <div className="container-fluid justify-content-center">

                <Link className="navbar-brand" to="/">Home work</Link>

                <div className="collapse navbar-collapse">
                    <ul className="navbar-nav">


                        <li className="nav-item ms-3">
                            <NavLink className={setActive} to="/">Главная</NavLink>
                        </li>


                        <li className="nav-item">
                            <NavLink className={setActive} to="/component1">Компонент 1</NavLink>
                        </li>

                        <li className="nav-item">
                            <NavLink className={setActive} to="/component2">Компонент 2</NavLink>
                        </li>

                        <li className="nav-item">
                            <NavLink className={setActive} to="/component3">Компонент 3</NavLink>
                        </li>

                        <li className="nav-item">
                            <NavLink className={setActive} to="/componentOutlet">Компонент 4</NavLink>
                        </li>

                    </ul>
                </div>
            </div>
        </nav>
    )
}