//Получение элемента
/*$ = (id) => {
    return document.getElementById(id);
};*/

//Генерация значений
function getRandomDouble(lo, hi) {
    return lo + (hi-lo)*Math.random();
}
function getRandomInt(lo, hi) {
    return  Math.round(lo + (hi-lo)*Math.random());
}

function getAssessments(percentage, summ) {
    return percentage/100 * summ;
}

//Получение нормальной массы тела человека
function getMassFromHeight (height) {return (height - 100) - (height - 150)/2 }

//Определение типа числа
function countSalary(appointmentPrice, percentage, incomeTax = 0.13) {
    if (appointmentPrice < 0 || percentage > 100)
        return ;
    let salary = appointmentPrice * (percentage/100);
    return salary - salary*incomeTax;
}

//Специализации врачей
function getSpecialization() {
    let specializations = [
        "Педиатор",
        "Дерматолог",
        "Психотерапевт",
        "Невролог",
        "Иммунолог",
    ]

    return specializations[getRandomInt(0,specializations.length-1)]
}

let appointments = [
    new Appointment(1,new Date(2022,10,15).toLocaleDateString(),'Васильев Д.В','Кац Д.В'
        ,getSpecialization(),getRandomInt(1000,10000),getRandomInt(8,20),getRandomInt(5,200)),
    new Appointment(2,new Date(2022,10,15).toLocaleDateString(),'Павловский А.В','Зайцева B.А'
        ,getSpecialization(),getRandomInt(1000,10000),getRandomInt(8,20),getRandomInt(5,200)),
    new Appointment(3,new Date(2022,10,15).toLocaleDateString(),'Квитко А.К','Курдиков С.К'
        ,getSpecialization(),getRandomInt(1000,10000),getRandomInt(8,20),getRandomInt(5,200)),
    new Appointment(4,new Date(2022,10,15).toLocaleDateString(),'Ведерников Е.В','Якубович А.Д'
        ,getSpecialization(),getRandomInt(1000,10000),getRandomInt(8,20),getRandomInt(5,200)),
    new Appointment(5,new Date(2022,10,15).toLocaleDateString(),'Мармазова В.Е','Царско З.В'
        ,getSpecialization(),getRandomInt(1000,10000),getRandomInt(8,20),getRandomInt(5,200)),
]

//Специализации врачей
function getAppointment(index) {

    return specializations[getRandomInt(0,specializations.length-1)]
}
