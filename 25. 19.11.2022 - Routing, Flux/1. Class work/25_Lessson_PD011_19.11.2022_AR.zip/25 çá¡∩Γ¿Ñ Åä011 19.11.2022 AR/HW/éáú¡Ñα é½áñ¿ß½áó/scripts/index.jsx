const useParams = ReactRouterDOM.useParams;
const Outlet = ReactRouterDOM.Outlet;
const Router = ReactRouterDOM.BrowserRouter;
const Route = ReactRouterDOM.Route;
const Routes = ReactRouterDOM.Routes;
const NavLink = ReactRouterDOM.NavLink;
const Link = ReactRouterDOM.Link;

let date = new Date();
let minutes = date.getMinutes();
const dataName = 'appointments';

ReactDOM.createRoot(document.getElementById("app"))
    .render(
        <Router>
            <div>
                <Nav/>
                <section className="min-vh-90">
                    <Routes>
                        <Route path="/" element={<Main/>}/>
                        <Route path="/component1" element={<Component1 senderSnp={"Пелых А.О."}
                                                                       senderPhone={"+38 071 366 653"}
                                                                       recipientSnp={"Яковчук А.В."}
                                                                       recipientPhone={"+38 071 435 235"}
                                                                       transactionTime={`[${date.getDay()}.${date.getMonth() + 1}.${date.getFullYear()}] ${date.getHours()}:${minutes < 10 ? "0" + minutes : minutes}`}
                                                                       percentage={1.2}
                        />}/>
                        <Route path="/component2" element={<Component2 height={getRandomInt(140, 210)}/>}/>
                        <Route path="/component3" element={<Component3 doctorSnp={"Морозова Е.К."}
                                                                       specialization={getSpecialization()}
                                                                       percentage={getRandomInt(8, 20)}/>}/>

                        <Route path="/componentOutlet" element={<ComponentsOutlet/>}>
                            <Route index element={<Component4/>}/>
                            <Route path="details/:id" element={<Component5/>}/>
                        </Route>

                        <Route path="*" element={<h3>Ресурс не найден</h3>}/>
                    </Routes>

                </section>
            </div>
        </Router>
    );