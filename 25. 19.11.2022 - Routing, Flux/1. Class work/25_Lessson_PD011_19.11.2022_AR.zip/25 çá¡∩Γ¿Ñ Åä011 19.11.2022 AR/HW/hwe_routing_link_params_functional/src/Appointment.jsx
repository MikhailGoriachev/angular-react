// дата приема, фамилия и инициалы пациента, фамилия и инициалы доктора,
// специальность доктора, стоимость приема, процент отчислений на зарплату врача,
// номер кабинета в котором велся прием
class Appointment {
    constructor(id, date, patient, doctor, speciality, price, percent, cabinet) {
        this.id = id;
        this.date = date;
        this.patient = patient;
        this.doctor = doctor;
        this.speciality = speciality;
        this.price = price;
        this.percent = percent;
        this.cabinet = cabinet;
    }

    // вычисление зарплаты доктора, получаемой на руки
    // Стоимость приема * Процент отчисления от стоимости приема на зарплату врача.
    // Из этой суммы вычитается подоходный налог, составляющий 13% от суммы
    salary() {
        let sum = this.price * this.percent / 100;
        return 0.87 * sum;
    }

    // вывод данных в строку таблицы
    // дата приема, фамилия и инициалы пациента, фамилия и инициалы доктора, специальность доктора, стоимость приема
    toTableRow() {
        return <tr key={this.id}>
            <td>{this.id}</td>
            <td>{this.date.toLocaleDateString()}</td>
            <td>{this.patient}</td>
            <td>{this.doctor}</td>
            <td>{this.speciality}</td>
            <td>{this.price}</td>
            <td><NavLink className= "btn btn-secondary" to={`/component4/${this.id}`}>Детали</NavLink></td>
        </tr>
    } // toTableRow
}