function Nav(){

    const NavLink = ReactRouterDOM.NavLink;

    // callback для NavLink
    const setActive = ({ isActive }) => "link-item " + (isActive ? "active" : "");

    return (
        <div className="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
            <div className="container-fluid">
                <div style={{width: '70%', margin: 'auto', fontWeight: '500px'}}>
                    <div className="navbar-collapse">
                        <ul className="navbar-nav fs-4" id="nav">
                            <li className="nav-item pt-1">
                                <NavLink to="/" className={setActive} >Страница с заданием</NavLink>
                            </li>
                            <li className="nav-item pt-1 ps-3">
                                <NavLink className={setActive} to="/task01">Компонент 1</NavLink>
                            </li>
                            <li className="nav-item pt-1 ps-3">
                                <NavLink className={setActive} to="/task02">Компонент 2</NavLink>
                            </li>
                            <li className="nav-item pt-1 ps-3">
                                <NavLink className={setActive} to="/task03">Компонент 3</NavLink>
                            </li>
                            <li className="nav-item pt-1 ps-3">
                                <NavLink className={setActive} to="/task04">Компонент 4</NavLink>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>);
}