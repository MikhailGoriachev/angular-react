
function Component04(props){

    const [receptions, setReceptions] = React.useState(props.receptions);

    //Коллекция должна быть сохранена в локальном хранилище,
    // загружать коллекцию также стоит из локального хранилища.
    React.useEffect(() => {

        // извлекаем данные из localStorage
        const medicalReceptions = localStorage.getItem("medicalReceptions");

        // если в localStorage есть такой объект
        if(medicalReceptions !==null ) {
            setReceptions(medicalReceptions);
            console.log("Данные получены из localStorge");
        }else {
            localStorage.setItem("medicalReceptions", receptions);
            console.log("Данные сохранены в localStorage");
        }

    },[]);

    return (
       <table className="table">
           <thead>
                <tr>
                <th>Дата</th>
                <th>Пациент</th>
                <th>Врач</th>
                <th>Спецаильность</th>
                <th>Стоимость</th>
                <th>Процент</th>
                <th>Номер кабинета</th>
                </tr>
           </thead>
           <tbody>
                {
                    receptions.map(function (item){
                        return <tr key={item.id}>
                            <td>{item.data}</td>
                            <td>{item.patient}</td>
                            <td>{item.doctor}</td>
                            <td>{item.speciality}</td>
                            <td>{item.cost}</td>
                            <td>{item.interestPercent}</td>
                            <td>{item.number}</td>
                        </tr>
                    })
                }

           </tbody>
       </table>
    );
}