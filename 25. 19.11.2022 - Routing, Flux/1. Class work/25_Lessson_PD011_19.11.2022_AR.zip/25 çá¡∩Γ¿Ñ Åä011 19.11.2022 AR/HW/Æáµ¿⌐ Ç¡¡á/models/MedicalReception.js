/*Компонент 4 .Компонент для вывода сведений о врачебных
приемах: дата, фамилия и инициалы пациента, фамилия и инициалы
доктора, специальность доктора, стоимость приема (требуется также
хранить процент отчислений на зарплату врача, номер кабинета в
котором велся прием). */

class MedicalReception {

    constructor(date,patient,doctor,speciality,cost,interestPercent,number) {

        //дата
        this.date = date;

        //фамилия и инициалы пациента
        this.patient = patient;

        // фамилия и инициалы врача
        this.doctor = doctor;

        // спецаильность врача
        this.speciality = speciality;

        // стоимость приёма
        this.cost = cost;

        // процент отчисления врачу
        this.interestPercent = interestPercent;

        //номер кабинета в котором велся прием
        this.number = number;

    }
}