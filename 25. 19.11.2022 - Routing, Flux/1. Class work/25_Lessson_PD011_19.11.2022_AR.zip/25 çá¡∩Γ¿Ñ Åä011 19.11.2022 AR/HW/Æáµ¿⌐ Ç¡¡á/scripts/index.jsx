// обработка страницы "index.html"

const Router = ReactRouterDOM.BrowserRouter;
const Route = ReactRouterDOM.Route;
const Routes = ReactRouterDOM.Routes;

const Outlet = ReactRouterDOM.Outlet;

function NotFound() {
    return <p className="fs-4">Ресурс не найден!</p>;
}

function MedicalReceptions() {
    return (
        <div>
            <p className="fs-4">Врачебные приемы:</p>
            <Outlet/>
        </div>
    );
}

const receptions= [
    new MedicalReception(new Date(),"Фролов В. А.","Кузнецова А. К.","Гематолог",2500,40,34),
    new MedicalReception(new Date(),"Орлов Н. Д.","Дубровина С. А.","Паразитолог",2300,30,41),
    new MedicalReception(new Date(),"Максимова В. М.","Беляев Г. В.","Остеопат",4500,35,44),
    new MedicalReception(new Date(),"Иванова Е. П.","Семенов Г. Р.","Ортопед",2600,40,22),
    new MedicalReception(new Date(),"Голубева В. А.","Петрова А. М.","Стоматолог",5500,30,24)
]

// вывод навигации
ReactDOM.createRoot(document.querySelector("#app")).render(
    <Router>
        <Nav/>
        <div className="container-fluid">
            <div className="row-sm mt-5 p-3 container-fluid-style">
                <div className="p-4 bg-white m-3 border-warning-top border-warning-bottom">
                    <section className="mx-5 my-4 bg-light p-3">
                        <div className="row">
                            <Routes>

                                <Route path='/' element={<Main/>}/>
                                <Route path="/task01" element={<Component01 bankTransfer={new BankTransfer(
                                    'Гришин В. А.',
                                    '+38(050)-55-00-432',
                                    'Вершкова А. Д.',
                                    '+38(050)-55-34-541',
                                    12.5,
                                    0)}
                                />}/>
                                <Route path="/task02" element={<Component02 />}/>
                                <Route path="/task03" element={ <Component03 appointment={new Appointment(
                                    'Безруков И. В.',
                                    'Терапевт',
                                    0,
                                    30,
                                    13)}/>}/>
                                <Route path="/task04" element={<MedicalReceptions/>}>
                                    <Route index element={<Component04 receptions= {receptions}/>}/>
                                </Route>
                                <Route path="*" element={<NotFound/>}/>

                            </Routes>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </Router>

);

