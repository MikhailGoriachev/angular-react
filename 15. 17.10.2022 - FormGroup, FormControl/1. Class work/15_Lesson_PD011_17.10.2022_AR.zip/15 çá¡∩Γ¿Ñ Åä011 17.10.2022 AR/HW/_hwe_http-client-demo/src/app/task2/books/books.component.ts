import { Component, OnInit } from '@angular/core';
import {Task2BooksService} from "../../services/task2-books.service";
import {Book} from "../../../models/Book";

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  providers: [Task2BooksService]
})
export class BooksComponent implements OnInit {

  books: Book[];

  constructor(private _task2BookService: Task2BooksService) {
    this.books = [];
  }

  ngOnInit(): void {
    // обращение к серверу и подписка на получение результата
    // запроса (данных)
    this._task2BookService.getBooks()
      .subscribe(result => {
        this.books = result as Book[];
        console.dir(this.books);
    });

  }

}
