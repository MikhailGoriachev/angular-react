import { Injectable } from '@angular/core';
import {InMemoryDbService} from "angular-in-memory-web-api";
import {Book} from "../../models/Book";

@Injectable({
  providedIn: 'root'
})
export class Task2BackendService implements InMemoryDbService {

  constructor() { }

  // реализация интерфейса InMemoryDbService
  createDb() {
    let booksList = [
      new Book( 1, "C# 4.0 полное руководство",          2011,  720, "Шилдт Г." ),
      new Book( 2, "Программируем на С# 8.0",            2021, 1100, "Гриффитс М."),
      new Book( 3, "Задачник по PHP с решениями",        2018,  650, "Григорьев Р.И."),
      new Book( 4, "1000 задач по программированию",     2002,  100, "Абрамян М.Э."),
      new Book( 6, "Python - книга рецептов",            2019, 1100, "Бизли Д."),
      new Book( 7, "Технология LINQ",                    2011,  460, "Абрамян М.Э."),
      new Book( 8, "Думай, как программист",             2018,  300, "Спрол А."),
      new Book( 9, "Изучаем Java EE",                   2016,  800, "Дашнер С."),
      new Book(10, "Практикум STL для C++17",            2018,  700, "Борисова Р.К."),
      new Book(11, "Spring в действии",                  2018, 1100, "Уоллс К."),
      new Book(12, "Практикум по программированию на C", 2012,  540, "Павловская Т.А."),
      new Book(13, "Java 8 - полное руководство",        2015,  780, "Шилдт Г.")
    ];

    // доступ из сервиса получения данных по uri api/books - по имени свойства
    return {books: booksList};
  } // dbCreate

}
