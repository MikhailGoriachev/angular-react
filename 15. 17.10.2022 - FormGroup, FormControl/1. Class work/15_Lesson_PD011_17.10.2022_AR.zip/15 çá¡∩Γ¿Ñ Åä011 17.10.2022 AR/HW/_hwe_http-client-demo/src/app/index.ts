// перечисление компонентов для экспорта
export * from "./app.component";
export * from "./home/home.component";
export * from "./not-found/not-found.component";
// export * from "./task1/index";
export * from "./task1/users/users.component";
export * from "./task1/posts/posts.component";
export * from "./task1/photos/photos.component";
export * from "./task1/todos/todos.component";

