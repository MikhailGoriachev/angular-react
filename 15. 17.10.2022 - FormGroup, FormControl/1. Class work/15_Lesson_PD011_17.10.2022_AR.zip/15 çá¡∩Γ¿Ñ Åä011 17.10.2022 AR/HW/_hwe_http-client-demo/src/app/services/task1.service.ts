// сервис для получения данных к задаче 1
import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";

@Injectable()
export class Task1Service {
  // общая часть пути к удаленному сервису
  private _url: string = 'https://jsonplaceholder.typicode.com/';

  // конструктор с DI для HttpClient
  constructor(private _http: HttpClient) { }

  // запрос сведений о пользователях с удаленного сервера
  getUsers(){
    return this._http.get(`${this._url}users`);
  } // getUsers

  // запрос постов заданного пользователя
  getUserPosts(id: number) {
    return this._http.get(`${this._url}users/${id}/posts`);
  } // getUserPosts

  // запрос фотографий из альбома заданного пользователя
  getUserPhotos(id: number) {
    return this._http.get(`${this._url}albums/${id}/photos`);
  } // getUserPhotos

  // запрос списка дел заданного пользователя
  getUserTodos(id: number) {
    return this._http.get(`${this._url}users/${id}/todos`);
  } // getUserTodos

} // class Task1Service
