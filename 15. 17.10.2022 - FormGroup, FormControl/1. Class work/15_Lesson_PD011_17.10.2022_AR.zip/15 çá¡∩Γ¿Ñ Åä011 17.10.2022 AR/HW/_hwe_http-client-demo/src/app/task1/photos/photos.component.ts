import { Component, OnInit } from '@angular/core';
import {Task1Service} from "../../services/task1.service";

@Component({
  selector: 'app-photos',
  templateUrl: './photos.component.html',
  providers: [Task1Service]
})
export class PhotosComponent implements OnInit {

  constructor(private _task1Server: Task1Service) { }

  ngOnInit(): void {
  }

}
