import { Component, OnInit } from '@angular/core';
import {Task1Service} from "../../services/task1.service";
import {User} from "../../../models/User";

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  providers: [Task1Service]
})
export class UsersComponent implements OnInit {
  // сведения о пользователях
  users: User[] = null!;

  // подключение к сервису получения данных
  constructor(private _task1Service: Task1Service) {
    // this.users = [];
  } // constructor

  ngOnInit(): void {
    // обращение к серверу и подписка на получение результата
    // запроса (данных)
    this._task1Service.getUsers()
      .subscribe(result => {
        this.users = [];
        for(let {email, id, name, phone, username, website} of result as []) {
          this.users.push(new User(id, name, username, email, phone, website))
        }
      });

  } // ngOnInit

}
