import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class Task2BooksService {

  constructor(private _http: HttpClient) { }

  getBooks(){
    return this._http.get('api/books');
  }
}
