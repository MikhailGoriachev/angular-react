import { NgModule } from '@angular/core';

// для работы с удаленным веб-сервисом
import { HttpClientModule } from "@angular/common/http";

// для работы с имитацией удаленного сервиса
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';

import { BrowserModule } from '@angular/platform-browser';

import {
  AppComponent,
  HomeComponent,
  NotFoundComponent,
  PhotosComponent,
  PostsComponent,
  TodosComponent,
  UsersComponent,
} from './index';
import {AppRoutingModule} from "./app-routing.module";
import { BooksComponent } from './task2/books/books.component';
import {Task2BackendService} from "./services/task2-backend.service";

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NotFoundComponent,
    UsersComponent,
    PostsComponent,
    PhotosComponent,
    TodosComponent,
    BooksComponent,
  ],
  imports: [
    BrowserModule, HttpClientModule, AppRoutingModule,
	// подключение имитатора серверной стороны (БД), в параметрах разрещаем работу
	// также и с другими адресами, не только с адресом имитатора, задаем задержку 
	// выдачи ответа от имитатора
    InMemoryWebApiModule.forRoot(Task2BackendService, {passThruUnknownUrl: true, delay: 500 })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
