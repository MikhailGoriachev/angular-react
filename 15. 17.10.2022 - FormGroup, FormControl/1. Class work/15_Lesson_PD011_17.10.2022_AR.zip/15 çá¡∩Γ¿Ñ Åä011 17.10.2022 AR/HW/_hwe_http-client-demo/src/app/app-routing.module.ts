import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {
  HomeComponent,
  NotFoundComponent,
  PhotosComponent, PostsComponent, TodosComponent, UsersComponent
} from "./index";
import {BooksComponent} from "./task2/books/books.component";

const routes: Routes = [
  // маршруты приложения
  {path: '', component: HomeComponent},
  {path: 'users', component: UsersComponent},
  {path: 'posts', component: PostsComponent},
  {path: 'photos', component: PhotosComponent},
  {path: 'todos', component: TodosComponent},
  // -------------------------------------------
  {path: 'books', component: BooksComponent},
  // компонент для несуществующих путей
  { path: '**', component: NotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
