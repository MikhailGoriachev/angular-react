import { Component, OnInit } from '@angular/core';
import {Task1Service} from "../../services/task1.service";

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  providers: [Task1Service]
})
export class PostsComponent implements OnInit {

  constructor(private _task1servuce: Task1Service) { }

  ngOnInit(): void {
  }

}
