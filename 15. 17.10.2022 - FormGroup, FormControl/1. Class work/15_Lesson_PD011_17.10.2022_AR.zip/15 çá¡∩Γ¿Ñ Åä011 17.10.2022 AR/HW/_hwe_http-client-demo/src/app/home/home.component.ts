import { Component, OnInit } from '@angular/core';

// Вывод задания на разработку
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html'
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void { }

} // class HomeComponent
