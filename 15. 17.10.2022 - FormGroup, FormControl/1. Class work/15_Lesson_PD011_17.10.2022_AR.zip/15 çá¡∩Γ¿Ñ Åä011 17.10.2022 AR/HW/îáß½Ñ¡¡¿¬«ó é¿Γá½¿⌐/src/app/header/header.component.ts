import { Component, OnInit } from '@angular/core';
import { ActivationStart, Router } from "@angular/router";
import { Subscription } from "rxjs";
import { AutoUnsubscribe } from "ngx-auto-unsubscribe-decorator";

@Component({
    selector: 'app-header',
    template: `
        <header class="container-fluid">
            <div class="top-bar row align-items-center ps-4">
                <h1> {{title}}</h1>
            </div>
        </header>
    `,
    styles: []
})
export class HeaderComponent implements OnInit {

    title: string | undefined;
    
    @AutoUnsubscribe()
    titleSubscription!: Subscription;

    constructor(private router: Router) { }
    
    ngOnInit() {
        this.titleSubscription = this.router.events.subscribe(data => {
            if (data instanceof ActivationStart) {
                this.title = data.snapshot.data['title'];
            }
        })
    }
}
