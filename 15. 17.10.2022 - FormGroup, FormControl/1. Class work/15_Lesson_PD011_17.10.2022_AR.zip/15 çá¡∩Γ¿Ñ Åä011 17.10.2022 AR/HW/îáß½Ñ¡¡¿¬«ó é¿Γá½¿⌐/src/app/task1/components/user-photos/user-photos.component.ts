import { Component, Input, OnInit } from '@angular/core';
import { HttpClientUserService } from "../../services/http-client-user.service";
import { Observable, tap } from "rxjs";
import { Photo } from "../../../../models/task1/photo";

@Component({
    selector: 'app-user-photos',
    templateUrl: './user-photos.component.html'
})
export class UserPhotosComponent implements OnInit {
    @Input() id!: number;

    photos$!: Observable<Photo[]>;
    
    photosCount: number = 0;

    constructor(private userService: HttpClientUserService) {
    }

    ngOnInit(): void {
        this.photos$ = this.userService.getUserPhotos(this.id)
            .pipe(tap(res => {
                this.photosCount = res.length;
            }));
    }
}
