import { Component, Input, OnInit } from '@angular/core';
import { HttpClientUserService } from "../../services/http-client-user.service";
import { Observable, tap } from "rxjs";
import { Todo } from "../../../../models/task1/todo";
import { IconNamesEnum } from "ngx-bootstrap-icons";

@Component({
    selector: 'app-user-todos',
    templateUrl: './user-todos.component.html'
})
export class UserTodosComponent implements OnInit {
    iconNames = IconNamesEnum;
    
    @Input() id!: number;

    todos$!: Observable<Todo[]>

    todosCount: number = 0;
    todosCompleted: number = 0;
    todosIncompleted: number = 0;
    
    constructor(private userService: HttpClientUserService) { }

    ngOnInit(): void {
        this.todos$ = this.userService.getUserTodos(this.id)
            .pipe(tap(res => {
                this.todosCount = res.length;
                this.todosCompleted = res.filter(v => v.completed).length;
                this.todosIncompleted = this.todosCount - this.todosCompleted;
            }))
    }
}
