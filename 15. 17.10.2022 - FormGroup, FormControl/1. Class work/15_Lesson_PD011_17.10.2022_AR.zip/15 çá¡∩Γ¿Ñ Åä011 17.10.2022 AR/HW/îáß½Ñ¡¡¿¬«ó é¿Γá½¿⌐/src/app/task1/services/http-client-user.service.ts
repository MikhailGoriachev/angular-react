import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { User } from "../../../models/task1/user";
import { Post } from "../../../models/task1/post";
import { Photo } from "../../../models/task1/photo";
import { Todo } from "../../../models/task1/todo";

@Injectable()
export class HttpClientUserService {

    // URL сервиса поставки данных - API
    private readonly url: string = "https://jsonplaceholder.typicode.com";

    constructor(private http: HttpClient) { }
    
    getUsers(): Observable<User[]> {
        return this.http.get<User[]>(`${this.url}/users`);
    }
    
    getUserPosts(id: number): Observable<Post[]> {
        return this.http.get<Post[]>(`${this.url}/users/${id}/posts`);
    }
    
    getUserPhotos(id: number): Observable<Photo[]> {
        return this.http.get<Photo[]>(`${this.url}/albums/${id}/photos`);
    }
    
    getUserTodos(id: number): Observable<Todo[]> {
        return this.http.get<Todo[]>(`${this.url}/users/${id}/todos`);
    }
}
