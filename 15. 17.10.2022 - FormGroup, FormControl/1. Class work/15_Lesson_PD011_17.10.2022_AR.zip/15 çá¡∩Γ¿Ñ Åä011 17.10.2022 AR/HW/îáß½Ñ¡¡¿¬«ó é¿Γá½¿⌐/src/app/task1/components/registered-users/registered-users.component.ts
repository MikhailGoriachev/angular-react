import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { HttpClientUserService } from "../../services/http-client-user.service";
import { Observable } from "rxjs";
import { User } from "../../../../models/task1/user";
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-registered-users',
  templateUrl: './registered-users.component.html'
})
export class RegisteredUsersComponent implements OnInit {
  
  @ViewChild("modal")
  modalElement!: TemplateRef<any>;        // ссылка на элемент разметки модального окна
  modalRef!: BsModalRef;                  // ссылка для объекта модального окна                             
  modalContent!: TemplateRef<any> | null; // ссылка на текущий контент модального окна
  modalTitle: string = "";
  
  users$!: Observable<User[]>;
  chosenUserId: number = 0;
  
  constructor(private userService: HttpClientUserService, private modalService: BsModalService) { }

  ngOnInit(): void {
    this.users$ = this.userService.getUsers();
  }
  
  showModal(id: number, content:TemplateRef<any>, title: string) {
    this.chosenUserId = id;
    this.modalContent = content;
    this.modalTitle = title;
    this.modalRef = this.modalService.show(this.modalElement!, { class: 'modal-custom-style' });
  }
}
