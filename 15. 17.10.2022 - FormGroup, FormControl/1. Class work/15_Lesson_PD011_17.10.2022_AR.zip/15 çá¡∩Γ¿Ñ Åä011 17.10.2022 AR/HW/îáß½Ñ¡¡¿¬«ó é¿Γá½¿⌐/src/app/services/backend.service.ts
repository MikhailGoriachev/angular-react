import { Injectable } from '@angular/core';
import { InMemoryDbService } from "angular-in-memory-web-api";
import { unique } from "radash";
import { Books } from "../../models/task2/mock-books"

@Injectable({
  providedIn: 'root'
})
export class BackendService implements InMemoryDbService{

  constructor() { }

  createDb() {
    const books = Books;
    
    const authors = unique(books.map(b => b.author)).sort();
        
    return { 
      books,
      authors
    };
  }
}
