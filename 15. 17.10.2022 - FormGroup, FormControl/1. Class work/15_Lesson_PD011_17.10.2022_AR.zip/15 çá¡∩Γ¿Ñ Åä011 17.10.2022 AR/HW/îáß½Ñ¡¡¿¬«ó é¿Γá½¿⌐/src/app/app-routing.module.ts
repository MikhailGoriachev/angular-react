import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from "./home/home.component";
import { RegisteredUsersComponent } from "./task1/components/registered-users/registered-users.component";
import { BooksComponent } from "./task2/components/books/books.component";

export const routes: Routes = [
    { path: '', component: HomeComponent, title: 'Главная', data: { title: 'Главная' } },
    { path: 'users', component: RegisteredUsersComponent, title: 'Пользователи', data: { title: 'Пользователи' } },
    { path: 'books', component: BooksComponent, title: 'Книги', data: { title: 'Книги' } },
    { path: '**', redirectTo: '/' },];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule {

}
