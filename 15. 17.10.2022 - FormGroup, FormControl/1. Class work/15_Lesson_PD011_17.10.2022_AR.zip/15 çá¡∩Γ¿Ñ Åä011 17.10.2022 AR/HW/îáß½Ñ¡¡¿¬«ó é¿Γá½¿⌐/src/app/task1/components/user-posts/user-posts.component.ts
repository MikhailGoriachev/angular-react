import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { HttpClientUserService } from "../../services/http-client-user.service";
import { Post } from "../../../../models/task1/post";
import { Observable, tap } from "rxjs";
import { first, last, sum } from "radash";

@Component({
    selector: 'app-user-posts',
    templateUrl: './user-posts.component.html'
})
export class UserPostsComponent implements OnInit {

    @Input() id!: number;

    posts$!: Observable<Post[]>;

    postsCount: number = 0;
    maxLength: number = 0;
    minLength: number = 0;
    avgLength: number = 0;

    constructor(private userService: HttpClientUserService) { }

    ngOnInit(): void {
        this.posts$ = this.userService.getUserPosts(this.id)
            .pipe(tap(res => {
                const lengths = res.map(v => v.body.length).sort();

                this.postsCount = lengths.length;
                this.maxLength = last(lengths);
                this.minLength = first(lengths);
                this.avgLength = sum(lengths) / lengths.length;
            }));
    }
}
