import { Component, OnInit } from '@angular/core';
import { routes as Routes } from "../app-routing.module";

@Component({
    selector: 'app-navbar',
    template: `
        <nav class="navbar navbar-expand-sm navbar-main bg-body sticky-top shadow mb-2">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#appNavbarMain">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="appNavbarMain">
                    <ul class="navbar-nav ms-3">

                        <li *ngFor="let route of routes" class="nav-item nav-item-my me-2">
                            <a [routerLink]="route.path"
                               routerLinkActive="active" [routerLinkActiveOptions]="{exact: true}"
                               class="nav-link nav-link-my" title="Перейти на страницу">
                                {{route.title}} </a> 
                        </li>
                        
                    </ul>
                </div>
            </div>
        </nav>
    `,
    styles: []
})
export class NavbarComponent implements OnInit {
    routes = Routes.slice(0, -1);
    
    constructor() {
    }

    ngOnInit(): void {
    }
}
