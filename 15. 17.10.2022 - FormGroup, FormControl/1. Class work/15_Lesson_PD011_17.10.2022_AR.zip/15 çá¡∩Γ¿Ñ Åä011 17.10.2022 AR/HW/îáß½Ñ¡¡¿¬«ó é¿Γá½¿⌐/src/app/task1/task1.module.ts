import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RegisteredUsersComponent } from './components/registered-users/registered-users.component';
import { UserPostsComponent } from './components/user-posts/user-posts.component';
import { UserPhotosComponent } from './components/user-photos/user-photos.component';
import { UserTodosComponent } from './components/user-todos/user-todos.component';
import { NgxBootstrapIconsModule } from "ngx-bootstrap-icons";
import { HttpClientUserService } from "./services/http-client-user.service";



@NgModule({
  declarations: [
    RegisteredUsersComponent,
    UserPostsComponent,
    UserPhotosComponent,
    UserTodosComponent
  ],
    imports: [
        CommonModule,
        NgxBootstrapIconsModule,
    ],
    providers: [HttpClientUserService]
})
export class Task1Module { }
