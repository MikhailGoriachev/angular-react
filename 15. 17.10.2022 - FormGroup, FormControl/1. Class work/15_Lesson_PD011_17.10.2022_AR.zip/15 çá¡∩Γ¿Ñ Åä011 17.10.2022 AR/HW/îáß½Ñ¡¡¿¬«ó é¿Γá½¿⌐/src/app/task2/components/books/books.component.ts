import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { HttpClientBookService } from "../../services/http-client-book.service";
import { Book } from "../../../../models/task2/book";
import { sortBy } from "../../../../util/array";
import { IconNamesEnum } from "ngx-bootstrap-icons";
import { Observable, Subscription } from "rxjs";
import { Books as BooksSource } from "../../../../models/task2/mock-books";
import { draw, min } from "radash";
import { BsModalRef, BsModalService } from "ngx-bootstrap/modal";
import { BsDropdownConfig } from "ngx-bootstrap/dropdown";
import { AutoUnsubscribe } from "ngx-auto-unsubscribe-decorator";

@Component({
    selector: 'app-books',
    templateUrl: './books.component.html',
    providers: [{ provide: BsDropdownConfig, useValue: { isAnimated: true, autoClose: true } }]
})
export class BooksComponent implements OnInit {
    iconNames = IconNamesEnum;

    @ViewChild("modal")
    modalElement!: TemplateRef<any>;        // ссылка на элемент модального окна в разметке 
    modalRef!: BsModalRef;                  // ссылка на объект модального окна для управления
    modalContent!: TemplateRef<any> | null; // ссылка на текущий контент модального окна
    modalTitle: string = "";

    // Ссылка на подписку
    @AutoUnsubscribe() // https://www.npmjs.com/package/ngx-auto-unsubscribe-decorator
    booksSubscription!: Subscription;
    
    // Коллекция данных
    books!: Book[];
    
    // Объект для редактирования
    bookEdit: Book = new Book();
    @AutoUnsubscribe()
    editBooksSubscription!: Subscription;

    // Наблюдаемая коллекция списка авторов
    authors$!: Observable<string[]>;

    // настройка колонок
    columns = [
        { name: 'Id', sortProp: (b: Book) => b.id },
        { name: 'Название', sortProp: (b: Book) => b.title },
        { name: 'Автор', sortProp: (b: Book) => b.author },
        { name: 'Год издания', sortProp: (b: Book) => b.year },
        { name: 'Цена, ₽', sortProp: (b: Book) => b.price },
    ];
    isOrderDescend: boolean = false;   // текущий порядок сортировки в таблице   
    lastSorted: string = "Id";         // последний сортированный столбец


    constructor(private bookClient: HttpClientBookService, private modalService: BsModalService) {
    }

    ngOnInit(): void {
        this.sourceData();
        this.authors$ = this.bookClient.getAuthors();
    }

    // Отобразить модальное окно с указанным контентом
    showModal(content: TemplateRef<any>, title: string = "Фильтр") {
        this.modalContent = content;
        this.modalTitle = title;
        this.modalRef = this.modalService.show(this.modalElement!, { class: 'modal-dialog-centered' });
    }
    
    // Инициация редактирования данных
    initEdit(id: number, modalContent: TemplateRef<any>) {
        this.editBooksSubscription = this.bookClient.getBookById(id).subscribe(res => this.bookEdit = res)

        this.showModal(modalContent, "Редактировать информацию о книге");
    }
    
    // сортировка таблицы
    onOrderChanged(name: string, property: (b: Book) => number | string) {
        if (name == this.lastSorted)
            this.isOrderDescend = !this.isOrderDescend;

        this.lastSorted = name;
        sortBy(this.books, property, this.isOrderDescend);
    }

    // Загрузить исходные данные
    sourceData() {
        this.resetData();
        this.booksSubscription = this.bookClient.getBooks()
            .subscribe(res => this.books = res);
    }

    addBook() {
        this.booksSubscription = this.bookClient.addBook(draw(BooksSource))
            .subscribe(_ => this.sourceData());
    }

    editBook(id: number, title: string, author:string, year:number, price:number) {
        this.editBooksSubscription = this.bookClient.editBook({id, title, author, year, price})
            .subscribe(_ => {
                this.sourceData();
                this.modalRef.hide();
            });
    }

    deleteBook(id: number) {
        this.booksSubscription =  this.bookClient.deleteBook(id)
            .subscribe(_ => this.sourceData());
    }

    selectByAuthor(value: string) {
        this.proceedSelection(() => this.bookClient.getBooksByAuthor(value)
            .subscribe(res => this.books = res));
    }

    selectByTitlePrice(title: string, priceMax: number) {
        this.proceedSelection(() => this.bookClient.getBooksByTitle(title)
            .subscribe(res => this.books = res.filter(v => v.price <= priceMax)));
    }

    selectByPriceRange(priceFrom: number, priceTo: number) {
        this.proceedSelection(() => this.bookClient.getBooks()
            .subscribe(res => this.books = res.filter(v => v.price <= priceTo && v.price >= priceFrom)));
    }

    selectCheapestBooks() {
        this.proceedSelection(() => this.bookClient.getBooks()
            .subscribe(res => {
                const minPrice = min(res.map(v => v.price));
                return this.books = res.filter(v => v.price == minPrice);
            }));
    }

    selectOldestBooks() {
        this.proceedSelection(() => this.bookClient.getBooks()
            .subscribe(res => {
                const oldestYear = min(res.map(v => v.year));
                return this.books = res.filter(v => v.year == oldestYear);
            }));
    }

    // Последовательность действия при выборке
    proceedSelection(callback: () => Subscription) {
        this.resetData();

        this.booksSubscription = callback();

        this.modalRef!.hide();
    }

    // Отписаться и сбросить настройки сортировки
    resetData() {
        this.isOrderDescend = false;
        this.lastSorted = "Id";
        this.booksSubscription?.unsubscribe();
    }
}
