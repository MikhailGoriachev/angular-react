﻿// Данные о книге
export class Book {
    constructor(public id: number = 0,
                public title: string = "",
                public author: string = "",
                public year: number = 1900,
                public price: number = 0) {
    }
}