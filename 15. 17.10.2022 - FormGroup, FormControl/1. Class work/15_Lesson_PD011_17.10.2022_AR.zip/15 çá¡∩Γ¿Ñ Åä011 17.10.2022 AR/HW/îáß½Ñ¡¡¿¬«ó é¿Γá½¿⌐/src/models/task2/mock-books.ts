﻿import { Book } from "./book";
import { getRandomInt } from "../../util/randoms";

export const Books = [
    new Book(1, "451° по Фаренгейту", "Брэдбери Рэй", 1953,  getRandomInt(4,20) * 100),
    new Book(2, "Изучаем Java", "Бейтс Берт",2019, getRandomInt(4,20) * 100),
    new Book(3, "Программирование на JavaScript", "Васильев А.Н.", 2019,getRandomInt(4,20) * 100),
    new Book(4, "1С: Предприятие. Практическое пособие разработчика", "Радченко Н.А.", 2012,getRandomInt(4,20) * 100),
    new Book(5  ,"Путь программиста", 			"Сонмез Джон", 2016,getRandomInt(4,20) * 100),
    new Book(6  ,"Путь самурая (Хагакурэ)", 	"Цунэтомо Ямамото", 2019,getRandomInt(4,20) * 100),
    new Book(7  ,"Совершенный код", 			"Макконнелл Стив",1993,getRandomInt(4,20) * 100),
    new Book(8  ,"Искусство программирования", "Кнут Эрвин", 1968,getRandomInt(4,20) * 100),
    new Book(9  ,"Refactoring", 				"Бек Кент", 1999,getRandomInt(4,20) * 100),
    new Book(10 ,"Философия Java", 			"Эккель Брюс", 1998,getRandomInt(4,20) * 100),
    new Book(11 ,"Собачье счастье", 			"Фролова Анна",2021,getRandomInt(4,20) * 100),
    new Book(12 ,"JavaScript с нуля", 		   	"Чиннатхамби Кирупа",2021,getRandomInt(4,20) * 100),
    new Book(13 ,"Design Patterns", 			"Гамма Эрих", 1994,getRandomInt(4,20) * 100),
    new Book(14 ,"Паттерны проектирования", 	"Фриман Эрик", 2004,getRandomInt(4,20) * 100),
]