﻿// Класс Фото
export class Photo {
    constructor(public id: number | undefined,
                public title: string | undefined,
                public thumbnailUrl: string | undefined) {
    }
}
