﻿// перечисление дополнительной информации
export enum InfoState {
    // посты
    posts,

    // фото
    photo,

    // список дел
    todoList
}
