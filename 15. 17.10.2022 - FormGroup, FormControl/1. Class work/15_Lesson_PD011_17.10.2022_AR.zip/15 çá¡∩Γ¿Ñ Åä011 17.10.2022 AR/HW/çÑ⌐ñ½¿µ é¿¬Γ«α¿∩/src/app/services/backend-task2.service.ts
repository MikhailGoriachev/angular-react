import { Injectable } from '@angular/core';
import {InMemoryDbService} from "angular-in-memory-web-api";

@Injectable({
  providedIn: 'root'
})
// Объект класса Книга имеет следующие поля:
// идентификатор, название книги,
// год издания, цена, фамилия и инициалы автора
export class BackendTask2Service implements InMemoryDbService{

  constructor() { }

  createDb() {
    let booksList = [
      {id: 1, title: "Design Patterns", pubYear: 2004, price: 850, author: "Эрих Гамма"},
      {id: 2, title: "PHP 7. Самоучитель", pubYear: 2019, price: 1350, author: "Кузнецов В.М."},
      {id: 3, title: "Путь программиста", pubYear: 2007, price: 2200, author: "Джон Сонмез"},
      {id: 4, title: "Refactoring", pubYear: 1999, price: 1570, author: "Кент Бек"},
      {id: 5, title: "Pascal для всех", pubYear: 2003, price: 1250, author: "Боон К."},
      {id: 6, title: "JavaScript с нуля", pubYear: 2021, price: 2050, author: "Чиннатхамби Кирупа"},
      {id: 7, title: "Раздельный Django", pubYear: 2022, price: 2200, author: "Гальярди В."},
      {id: 8, title: "Изучаем Java", pubYear: 2019, price: 850, author: "Бейтс Берт"},

    ];

    return {books: booksList}
  }
}
