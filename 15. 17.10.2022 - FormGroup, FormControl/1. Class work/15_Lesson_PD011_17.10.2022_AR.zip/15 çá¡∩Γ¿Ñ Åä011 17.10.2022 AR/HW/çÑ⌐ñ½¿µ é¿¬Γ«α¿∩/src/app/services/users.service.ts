import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private http: HttpClient) { }

  // получить коллекцию пользователей
  getDataUsers(){
    // Запрос на удаленный сервер
    return this.http.get('https://jsonplaceholder.typicode.com/users')
  }

  // вывести все посты пользователя
  getUserPosts(id: number){
    return this.http.get(`https://jsonplaceholder.typicode.com/users/${id}/posts`)
  }

  // вывести фото из альбома пользователя
  getUserPhotos(id: number){
    return this.http.get(`https://jsonplaceholder.typicode.com/albums/${id}/photos`)
  }

  // вывести список дел пользователя
  getUserTodos(id: number){
    return this.http.get(`https://jsonplaceholder.typicode.com/users/${id}/todos`)
  }

} // class UsersService
