import { Component, OnInit } from '@angular/core';
import {BookTask2Service} from "../services/book-task2.service";
import {Book} from "../../models/book";

@Component({
  selector: 'app-task02',
  templateUrl: './task02.component.html'
})
export class Task02Component implements OnInit {

  books: Book[] | undefined
  // коллекция для отображения
  booksView: Book[] | undefined

  constructor(private bookService: BookTask2Service) { }

  ngOnInit(): void {
    // получить коллекцию данных
    this.getBooks();
  }

  // получить коллекцию данных
  getBooks(){
    this.bookService.getItems().subscribe(data => {
      this.books = data as Book[];
      this.booksView = this.books
    })
  }

  // Вывести книги с заданным автором. Выводить название и год издания книги
  // Вывести книги, в названии которых содержится заданная подстрока и цена не превышает заданного значения
  // Вывести название, автора книг, цена на которые попадает в заданный диапазон значений, выбранные книги упорядочить по автору
  // Самые недорогие книги
  selectByMinCost(){
    let minPrice = Math.min(...this.books!.map(b => b.price));
    this.booksView = this.books!.filter(book => book.price === minPrice);
  }

  // Самые старые книги
  selectByOldest(){
    let minPubYear = Math.min(...this.books!.map(b => b.pubYear));
    this.booksView = this.books!.filter(book => book.pubYear === minPubYear);
  }

  // Упорядочить книги по убыванию цены
  sortedByPriceDesc(){
    this.booksView = this.books?.sort((a, b) => b.price - a.price)
  }

  // Упорядочить книги по автору
  sortedByAuthor(){
    this.booksView = this.books?.sort((a, b) => a.author.localeCompare(b.author))
  }

  // Упорядочить книги по названию
  sortedByTitle(){
    this.booksView = this.books?.sort((a, b) => a.title.localeCompare(b.title))
  }


}
