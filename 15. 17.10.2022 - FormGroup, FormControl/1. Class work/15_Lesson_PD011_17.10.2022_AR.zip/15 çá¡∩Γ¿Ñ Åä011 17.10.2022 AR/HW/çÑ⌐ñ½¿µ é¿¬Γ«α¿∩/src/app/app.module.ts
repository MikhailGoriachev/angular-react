import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from "@angular/forms";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainComponent } from './main/main.component';
import {RouterLinkWithHref, RouterOutlet} from "@angular/router";
import { Task01Component } from './task01/task01.component';
import {CommonModule} from "@angular/common";
import {HttpClientModule} from "@angular/common/http";
import { Task02Component } from './task02/task02.component';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import {BackendTask2Service} from "./services/backend-task2.service";


@NgModule({
  declarations: [
    AppComponent,
    MainComponent,
    Task01Component,
    Task02Component,

  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    RouterOutlet,
    RouterLinkWithHref,
    CommonModule,
    HttpClientModule,
    // Раскомментировать для корректной работы Задачи 2
    InMemoryWebApiModule.forRoot(BackendTask2Service)

  ],
  // регистрация сервисов
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
