import { Component, OnInit } from '@angular/core';
import {UsersService} from "../services/users.service";

@Component({
  selector: 'app-task01',
  templateUrl: './task01.component.html'
})
export class Task01Component implements OnInit {

  constructor(private userService: UsersService) { }

  users: any
  posts : any
  photos: any
  todos:any
  edited: boolean = false


  ngOnInit(): void {
    // обращение к серверу и подписка на получение результата
    this.userService.getDataUsers()
      .subscribe(res => { this.users = res })

  }

  userInitialize(){
  this.edited = false
    this.userService.getDataUsers()
      .subscribe(res => { this.users = res })
  }

  // все посты пользователя
  userPosts(id: number){
    this.edited = true
    this.userService.getUserPosts(id)
      .subscribe(res => { this.posts = res})
  }

  // фото из альбома пользователя
  userPhotos(id: number){
    this.edited = true
    this.userService.getUserPosts(id)
      .subscribe(res => { this.photos = res})
  }

  // список дел пользователя
  userTodos(id: number){
    this.edited = true
    this.userService.getUserPosts(id)
      .subscribe(res => { this.todos = res})
  }



}
