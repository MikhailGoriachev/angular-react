// Класса Книга имеет следующие поля:
// идентификатор,
// название книги,
// год издания,
// цена,
// фамилия и инициалы автора
export class Book{
  constructor(public id: number, public title: string,
              public author: string, public pubYear: number,
              public price: number) {
  }
}
