// Класс Пользователь поля:
// id, name,
// username,
// email,
// phone,
// website

export class User{
  constructor(public id: number, public name: string,
              public username: string, public email: string,
              public phone: string, public website: string) {
  }
}
