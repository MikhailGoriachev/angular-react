import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { arrowDown, arrowUp, NgxBootstrapIconsModule } from "ngx-bootstrap-icons";

import { ListComponent, ListItemDirective } from "./list/list.component";



@NgModule({
  declarations: [
    ListComponent,
    ListItemDirective
  ],
  exports: [
    ListComponent,
    ListItemDirective
  ],
  imports: [
    CommonModule,
    NgxBootstrapIconsModule.pick({
      arrowDown,
      arrowUp
    }),
    ReactiveFormsModule,
  ]
})
export class SharedModule { }
