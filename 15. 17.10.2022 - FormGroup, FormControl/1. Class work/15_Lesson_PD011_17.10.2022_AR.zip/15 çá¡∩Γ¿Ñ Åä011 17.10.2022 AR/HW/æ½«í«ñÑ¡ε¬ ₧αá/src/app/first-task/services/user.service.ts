import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";


export type User = {
  id: number,
  username: string,
  email: string,
  phone: string,
  website: string;
};


export type Post = {
  id: number,
  title: string,
  body: string;
};


export type Album = {
  id: number,
  title: string;
};


export type Photo = {
  title: string,
  url: string;
};


export type Todo = {
  id: number,
  title: string,
  completed: boolean;
};


@Injectable()
export class UserService {
  constructor(private http: HttpClient) {
  }

  getUsers() {
    return this.http.get<User[]>(`https://jsonplaceholder.typicode.com/users`);
  }

  getPosts(userId: number) {
    return this.http.get<Post[]>(`https://jsonplaceholder.typicode.com/users/${userId}/posts`);
  }

  getAlbums(userId: number) {
    return this.http.get<Album[]>(`https://jsonplaceholder.typicode.com/users/${userId}/albums`);
  }

  getPhotos(albumId: number) {
    return this.http.get<Photo[]>(`https://jsonplaceholder.typicode.com/albums/${albumId}/photos`);
  }

  getTodos(userId: number) {
    return this.http.get<Todo[]>(`https://jsonplaceholder.typicode.com/users/${userId}/todos`);
  }
}
