import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { UntilDestroy, untilDestroyed } from "@ngneat/until-destroy";
import { switchMap, tap } from "rxjs";
import { Sortables } from "src/app/shared/types";

import { Todo, UserService } from "../services/user.service";

@UntilDestroy()
@Component({
  templateUrl: './todo.component.html'
})
export class TodoComponent implements OnInit {
  todos: Todo[] = [];

  additionalStats: {
    completed: number,
    uncompleted: number,
  } | null = null;

  sortables: Sortables<Todo> = {
    title: "Заголовок",
    completed: "Статус"
  };

  constructor(
    private route: ActivatedRoute,
    private userService: UserService
  ) { }

  ngOnInit() {
    this.route.params
      .pipe(
        untilDestroyed(this),
        switchMap(params => this.userService.getTodos(params["id"])),
        tap(x => {
          const completed = x.filter(z => z.completed).length;

          this.additionalStats = {
            completed,
            uncompleted: x.length - completed
          };
        })
      )
      .subscribe(x => this.todos = x);
  }
}
