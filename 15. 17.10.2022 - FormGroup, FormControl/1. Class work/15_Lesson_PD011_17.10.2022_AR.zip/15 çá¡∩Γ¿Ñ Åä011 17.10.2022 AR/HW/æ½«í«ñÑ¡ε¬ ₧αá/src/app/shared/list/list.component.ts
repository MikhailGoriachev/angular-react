import { Component, ContentChild, Directive, Input, OnInit, TemplateRef } from "@angular/core";
import { FormBuilder } from "@angular/forms";
import { UntilDestroy, untilDestroyed } from "@ngneat/until-destroy";
import * as _ from "lodash";

import { Sortables } from "../types";


type ListItemTemplateContext<T> = {
  $implicit: T;
};


@Directive({
  selector: 'ng-template[list-item]'
})
export class ListItemDirective<T> {
  @Input("list-item") item!: T[];

  static ngTemplateContextGuard<TContext>(
    directive: ListItemDirective<TContext>,
    context: unknown
  ): context is ListItemTemplateContext<TContext> {
    return true;
  }
}


@UntilDestroy()
@Component({
  selector: 'app-list[items]',
  templateUrl: './list.component.html'
})
export class ListComponent<T extends { id: unknown; }> implements OnInit {
  @Input()
  items!: T[];

  @Input()
  sortables?: Sortables<T>;

  @ContentChild(ListItemDirective, { read: TemplateRef })
  listItem: TemplateRef<T> | null = null;

  optionsForm = this.fb.group({
    prop: this.fb.control<keyof T>("id"),
    order: this.fb.control<boolean>(true)
  });

  constructor(
    private fb: FormBuilder
  ) { }

  ngOnInit(): void {
    this.optionsForm.valueChanges
      .pipe(untilDestroyed(this))
      .subscribe(x => this.sort(x.prop ?? "id", x.order ? "asc" : "desc"));
  }

  sort(prop: keyof T, order: "asc" | "desc") {
    if (prop === "id")
      order = "asc";

    this.items = _.orderBy(this.items, [prop], [order]);
  }

  toggle() {
    this.optionsForm.patchValue({ order: !this.optionsForm.value.order });
  }
}
