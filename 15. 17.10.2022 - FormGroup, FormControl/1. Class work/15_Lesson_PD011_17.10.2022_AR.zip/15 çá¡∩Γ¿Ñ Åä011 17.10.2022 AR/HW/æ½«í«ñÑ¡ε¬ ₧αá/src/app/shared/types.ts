export type Sortables<T> = {
    [Key in keyof T]?: string
};