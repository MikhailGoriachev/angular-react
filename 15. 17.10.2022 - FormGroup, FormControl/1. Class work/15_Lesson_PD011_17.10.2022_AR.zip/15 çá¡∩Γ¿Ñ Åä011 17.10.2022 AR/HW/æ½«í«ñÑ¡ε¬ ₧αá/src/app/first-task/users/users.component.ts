import { Component, OnInit } from "@angular/core";
import { UntilDestroy, untilDestroyed } from "@ngneat/until-destroy";
import { Sortables } from "src/app/shared/types";

import { User, UserService } from "../services/user.service";


@UntilDestroy()
@Component({
  templateUrl: './users.component.html'
})
export class UsersComponent implements OnInit {
  users: User[] = [];

  sortables: Sortables<User> = {
    username: "Имя пользователя"
  };

  constructor(
    private userService: UserService
  ) { }

  ngOnInit() {
    this.userService.getUsers()
      .pipe(untilDestroyed(this))
      .subscribe(x => this.users = x);
  }
}
