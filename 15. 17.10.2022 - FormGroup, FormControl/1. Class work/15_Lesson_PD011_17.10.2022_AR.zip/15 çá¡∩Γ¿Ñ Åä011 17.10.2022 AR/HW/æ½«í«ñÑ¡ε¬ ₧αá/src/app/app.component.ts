import { Component } from "@angular/core";

import { visibleRoutes } from "../constants";


@Component({
    selector: "app-root",
    templateUrl: "./app.component.html"
})
export class AppComponent {
    routes = visibleRoutes;
}