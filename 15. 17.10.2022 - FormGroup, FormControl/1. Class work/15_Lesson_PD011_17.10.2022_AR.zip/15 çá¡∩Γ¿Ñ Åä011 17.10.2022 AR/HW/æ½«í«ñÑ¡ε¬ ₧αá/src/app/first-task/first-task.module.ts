import { CommonModule } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { routes } from "src/constants";

import { SharedModule } from "../shared/shared.module";
import { AlbumComponent } from "./album/album.component";
import { DescriptionComponent } from "./description/description.component";
import { PostComponent } from "./post/post.component";
import { UserService } from "./services/user.service";
import { UsersComponent } from "./users/users.component";
import { TodoComponent } from './todo/todo.component';



@NgModule({
  declarations: [
    DescriptionComponent,
    UsersComponent,
    PostComponent,
    AlbumComponent,
    TodoComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes),
    SharedModule,
    HttpClientModule,
    NgbModule
  ],
  providers: [
    UserService
  ]
})
export class FirstTaskModule { }
