import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { UntilDestroy, untilDestroyed } from "@ngneat/until-destroy";
import { forkJoin, map, switchAll, switchMap } from "rxjs";

import { Album, Photo, UserService } from "../services/user.service";


@UntilDestroy()
@Component({
  templateUrl: './album.component.html'
})
export class AlbumComponent implements OnInit {
  items: {
    album: Album,
    photos: Photo[];
  }[] = [];

  constructor(
    private route: ActivatedRoute,
    private userService: UserService
  ) { }

  ngOnInit() {
    this.route.params
      .pipe(
        untilDestroyed(this),
        switchMap(params => this.userService.getAlbums(params["id"])),
        switchAll(),
        switchMap(album => forkJoin([this.userService.getPhotos(album.id).pipe(
          map(photos => ({ album, photos }))
        )])),
      )
      .subscribe(x => this.items = x);
  }
}
