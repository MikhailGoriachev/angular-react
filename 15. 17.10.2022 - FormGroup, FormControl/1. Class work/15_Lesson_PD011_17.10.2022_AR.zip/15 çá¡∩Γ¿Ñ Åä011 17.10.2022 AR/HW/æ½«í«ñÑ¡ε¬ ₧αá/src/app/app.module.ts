import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { RouterModule } from "@angular/router";

import { routes } from "../constants";
import { AppComponent } from "./app.component";
import { FirstTaskModule } from "./first-task/first-task.module";
import { HomeComponent } from "./home/home.component";


@NgModule({
    declarations: [
        AppComponent,
        HomeComponent,
    ],
    imports: [
        RouterModule.forRoot(routes),
        BrowserModule,
        FirstTaskModule,
    ],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule {
}
