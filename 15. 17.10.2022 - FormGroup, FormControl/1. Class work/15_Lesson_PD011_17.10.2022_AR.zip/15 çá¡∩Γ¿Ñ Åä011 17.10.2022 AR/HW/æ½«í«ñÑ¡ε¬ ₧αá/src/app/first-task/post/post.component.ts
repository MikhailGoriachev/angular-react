import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { UntilDestroy, untilDestroyed } from "@ngneat/until-destroy";
import * as _ from "lodash";
import { switchMap, tap } from "rxjs";
import { Sortables } from "src/app/shared/types";

import { Post, UserService } from "../services/user.service";


@UntilDestroy()
@Component({
  templateUrl: './post.component.html'
})
export class PostComponent implements OnInit {
  posts: Post[] = [];

  additionalStats: {
    count: number,
    minBody: number,
    avgBody: number,
    maxBody: number;
  } | null = null;

  sortables: Sortables<Post> = {
    title: "Заголовок",
    body: "Текст"
  };

  constructor(
    private route: ActivatedRoute,
    private userService: UserService
  ) { }

  ngOnInit() {
    this.route.params
      .pipe(
        untilDestroyed(this),
        switchMap(params => this.userService.getPosts(params["id"])),
        tap(x => this.additionalStats = {
          count: x.length,
          minBody: _.minBy(x, z => z.body)?.body.length ?? 0,
          avgBody: _.meanBy(x, z => z.body.length),
          maxBody: _.maxBy(x, z => z.body)?.body.length ?? 0
        })
      )
      .subscribe(x => this.posts = x);
  }
}
