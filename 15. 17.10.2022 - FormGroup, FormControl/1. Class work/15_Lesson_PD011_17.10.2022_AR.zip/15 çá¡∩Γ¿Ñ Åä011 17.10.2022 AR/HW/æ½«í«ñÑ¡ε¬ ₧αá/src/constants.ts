import { Route, Routes } from "@angular/router";

import { AlbumComponent } from "./app/first-task/album/album.component";
import { DescriptionComponent } from "./app/first-task/description/description.component";
import { PostComponent } from "./app/first-task/post/post.component";
import { TodoComponent } from "./app/first-task/todo/todo.component";
import { UsersComponent } from "./app/first-task/users/users.component";
import { HomeComponent } from "./app/home/home.component";


export const tasks = [
    { descriptionComponent: DescriptionComponent }
];


export const visibleRoutes: Pick<Route, "path" | "title">[] = [
    { path: "", title: "Описание" },
    { path: "users", title: "Пользователи" }
];


export const routes: Routes = [
    { component: HomeComponent, path: "", title: "Описание" },
    { component: UsersComponent, path: "users", title: "Пользователи" },
    { component: PostComponent, path: "users/posts/:id", title: "Посты" },
    { component: TodoComponent, path: "users/todos/:id", title: "Дела" },
    { component: AlbumComponent, path: "users/albums/:id", title: "Альбомы" },
    { path: "**", redirectTo: "/" }
];