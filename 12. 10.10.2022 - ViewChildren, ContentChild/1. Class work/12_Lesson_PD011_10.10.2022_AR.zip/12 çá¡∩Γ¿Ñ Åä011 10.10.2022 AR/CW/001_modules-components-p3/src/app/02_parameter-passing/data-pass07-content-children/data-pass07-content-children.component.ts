import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-pass07-content-children',
  templateUrl: './data-pass07-content-children.component.html'
})
export class DataPass07ContentChildrenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
