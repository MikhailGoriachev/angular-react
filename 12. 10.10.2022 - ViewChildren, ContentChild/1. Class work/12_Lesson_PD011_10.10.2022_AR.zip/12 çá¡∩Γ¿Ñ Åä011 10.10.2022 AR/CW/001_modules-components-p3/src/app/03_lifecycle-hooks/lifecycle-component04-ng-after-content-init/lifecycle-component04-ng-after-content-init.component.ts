import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lifecycle-component04-ng-after-content-init',
  templateUrl: './lifecycle-component04-ng-after-content-init.component.html'
})
export class LifecycleComponent04NgAfterContentInitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
