import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-descendant',
  templateUrl: './descendant.component.html',
  styleUrls: ['./descendant.component.css'],
})
export class DescendantComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
