// оценка студента: предмет, уровень знаний (0, .., 12)
export class Mark {
  constructor(private _subject: string = "Информатика", private _level: number = 0) { }

  get subject(): string { return this._subject; }
  set subject(value: string) {
    this._subject = value;
  }

  get level(): number { return this._level; }
  set level(value: number) {
    this._level = 0 <= value && value <= 5?value:this._level;
  }
} // class Mark
