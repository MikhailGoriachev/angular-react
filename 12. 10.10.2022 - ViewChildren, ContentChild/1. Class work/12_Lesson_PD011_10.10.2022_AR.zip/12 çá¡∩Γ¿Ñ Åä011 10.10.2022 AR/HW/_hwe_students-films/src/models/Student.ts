import {Mark} from "./Mark";
import {getIntRand} from "../infrastructure/utils";

// Класс Student- сведения о студенте
// • фамилия и инициалы;
// • пол студента;
// • фотография студента (заранее подготовленные файлы, с именами man001,
//   woman001 и т.д. Имя файла генерируется в зависимости от пола студента);
// • название группы;
// • успеваемость (массив из пяти элементов типа Mark)
export class Student {
  constructor(
    private _fullName: string, public gender: boolean,
    private _photo: string, public group: string,
    private _marks: Mark[]) {
  } // constructor

  get fullName(): string { return this._fullName; }
  set fullName(value: string) {
    this._fullName = value;
  }

  get photo(): string {  return this._photo; }
  get marks(): Mark[] {  return this._marks; }

  // свойство для получения средней оценки студента
  get avgMark(): number {
     return this._marks
       .map(m => m.level)
       .reduce((acc, level) => acc + level, 0) / this._marks.length;
  } // avgMark

  // метод для генерации данных студента
  static generate(): Student {
    // набор мужских фамилий
    let maleFullNames = [
      'Иванов И.И.',   'Петров П.п.',    'Федоров Ф.Ф.', 'Васильев В.В.', 'Сергеев С.С.',
      'Михайлов М.М.', 'Тарасов Т.Т.',   'Павлов П.П.',  'Николаев Н.Н.', 'Сидоров С.С.',
      'Яворский Я.Я.', 'Юрковский Ю.В.', 'Шабанов Р.А.', 'Макаров В.А.',  'Ивановский А.В.'
    ];

    // набор женских фамилий
    let femaleFullNames = [
      'Иванова Б.Ю.',   'Петрова П.п.',   'Федорова Ф.Ф.', 'Васильева В.В.', 'Сергеева П.К.',
      'Михайлова В.И.', 'Тимофеева Т.Т.', 'Павлов П.П.',   'Николаев Н.Н.',  'Сидорова Ю.В.',
      'Яворская К.В.',  'Юрковская В.А.', 'Шабанова Р.А.', 'Макарова Т.В.',  'Ивановская И.А.'
    ];

    // шаблоны генерации массивов оценок
    let marks: Mark[][] = [
       [new Mark('OOP C++', 4), new Mark('DP', 5), new Mark('C#', 5),
        new Mark('DT', 4), new Mark('WPF', 4)],
       [new Mark('OOP C++', 4), new Mark('DP', 3), new Mark('C#', 4),
        new Mark('DT', 3), new Mark('WPF', 3)],
       [new Mark('OOP C++', 2), new Mark('DP', 3), new Mark('C#', 3),
        new Mark('DT', 3), new Mark('WPF', 3)],
       [new Mark('OOP C++', 5), new Mark('DP', 4), new Mark('C#', 4),
        new Mark('DT', 2), new Mark('WPF', 2)],
       [new Mark('OOP C++', 4), new Mark('DP', 2), new Mark('C#', 4),
        new Mark('DT', 2), new Mark('WPF', 3)]
    ];

    // группы
    let groups = ['СУ1-35', 'СУ2-35', 'СД1-35', 'СД2-35', 'СВ1-35', 'СВ2-35'];

    let indexFullName = getIntRand(0, maleFullNames.length-1);
    let indexMarks = getIntRand(0, marks.length-1);
    let indexGroup = getIntRand(0, groups.length-1);

    let gender = getIntRand(0, 1) === 1;
    let fullName = gender?maleFullNames[indexFullName]:femaleFullNames[indexFullName];
    let photo = gender?'':'wo' + 'man' + getIntRand(1, 10).toString().padStart(3, '0');

    return new Student(fullName, gender, photo, groups[indexGroup], marks[indexMarks]);
  } // generate
} // class Student
