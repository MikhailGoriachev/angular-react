// фильм описывается названием, фамилией и инициалами режиссера, жанром, годом выпуска
export class Film {
  constructor(public name: string, public producer: string, public genre: string, public year: number) {
  }
} // class Film
