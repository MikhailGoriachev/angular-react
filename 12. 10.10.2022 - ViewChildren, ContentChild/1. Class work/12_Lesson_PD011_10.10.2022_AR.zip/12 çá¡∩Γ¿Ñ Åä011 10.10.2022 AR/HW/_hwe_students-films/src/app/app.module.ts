import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

// импорт компонентов и модуля маршрутизации из index.tx
import {AppComponent, HomeComponent, StudentsComponent, FilmsComponent, NotFoundComponent} from "./index";
import {AppRoutingModule} from "./app-routing.module";

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    StudentsComponent,
    FilmsComponent,
    NotFoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule  /* подключение модуля маршрутизации  */
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
