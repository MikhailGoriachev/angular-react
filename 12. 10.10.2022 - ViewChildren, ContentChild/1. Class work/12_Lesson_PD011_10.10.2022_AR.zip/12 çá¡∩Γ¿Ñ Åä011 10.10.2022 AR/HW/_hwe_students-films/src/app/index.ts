// перечисление компонентов для экспорта
export * from "./app.component";
export * from "./home/home.component";
export * from "./students/students.component";
export * from "./films/films.component";
export * from "./not-found/not-found.component";

