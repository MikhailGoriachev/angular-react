// генерация случайного вещественного числа
export function getRand(from: number, to: number): number {
    return from + (to - from)*Math.random();
} // getRandom

// генерация случайного целого числа
export function getIntRand(from: number = 0, to: number = 5): number {
    // Math.trunc(x) - возвращает целую часть числа
    // (без округлений, просто отбрасывается дробная часть)
    return Math.trunc(getRand(from, to));
} // getIntRand
