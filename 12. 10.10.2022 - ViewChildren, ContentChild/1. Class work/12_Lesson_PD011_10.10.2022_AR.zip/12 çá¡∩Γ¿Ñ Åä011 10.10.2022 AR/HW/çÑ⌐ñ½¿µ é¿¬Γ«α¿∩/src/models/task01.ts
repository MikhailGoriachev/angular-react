/*
Описать класс Student, содержащий поля:
•	фамилия и инициалы;
•	пол студента;
•	фотография студента (заранее подготовленные файлы, с именами man001, woman001 и т.д. Имя файла генерируется в зависимости от пола студента);
•	название группы;
•	успеваемость (массив из пяти элементов типа Mark)
•	Mark – класс: название предмета, оценка
*/
import{Utils} from "../util/utils";

export class Mark {
  constructor(public subject= "",
              public grade = 0) {
  }

  toString(): string{
    return `${this.subject}: ${this.grade}`
  }

  assign(m: Mark) {
    Object.assign(this, m);
    return this;
  }
}


export class Student {
  constructor(public id: number, public  fullName: string,
              public gender: boolean, public photoImg: string,
              public group: string, public marks: Mark[]) {
  }

  get avgGrade() {
    return this.marks.map(m => m.grade).reduce((acc, cur) => acc + cur, 0) / this.marks.length
  }

  assign(s: Student) {
    Object.assign(this, s);
    this.marks = this.marks.map(m => new Mark().assign(m));
    return this;
  }
}


export class Academy{
  static getStudents(){
    return [
      new Student(1, "Рымарь О.А.", true, "man005.jpg", "РН004", this.getMarks()),
      new Student(2, "Воронцов И.А.", true, "man004.jpg", "ЕН008", this.getMarks()),
      new Student(3, "Романова П.В.", false, "woman006.jpg", "РН004", this.getMarks()),
      new Student(4, "Рогов Э.Э.", true, "man006.jpg", "ПД009", this.getMarks()),
      new Student(5, "Горбовский Д.В.", true, "man008.jpg", "ЕН008", this.getMarks()),
      new Student(6, "Жукова Р.Б.", false, "woman004.jpg", "ПД009", this.getMarks()),
      new Student(7, "Кондратьев М.Ю.", true, "man001.jpg", "ЕН008", this.getMarks()),
      new Student(8, "Василенко В.Ю.", true, "man003.jpg", "РН004", this.getMarks()),
      new Student(9, "Беляков К.В.", true, "man009.jpg", "ЕН008", this.getMarks()),
      new Student(10, "Комаров О.А.", true, "man002.jpg", "ПД009", this.getMarks()),
    ]
  }

  static getMarks(){
    return [
      new Mark("ADO.NET", Utils.getInt(4, 5)),
      new Mark("Теория БД", Utils.getInt(2, 5)),
      new Mark("3D Max", Utils.getInt(3, 5)),
      new Mark("Паттерны", Utils.getInt(2, 5)),
      new Mark("C Starter", Utils.getInt(3, 6)),
    ]
  }
}
