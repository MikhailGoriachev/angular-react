// Класс Фильм описывается
// названием,
// фамилией и инициалами режиссера,
// жанром,
// годом выпуска

export class Film{
  constructor(public id: number, public nameFilm: string, public fullName: string,
              public genre: string, public yearRelease: number) {
  }

  assign(film: Film) {
    Object.assign(this, film);
    return this;
  }
}


export class VideoLibrary{
  static getFilms(){
    return [
      new Film(1, "Отрочество", "Линклейтер P.", "драма", 2010),
      new Film(2, "Мальчишник в Вегасе", "Филлипс Т.", "комедия", 2009),
      new Film(3, "Статский советник", "Янковский Ф.", "драма", 2005),
      new Film(4, "Брат Баджранги", "Кхан К.", "комедия", 2015),
      new Film(5, "Нефть", "Андерсон Т.", "драма", 2007),
      new Film(6, "Батя", "Ефимович Д.", "комедия", 2020),
      new Film(7, "Мы - Миллеры", "Тёрбер М.", "комедия", 2013),
      new Film(8, "Безумные соседи", "Шоврон Ф.", "комедия", 2017),
      new Film(9, "Отель «Гранд Будапешт»", "Андерсон У.", "детектив", 2014),
      new Film(10, "Рашн Юг", "Федотов А.П.", "комедия", 2021),
    ]
  }


}
