import { Component, OnInit } from '@angular/core';
import {Film, VideoLibrary} from "../../models/task02";

@Component({
  selector: 'app-task2',
  templateUrl: './task2.component.html',
  styleUrls: ['./task2.component.css']
})
export class Task2Component implements OnInit {

  // отображаемая коллекция
  films: Film[]

  // исходная коллекция
  source: Film[]

  // список жанра для выборки
  genre: Array<string>

  // список режиссёров для выборки
  fullName: Array<string>

  constructor() {
    this.source = VideoLibrary.getFilms()
    this.films = this.source

    // получить список жанра фильмов
    this.genre = [...new Set(this.source.map(s => s.genre))]

    // получить список режиссёров фильмов
    this.fullName = [...new Set(this.source.map(s => s.fullName))]
  }

  ngOnInit(): void {
  }


  showFilms(){
    this.films = this.source
  }

	// Выбор записи с заданным жанром
  selectByGenre(genreSelect: HTMLSelectElement){
    this.films = this.source.filter(f => f.genre === genreSelect.value)
  }

	// Выбор записи с заданным режиссером
  selectByProducer(producerSelect: HTMLSelectElement){
    this.films = this.source.filter(f => f.fullName === producerSelect.value)
  }

	// Выбор записи с заданным годом выпуска
  selectByYear(yearRelease: HTMLInputElement){
    let yearValue = Number.parseInt(yearRelease.value)

    this.films = this.source.filter(f => f.yearRelease === yearValue)
  }


} // class Task2Component
