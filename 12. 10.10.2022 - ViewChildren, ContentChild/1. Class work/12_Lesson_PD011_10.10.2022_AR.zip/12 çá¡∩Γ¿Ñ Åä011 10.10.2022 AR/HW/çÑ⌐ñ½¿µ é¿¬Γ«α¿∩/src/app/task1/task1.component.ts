import { Component, OnInit } from '@angular/core';
import {Mark, Student, Academy} from "../../models/task01";

@Component({
  selector: 'app-task1',
  templateUrl: './task1.component.html',
  styleUrls: ['./task1.component.css']
})
export class Task1Component implements OnInit {

  // отображаемая коллекция
  students: Student[]

  // исходная коллекция
  source: Student[]

  // список групп для выборки
  group: Array<string>

  // предикат для выделения записи
  selected = (student: Student) => false


  constructor() {
    this.source = Academy.getStudents()
    this.students = this.source

    // получить список групп
    this.group = [...new Set(this.source.map(s => s.group))]
  }

  ngOnInit(): void {
  }

  showAcademy(){
    this.students = this.source
  }


  // Выделение студентов, имеющих хотя бы одну оценку 2
  selectByGrade2(){
    this.selected = (s) => s.marks.some(m => m.grade === 2)
  }

  // Удаление студента из коллекции
  removeStudent(id: number){
    let index = this.source.findIndex(s => +s.id === +id)
    if(index > -1)
      this.source.splice(index, 1)
  }


  // Добавление студента в коллекцию
  addStudent(){
    let id = this.source.length
    id++
    let student = new Student(id, "Иванов О.А.", true, "man010.jpg", "ПД009", Academy.getMarks())
    this.source.push(student)
    this.students = this.source
  }


  // Выделение студентов, имеющих оценки 4 и 5
  selectByGrade4and5(){
    this.selected = (s) => s.marks.some(m => m.grade === 4 || m.grade === 5)
  }

  // Выделение студентов заданной группы
  selectByGroup(groupSelect: HTMLSelectElement) {
    this.selected = (s: Student) => s.group === groupSelect.value;
  }


  // Упорядочивание по возрастанию среднего балла
  sortedByAvgGrade() {
    this.students = this.source.slice().sort((a, b) => a.avgGrade - b.avgGrade)
  }

  // Упорядочивание по фамилиям и инициалам
  sortedByFullName(){
    this.students = this.source.slice().sort((a, b) => a.fullName.localeCompare(b.fullName));
  }

  // Упорядочивание по названию группы
  sortedByGroup(){
    this.students = this.source.slice().sort((a, b) => a.group.localeCompare(b.group));
  }

} // class Task1Component
