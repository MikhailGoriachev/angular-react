import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MoviesComponent } from './movies/movies.component';
import { MoviesTableComponent } from './movies-table/movies-table.component';
import { NgxBootstrapIconsModule } from "ngx-bootstrap-icons";

@NgModule({
  declarations: [
    MoviesComponent,
    MoviesTableComponent
  ],
  imports: [
    CommonModule,
    NgxBootstrapIconsModule
  ]
})
export class MovieLibraryModule { }
