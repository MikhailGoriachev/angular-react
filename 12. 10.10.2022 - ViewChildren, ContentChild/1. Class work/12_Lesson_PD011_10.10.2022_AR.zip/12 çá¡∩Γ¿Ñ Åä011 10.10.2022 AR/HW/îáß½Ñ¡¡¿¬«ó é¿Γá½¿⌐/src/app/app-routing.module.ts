import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from "./home/home.component";
import { StudentsComponent } from "./academy/students/students.component";
import { MoviesComponent } from "./movie-library/movies/movies.component";

export const routes: Routes = [
    { path: '', component: HomeComponent, data: { title: 'Главная' } },
    { path: 'students', component: StudentsComponent, data: { title: 'Студенты' } },
    { path: 'movies', component: MoviesComponent, data: { title: 'Фильмы' } },
    { path: '**', redirectTo: '/' },
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule {
    
}
