import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudentsComponent } from './students/students.component';
import { NgxBootstrapIconsModule } from "ngx-bootstrap-icons";
import { StTableComponent } from './st-table/st-table.component';

@NgModule({
  declarations: [
    StudentsComponent,
    StTableComponent
  ],
  imports: [
    CommonModule,
    NgxBootstrapIconsModule
  ]
})
export class AcademyModule { }
