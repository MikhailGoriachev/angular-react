import { Component, OnInit } from '@angular/core';
import { Academy } from "../../../models/task1/academy";
import { StudentsFactory } from "../../../models/task1/studentsFactory";
import { Student } from "../../../models/task1/student";

@Component({
    selector: 'app-students',
    templateUrl: './students.component.html',
    styleUrls: ['./students.component.css']
})
export class StudentsComponent implements OnInit {
    private readonly storageKey: string = "mv_academy";

    academy: Academy = new Academy();

    displayStudents: Student[];

    isSelected: (s: Student) => boolean = (_: Student) => false;

    constructor() {
        if (!this.academy.load(this.storageKey)) {
            this.academy.init().store(this.storageKey);
        }

        this.displayStudents = this.academy.students;
    }

    ngOnInit(): void {
    }

    selectByGroup(value: string) {
        this.isSelected = (s: Student) => s.group == value;
    }

    selectByMarks(value: string) {
        this.isSelected = (s: Student) => value.split(',')
            .every(v => s.marks.some(m => m.grade == +v));
    }

    addStudent() {
        this.academy.add(StudentsFactory.generateStudent(this.academy.nextId()));
        this.academy.store(this.storageKey);
    }

    removeStudent(id: number) {
        this.academy.remove(id);
        this.academy.store(this.storageKey);
    }

    sourceData() {
        this.isSelected = _ => false;
    }
}
