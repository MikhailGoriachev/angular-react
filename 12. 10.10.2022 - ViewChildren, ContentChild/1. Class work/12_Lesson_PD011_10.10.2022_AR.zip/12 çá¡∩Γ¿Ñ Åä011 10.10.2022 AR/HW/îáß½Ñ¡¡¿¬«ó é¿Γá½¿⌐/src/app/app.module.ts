import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HomeComponent } from './home/home.component';

import { NgxBootstrapIconsModule } from "ngx-bootstrap-icons";
import { arrowDownShort, arrowUpShort, recycle, trashFill, plusCircle } from "ngx-bootstrap-icons";
import { AcademyModule } from "./academy/academy.module";
import { MovieLibraryModule } from "./movie-library/movie-library.module";

const icons = { arrowDownShort, arrowUpShort, recycle, plusCircle, trashFill };

@NgModule({
    declarations: [
        AppComponent,
        HomeComponent,
        HeaderComponent,
        FooterComponent,
        NavbarComponent,
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        AcademyModule,
        MovieLibraryModule,
        NgxBootstrapIconsModule.pick(icons)
    ],
    providers: [],
    bootstrap: [AppComponent]
})

export class AppModule {
}
