import { Component, Input, OnInit } from '@angular/core';
import { sortBy } from "../../../util/array";
import { IconNamesEnum } from "ngx-bootstrap-icons";
import { Movie } from "../../../models/task2/movie";


@Component({
  selector: 'app-movies-table',
  templateUrl: './movies-table.component.html',
  styleUrls: ['./movies-table.component.css']
})
export class MoviesTableComponent implements OnInit {
  iconNames = IconNamesEnum;

  @Input() movies: Movie[] = [];

  // настройка колонок
  columns = [
    { name: 'Id',         sortProp: (m: Movie) => m.id },
    { name: 'Название',   sortProp: (m: Movie) => m.title },
    { name: 'Режиссер',   sortProp: (m: Movie) => m.director },
    { name: 'Жанр',       sortProp: (m: Movie) => m.genre },
    { name: 'Год выхода', sortProp: (m: Movie) => m.year },
  ];

  isOrderDescend: boolean = false;   // текущий порядок сортировки в таблице   
  lastSorted: string = "Id";         // последний сортированный столбец
  
  constructor() { }

  ngOnInit(): void {
  }
  

  // сортировка таблицы
  onOrderChanged(name: string, property: (s: Movie) => number | string) {

    if (name == this.lastSorted)
      this.isOrderDescend = !this.isOrderDescend;

    this.lastSorted = name;

    sortBy(this.movies, property, this.isOrderDescend);
  }
}
