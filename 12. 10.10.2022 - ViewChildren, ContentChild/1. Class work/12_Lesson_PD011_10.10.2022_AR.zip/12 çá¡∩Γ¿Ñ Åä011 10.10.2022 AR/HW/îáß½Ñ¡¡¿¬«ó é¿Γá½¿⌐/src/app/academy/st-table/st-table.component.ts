import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Student } from "../../../models/task1/student";
import { IconNamesEnum } from "ngx-bootstrap-icons";
import { sortBy } from "../../../util/array";

@Component({
    selector: 'app-st-table',
    templateUrl: './st-table.component.html',
    styleUrls: ['./st-table.component.css']
})
export class StTableComponent implements OnInit {
    iconNames = IconNamesEnum;

    @Input() students: Student[] = [];
    @Input() academyTitle: string = "";
    @Input() isSelected: (s: Student) => boolean = (_: Student) => false;

    @Output() onAddStudent = new EventEmitter();
    @Output() onRemoveStudent: EventEmitter<number> = new EventEmitter();

    // настройка колонок
    columns = [
        { name: 'Id', sortProp: (s: Student) => s.id },
        { name: 'Фото', sortProp: null },
        { name: 'Фамилия И.О.', sortProp: (s: Student) => s.fullName },
        { name: 'Пол', sortProp: (s: Student) => s.gender },
        { name: 'Группа', sortProp: (s: Student) => s.group },
        { name: 'Оценки', sortProp: null },
        { name: 'Ср. балл', sortProp: (s: Student) => s.avgGrade },
    ];

    isOrderDescend: boolean = false;   // текущий порядок сортировки в таблице   
    lastSorted: string = "Id";         // последний сортированный столбец


    constructor() {
    }

    ngOnInit(): void {
    }


    addStudent() {
        this.onAddStudent.emit();
    }
    
    removeStudent(id: number) {
        this.onRemoveStudent.emit(id);
    }


    // сортировка таблицы
    onOrderChanged(name: string, property: (s: Student) => number | string) {

        if (name == this.lastSorted)
            this.isOrderDescend = !this.isOrderDescend;

        this.lastSorted = name;

        sortBy(this.students, property, this.isOrderDescend);
    }

}
