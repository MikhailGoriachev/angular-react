﻿import { isNumber } from "radash";

export function sortBy<T extends object>(array: T[],
                                         get: (item: T) => number | string,
                                         isDescend: boolean = false) {
    array.sort((a, b) => get(a).toString()
            .localeCompare(get(b).toString(), undefined, { numeric: isNumber(get(a)) })
        * (isDescend ? -1 : 1));
}


