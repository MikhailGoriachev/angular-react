﻿
// Данные о фильме
export class Movie {
    constructor(public id = 0,
                public title = "",
                public director = "",
                public genre = "",
                public year = 1900) {
    }

    assign(o: Movie) {
        Object.assign(this, o);
        return this;
    }
}