﻿
// Данные оценки успеваемости
export class Mark {
    constructor(public subject: string= "",
                public grade: number = 0) {
    }
    
    assign(m: Mark) {
        Object.assign(this, m);
        return this;
    }
}