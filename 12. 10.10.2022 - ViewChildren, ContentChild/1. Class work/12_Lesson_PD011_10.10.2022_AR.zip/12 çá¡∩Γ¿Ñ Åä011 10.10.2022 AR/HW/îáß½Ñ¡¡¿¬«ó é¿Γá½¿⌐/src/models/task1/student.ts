﻿// Данные о студенте
import { Mark } from "./mark";
import { sum } from "radash"

export class Student {
    constructor(public id: number = 0,
                public fullName: string = "",
                public gender: string = "",
                public photo: string = "",
                public group: string = "",
                public marks: Mark[] = []) {
    }

    get avgGrade(): number {
        return sum(this.marks, m => m.grade) / this.marks.length;
    }

    assign(s: Student) {
        Object.assign(this, s);
        this.marks = this.marks.map(m => new Mark().assign(m));
        return this;
    }    
}