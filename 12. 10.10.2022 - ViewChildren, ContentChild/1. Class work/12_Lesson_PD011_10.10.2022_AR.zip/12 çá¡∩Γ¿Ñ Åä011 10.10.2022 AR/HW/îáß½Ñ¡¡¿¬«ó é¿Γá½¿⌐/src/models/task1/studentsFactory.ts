﻿import { draw, random, alphabetical } from "radash";
import { Mark } from "./mark";
import { Student } from "./student";

export class StudentsFactory {
    
    static generateCollection(size: number = 10) {
        return [...Array(size)].map((s, i) => StudentsFactory.generateStudent(i + 1));
    }

    static generateStudent(id: number) {
        return draw([StudentsFactory.generateMale, StudentsFactory.generateFemale])(id);
    }

    static generateMale(id: number, nMarks: number = 5) {
        return new Student(id, draw(StudentsFactory.maleNames), "мужской", StudentsFactory.randomMaleImg(),
            draw(StudentsFactory.groups), StudentsFactory.randomMarks(nMarks));
    }

    static generateFemale(id: number, nMarks: number = 5) {
        return new Student(id, draw(StudentsFactory.femNames), "женский", StudentsFactory.randomFemaleImg(),
            draw(StudentsFactory.groups), StudentsFactory.randomMarks(nMarks));
    }

    static randomMarks(amount: number) {
        let subjectsSet = new Set<string>();

        while (subjectsSet.size !== amount) {
            subjectsSet.add(draw(StudentsFactory.subjects));
        }

        let marks = [...subjectsSet].map(m => new Mark(m, random(2, 5)));
        return alphabetical(marks, m => m.subject);
    }

    static randomMaleImg() {
        return `man_${random(1, 20)}.jpg`;
    }

    static randomFemaleImg() {
        return `woman_${random(1, 20)}.jpg`;
    }

    static maleNames = ["Рябинин А.А.", "Николаев Ф.А.", "Федоров М.М.", "Семенов М.Д.", "Федоров Д.М.",
        "Кузнецов Г.Д.", "Коновалов И.Ф.", "Титов В.М.", "Андреев А.И.", "Никитин Л.Г.",
        "Чесноков Д.Т.", "Комаров Д.А.", "Антонов В.И.", "Баранов М.А.", "Новиков А.Р.",
        "Сорокин Д.Д.", "Никольский Д.Г.", "Дорофеев А.М.", "Булгаков М.Р.", "Васильев А.М.",
        "Осипов А.Б.", "Руднев А.Л.", "Соколов З.Ф.", "Ершов Б.С.", "Макаров А.А.",
        "Киселев М.А.", "Гаврилов И.Д.", "Белов П.И.", "Моисеев А.Г.", "Яковлев Д.А."];

    static femNames = ["Осипова В.Д.", "Крылова А.А.", "Глухова М.О.", "Филатова С.А.", "Яковлева Е.П.",
        "Михайлова В.К.", "Ерофеева С.С.", "Жданова Е.Т.", "Демина Е.И.", "Панова М.С.",
        "Тарасова Е.И.", "Коровина В.М.", "Сазонова М.Д.", "Иванова К.М.", "Королева Е.М.",
        "Пирогова С.М.", "Тимофеева В.М.", "Козырева М.С.", "Волкова В.Т.", "Коновалова К.А.",
        "Беликова В.В.", "Романова С.А.", "Суркова К.К.", "Мещерякова В.М.", "Васильева А.З.",
        "Ситникова Д.Н.", "Васильева А.М.", "Васильева С.Е.", "Булгакова А.Я.", "Ушакова К.Д."];

    static groups = ["СУ 1-35", "ППС 31-01", "ИСВ 33-03", "ПСД 2-23", "ИСД 3-17", "ЕКО 18П-86"];

    static subjects = ["IT Essential", "C Starter", "ООП C++", "C# Essential", "Design UML", "Паттерны",
        "Теория БД", "Windows 10", "Illustrator", "Photoshop", "3D Max", "Maya 3D",
        "HTML/CSS", "JavaScript", "PHP", "ADO.NET", "ASP.NET"];
}