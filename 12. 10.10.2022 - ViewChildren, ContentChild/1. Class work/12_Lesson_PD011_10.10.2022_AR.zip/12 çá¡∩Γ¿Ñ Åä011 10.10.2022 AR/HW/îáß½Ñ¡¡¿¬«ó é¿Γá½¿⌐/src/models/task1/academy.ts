﻿import { Student } from "./student";
import { unique } from "radash";
import { StudentsFactory } from "./studentsFactory";

// Учебное заведение
export class Academy {
    constructor(public students: Student[] = [],
                public title: string = "Компьютерная академия") {
    }
    
    init(students: Student[] = StudentsFactory.generateCollection()) {
        this.students = students;
        return this;
    } 

    add(student: Student) {
        this.students.push(student);
    }

    remove(id: number) {
        let index = this.students.findIndex(s => +s.id === +id);
        if (index > -1)
            this.students.splice(index, 1);
    }

    // Список групп студентов
    getGroupsList() {
        return unique(this.students.map(s => s.group));
    }
    
    // Новый доступный id
    nextId(): number {
        return Math.max(...this.students.map(s => s.id)) + 1;
    }

    // Сохранить в локальное хранилище
    store(key: string) {
        localStorage.setItem(key, JSON.stringify(this));
    }

    // Загрузить из локального хранилища
    load(key: string): boolean {
        const load = localStorage.getItem(key);
        
        if(!load) return false;
        
        const parsed = JSON.parse(load) as Academy;
        this.title = parsed.title;
        this.students = parsed.students.map((s) => new Student().assign(s));
        
        return true;
    }
}