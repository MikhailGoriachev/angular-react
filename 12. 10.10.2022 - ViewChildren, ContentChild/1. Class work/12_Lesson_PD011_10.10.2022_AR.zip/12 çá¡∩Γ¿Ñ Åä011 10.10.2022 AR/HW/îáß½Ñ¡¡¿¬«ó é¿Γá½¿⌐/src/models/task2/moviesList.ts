﻿import { unique } from "radash";
import { Movie } from "./movie";

// Коллекция фильмов
export class MoviesList {
    constructor(public movies: Movie[] = []) {
    }

    init(movies: Movie[]) {
        this.movies = movies;
        return this;
    }

    getGenres(): string[] {
        return unique(this.movies.map(v => v.genre).sort());
    }
    
    getDirectors(): string[] {
        return unique(this.movies.map(v => v.director).sort());
    }

    getYears(): number[] {
        return unique(this.movies.map(v => v.year).sort());
    }

    store(key: string) {
        localStorage.setItem(key, JSON.stringify(this.movies));
    }

    load(key: string): boolean {
        const load = localStorage.getItem(key);
        if(!load) return false;
        
        this.movies = (JSON.parse(load) as Movie[]).map((s) => new Movie().assign(s));
        
        return true;
    }
}