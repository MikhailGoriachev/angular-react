import { Component, OnInit } from '@angular/core';
import {AutoUnsubscribe} from "ngx-auto-unsubscribe-decorator";
import {Subscription} from "rxjs";
import {ActivationStart, Router} from "@angular/router";
import {routes as Routes} from "./app-routing.module";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})

export class AppComponent implements OnInit{
  title: string | undefined;
  routes = Routes.slice(0, -1);
  year: number;

  @AutoUnsubscribe()
  titleSubscription!: Subscription;

  constructor(private router: Router) {
    this.year = new Date().getFullYear();
  }
  
  ngOnInit(): void {
    this.titleSubscription = this.router.events.subscribe(data => {
      if (data instanceof ActivationStart) {
        this.title = data.snapshot.data['title'];
      }
    })
  }
}
