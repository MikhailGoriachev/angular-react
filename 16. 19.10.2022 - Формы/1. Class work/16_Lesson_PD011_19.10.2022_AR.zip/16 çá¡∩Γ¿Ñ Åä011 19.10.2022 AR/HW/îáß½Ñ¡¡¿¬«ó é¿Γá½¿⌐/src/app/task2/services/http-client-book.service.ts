import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
//import { Book } from "../../../models/task2/book";
import { Observable } from "rxjs";

export type Book = {
    id: number,
    title: string,
    author: string ,
    year: number,
    price: number
};

@Injectable()
export class HttpClientBookService {
    constructor(private http: HttpClient) {
    }

    getBooks(): Observable<Book[]> {
        return this.http.get<Book[]>('api/books');
    }
    
    getBookById(id: number): Observable<Book> {
        return this.http.get<Book>(`api/books/${id}`);
    }
    
    addBook(book: Book): Observable<Book> {
        return this.http.post<Book>('api/books', {
            title: book.title,
            author: book.author,
            price: book.price,
            year: book.year
        });
    }

    editBook(book: Book){
        return this.http.put(`api/books/${book.id}`, book);
    }

    deleteBook(id: number): Observable<Book>{
        return this.http.delete<Book>(`api/books/${id}`);
    }
    
    getAuthors(): Observable<string[]> {
        return this.http.get<string[]>('api/authors');
    }
    
    getBooksByAuthor(name: string): Observable<Book[]> {
        return this.http.get<Book[]>(`api/books?author=${name}`);
    }

    getBooksByTitle(title: string): Observable<Book[]> {
        return this.http.get<Book[]>(`api/books?title=^.*${title}.*$`);
    }
}
