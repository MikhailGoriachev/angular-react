import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {BooksComponent} from './components/books/books.component';
import {NgxBootstrapIconsModule} from "ngx-bootstrap-icons";
import {BsDropdownModule} from "ngx-bootstrap/dropdown";
import {HttpClientBookService} from "./services/http-client-book.service";
import {ReactiveFormsModule} from "@angular/forms";
import {SharedModule} from "../shared/shared.module";


@NgModule({
    declarations: [
        BooksComponent,
    ],
    imports: [
        CommonModule,
        NgxBootstrapIconsModule,
        BsDropdownModule,
        ReactiveFormsModule,
        SharedModule
    ],
    providers: [ HttpClientBookService ]
})
export class Task2Module {
}
