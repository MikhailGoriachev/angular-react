import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from "@angular/forms";
import {greaterThanValidator, requiredValidator} from "../../shared/validators";

type Result = {
    variant: string,
    arg: number,
    z1: number,
    z2: number
}

@Component({
    selector: 'app-expressions',
    templateUrl: './expressions.component.html'
})
export class ExpressionsComponent implements OnInit {

    // Данные результатов вычислений
    results = {
        v15: <Result>{ variant: "15"},
        v16: <Result>{ variant: "16"},
        v17: <Result>{ variant: "17"},
    }

    // Форма ввода параметров
    paramsForm = this.fb.group({
        b: [null, [requiredValidator, greaterThanValidator(-2)]],
        x: [null, [requiredValidator, greaterThanValidator(3)]],
        m: [null, [requiredValidator, greaterThanValidator(0)]]
    });

    constructor(private fb: FormBuilder) { }

    ngOnInit(): void {  }

    onSubmit(form: FormGroup) {
        const b = this.paramsForm.value.b!;
        const x = this.paramsForm.value.x!;
        const m = this.paramsForm.value.m!;

        let buf1: number = Math.sqrt(b ** 2 - 4);
        let buf2: number = b + 2;
        this.results.v15.z1 = (Math.sqrt(2 * b + 2 * buf1)) / (buf1 + buf2);
        this.results.v15.z2 = 1 / Math.sqrt(buf2);
        this.results.v15.arg = b;

        buf1 = Math.sqrt(x ** 2 - 9);
        this.results.v16.z1 = (x ** 2 + 2 * x - 3 + (x + 1) * buf1) / (x ** 2 - 2 * x - 3 + (x - 1) * buf1);
        this.results.v16.z2 = Math.sqrt((x + 3) / (x - 3));
        this.results.v16.arg = x;

        buf1 = 3 * m;
        buf2 = Math.sqrt(m);
        this.results.v17.z1 = Math.sqrt((buf1 + 2) ** 2 - 8 * buf1) / (3 * buf2 - 2 / buf2);
        this.results.v17.z2 = buf2;
        this.results.v17.arg = m;
    }
}
