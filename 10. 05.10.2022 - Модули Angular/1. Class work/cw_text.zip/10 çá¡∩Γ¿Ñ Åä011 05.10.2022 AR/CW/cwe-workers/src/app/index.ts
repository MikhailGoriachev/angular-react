// перечисление компонентов для экспорта
export * from "./home/home.component";
export * from "./workers-process/workers-process.component";
