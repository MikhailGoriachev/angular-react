export * from "./education/education.component";
export * from "./programing/programing.component";
export * from "./trips/trips.component";

