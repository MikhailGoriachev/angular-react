import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dl',
  templateUrl: './dl.component.html',
  styleUrls: ['./dl.component.css']
})
export class DlComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
