import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-card-notebook',
  templateUrl: './card-notebook.component.html',
  styleUrls: ['./card-notebook.component.css']
})
export class CardNotebookComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
