import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ul',
  templateUrl: './ul.component.html',
  styleUrls: ['./ul.component.css']
})
export class UlComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
