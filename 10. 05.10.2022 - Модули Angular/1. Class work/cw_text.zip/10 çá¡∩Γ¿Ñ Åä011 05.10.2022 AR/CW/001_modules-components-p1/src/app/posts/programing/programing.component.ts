import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-programing',
  templateUrl: './programing.component.html',
  styleUrls: ['./programing.component.css']
})
export class ProgramingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
