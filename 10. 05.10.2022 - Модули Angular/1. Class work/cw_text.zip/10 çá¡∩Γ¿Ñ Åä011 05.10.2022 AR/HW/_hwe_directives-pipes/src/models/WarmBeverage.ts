// Сведения о напитках, приготавливаемых в кофейне (название, объем, цена,
// признак напитка на вынос, топпер – название или строка «нет», фото
// напитка при подаче)
export class WarmBeverage {
  // название, объем, цена, признак напитка на вынос, название топпера, имя файла с фото
  // напитка при подаче
  constructor(public id: number, public name: string, public volume: number,
              public price: number, public isToGo: boolean, public topper: string,
              public image: string) {
  } // constructor
} // class WarmBeverage
