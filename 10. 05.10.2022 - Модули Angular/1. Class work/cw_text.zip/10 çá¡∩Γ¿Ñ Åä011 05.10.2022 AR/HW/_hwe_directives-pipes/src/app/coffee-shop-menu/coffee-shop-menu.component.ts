// компонент для отображения меню напитокв кофейни
import { Component, OnInit } from '@angular/core';
import {WarmBeverage} from "../../models/WarmBeverage";

@Component({
  selector: 'app-coffee-shop-menu',
  templateUrl: './coffee-shop-menu.component.html'
})
export class CoffeeShopMenuComponent implements OnInit {
  // меню напитков - хранимые данные
  warmBeverages: Array<WarmBeverage>;

  // отображаемые данные
  displayData: Array<WarmBeverage> = [];

  // конструктор с имитацией получения данных из источника
  constructor() {
    // имитация получения данных из провайдера данных/сервиса/обработчика запроса
    this.warmBeverages = [
      new WarmBeverage( 1, "Эспрессо",           110, 140, true,  "нет",      "espresso.png"),
      new WarmBeverage( 2, "Тай-кофе",           180, 440, false, "дропсы",   "tai-coffee.png"),
      new WarmBeverage( 3, "Капучино",           110, 250, true,  "сливки",   "capuccino.png"),
      new WarmBeverage( 4, "Алоэ капучино",      160, 340, true,  "нет",      "aloe-capuccino.png"),
      new WarmBeverage( 5, "Сосновый капучино",  160, 370, true,  "сливки",   "pine-capuccino.png"),
      new WarmBeverage( 6, "Фрапучино",          210, 540, false, "нет",      "frapuccino.png"),
      new WarmBeverage( 7, "Кокосовый хот-крем", 210, 510, false, "нет",      "coconut-hot-cream.png"),
      new WarmBeverage( 8, "Brown Sugar",        110, 230, true,  "шоколад",  "brown-sugar.png"),
      new WarmBeverage( 9, "Горячий шоколад",    180, 450, true,  "нет",      "hot-chocolate.png"),
      new WarmBeverage(10, "Сибирский чай",      450, 610, false, "нет",      "siberian-tea.png"),
      new WarmBeverage(11, "Сбитень",            210, 230, true,  "имбирь",   "sbiten.png"),
      new WarmBeverage(12, "Раф",                160, 320, true,  "нет",      "raf.png"),
    ];

    // для отображения коллекции в разметке - ссылку на хранилище
    // запишем в свлйство для вывода в разметку
    this.displayData = this.warmBeverages;
  } // constructor

  ngOnInit(): void { }

  // для вывода в порядке хранения
  initialize() { this.displayData = this.warmBeverages; }

  // Упорядочивание копии коллекции по наименованию напитка
  orderByName() {
      this.displayData = [...this.warmBeverages]
        .sort((wb1, wb2) => wb1.name.localeCompare(wb2.name));
  } // orderByName

  // Упорядочивание копии коллекции по виду топпера
  orderByTopper() {
    this.displayData =  [...this.warmBeverages]
      .sort((wb1, wb2) => wb1.topper.localeCompare(wb2.topper));
  } // orderByTopper

  // Упорядочивание копии коллекции по убыванию цены напитка
  orderByPriceDesc() {
    this.displayData = [...this.warmBeverages]
      .sort((wb1, wb2) => wb2.price - wb1.price);
  } // orderByPriceDesc

  // установка предиката для выборки

} // class CoffeeShopMenuComponent
