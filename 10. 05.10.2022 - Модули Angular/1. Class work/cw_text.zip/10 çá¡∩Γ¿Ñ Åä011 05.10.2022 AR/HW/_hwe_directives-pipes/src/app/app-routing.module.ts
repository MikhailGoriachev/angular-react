import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {HomeComponent} from "./home/home.component";
import {CoffeeShopMenuComponent} from "./coffee-shop-menu/coffee-shop-menu.component";

const routes: Routes = [
  // маршруты приложения
  {path: '', component: HomeComponent},
  {path: 'coffee_shop_menu', component: CoffeeShopMenuComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
