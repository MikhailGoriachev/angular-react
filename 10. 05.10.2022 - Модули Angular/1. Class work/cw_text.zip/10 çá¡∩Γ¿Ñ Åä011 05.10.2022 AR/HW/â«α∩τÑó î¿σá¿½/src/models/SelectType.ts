﻿// Типы выборки
export enum SelectType {
    
    // по топперу
    topper,

    // по диапазону цены
    priceRange,

    // по признаку напитка "на вынос"
    isGoto
}
