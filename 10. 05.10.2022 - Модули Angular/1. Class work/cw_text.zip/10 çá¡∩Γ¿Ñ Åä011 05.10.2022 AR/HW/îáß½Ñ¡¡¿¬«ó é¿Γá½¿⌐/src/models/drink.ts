﻿
// Модель данных о напитке
export class Drink {
    constructor(public name: string,
                public volume: number,
                public price: number,
                public isTakeaway: boolean,
                public topper: string,
                public image: string
                ) {
    }
}