﻿import { Drink } from "../models/drink";

export const DRINKS: Drink[] = [
    new Drink("PUMPKIN CARAMELICIOUS", 350, 120, false, "creamy caramel", "1.jpg"),
    new Drink("PUMPKIN SPICE LATTE", 350, 140, true, "creamy pumpkin", "2.jpg"),
    new Drink("MAPLE VANILLA LATTE", 350, 110, true, "maple syrup", "3.jpg"),
    new Drink("CARAMELICIOUS", 350, 150, false, "caramel sauce", "4.png"),
    new Drink("CANDY BAR LATTE", 350, 170, true, "liquid candy bars", "5.png"),
    new Drink("MOCHA", 250, 100, true, "нет", "6.png"),
    new Drink("WHITE MOCHA", 250, 90, true, "нет", "7.png"),
    new Drink("BREWED COFFEE", 250, 90, true, "нет", "8.png"),
    new Drink("TURTLE LATTE", 350, 150, true, "turtle candy", "9.png"),
    new Drink("ESPRESSO SHOT", 45, 70, false, "нет", "10.png"),
    new Drink("HOT CHOCOLATE", 250, 150, true, "whipped cream", "11.png"),
    new Drink("SCOOTER SHOOTER", 250, 110, true, "нет", "12.png"),
];