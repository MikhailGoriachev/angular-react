import { Component, OnInit } from '@angular/core';
import { IconNamesEnum } from 'ngx-bootstrap-icons';
import { Drink } from "../../models/drink";
import { DRINKS } from "../mock-drinks";
import { sortBy } from "../../util/array";

@Component({
    selector: 'app-drinks',
    templateUrl: './drinks.component.html',
    styleUrls: ['./drinks.component.css']
})
export class DrinksComponent implements OnInit {
    // время выделения
    private readonly timeoutDelay: number = 10_000;
    // таймер для выделения
    private timeoutHandler: NodeJS.Timeout | undefined;

    // названия иконок
    iconNames = IconNamesEnum;

    // данные для отображения
    drinks: Drink[];
    // список названий топперов
    toppers: string[];

    // настройка заголовков колонок
    columns = [
        { name: '№ п/п' },
        { name: 'Фото' },
        { name: 'Название', sortProp: 'name' },
        { name: 'Объем, мл', sortProp: 'volume' },
        { name: 'Топпер', sortProp: 'topper' },
        { name: 'На вынос', sortProp: 'isTakeaway' },
        { name: 'Стоимость, ₽', sortProp: 'price' },
    ];
    
    isOrderDescend: boolean = false;        // текущий порядок сортировки в таблице   
    lastSorted: string = "";                // последний сортированный столбец

    // текущие критерии выделений
    selectedTopper: string | null = null;
    priceFrom: number | null = null;
    priceTo: number | null = null;
    takeawaySelect: boolean = false;

    constructor() {
        this.drinks = DRINKS;
        this.toppers = this.drinks.map(v => v.topper)
            .filter((v, i, ar) => i == ar.indexOf(v))
            .sort((a, b) => a.localeCompare(b));
    }

    ngOnInit(): void {
    }

    // сортировка таблицы
    onOrderChanged(event: Event, property: string) {
        event.preventDefault();

        if (property == this.lastSorted)
            this.isOrderDescend = !this.isOrderDescend;

        this.lastSorted = property;
        sortBy(this.drinks, property, this.isOrderDescend);
    }

    // запуск таймера
    setSelectionTimeout() {
        clearTimeout(this.timeoutHandler);
        this.timeoutHandler = setTimeout(() => {
            this.selectedTopper = null;
            this.priceFrom = null;
            this.priceTo = null;
            this.takeawaySelect = false;
        }, this.timeoutDelay);
    }
    
    
    // проверка на необходимость выделения эелмента
    checkSelection(drink: Drink): boolean {
        if (drink.topper == this.selectedTopper)
            return true;
        
        if(this.takeawaySelect && drink.isTakeaway)
            return true;
        
        if(this.priceFrom != null && drink.price >= this.priceFrom) {
            if(this.priceTo == null)
                return true;
            
            if(drink.price <= this.priceTo)
                return true;
        }

        if(this.priceTo != null && drink.price <= this.priceTo) {
            if(this.priceFrom == null)
                return true;

            if(drink.price >= this.priceFrom)
                return true;
        }
        
        return false;        
    }
}
