// Класс о напитках, приготавливаемых в кофейне (
// название,
// объем,
// цена,
// признак напитка на вынос,
// топпер – название или строка «нет»,
// фото напитка при подаче).

export class Drink{
  constructor(public name: string,
              public volume: number,
              public price: number,
              public takeaway: boolean,
              public topper: string,
              public image: string) {
  }
}


// данные взяты: https://pitcofe.ru/menu/kofe-i-kakao
export class CoffeeHouse{
  static drinkList: Drink[] = [
    {name: "Эспрессо Доппио", volume:80, price:119 , takeaway: true, topper: "нет", image: "1061.jpg"},
    {name: "Капучино", volume:200, price:159 , takeaway: true, topper: "нет", image: "1064.jpg"},
    {name: "Кофекофе", volume:220, price:189 , takeaway: false, topper: "шоколадный", image: "1075.jpg"},
    {name: "Какао «Соленая карамель» с жареным зефиром", volume:290, price:219 , takeaway: false, topper: "нет", image: "1089.jpg"},
    {name: "Латте «Клен 2.0»", volume:300, price:229 , takeaway: false, topper: "кленовый", image: "2044.jpg"},
    {name: "Раф", volume:220, price:209 , takeaway: true, topper: "нет", image: "1544.jpg"},
    {name: "Латте «Соленая карамель»", volume:290, price:229 , takeaway: true, topper: "нет", image: "1073.jpg"},
    {name: "Флэт Уайт", volume:170, price:179 , takeaway: true, topper: "нет", image: "1068.jpg"},
    {name: "Фисташковый какао «Пряня»", volume:210, price:229 , takeaway: false, topper: "нет", image: "3442.jpg"},
    {name: "«Матча» латте", volume:250, price:239 , takeaway: true, topper: "нет", image: "2651.jpg"},
    {name: "Ореховый капучино", volume:165, price:179 , takeaway: false, topper: "шоколадный", image: "1069.jpg"},
    {name: "Айс эспрессо", volume:300, price:159 , takeaway: true, topper: "нет", image: "1874.jpg"},
    ]



} // class CoffeeHouse
