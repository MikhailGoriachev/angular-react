import { Component, OnInit } from '@angular/core';
import {CoffeeHouse, Drink} from "../../models/drink";

@Component({
  selector: 'app-coffee-house',
  templateUrl: './coffee-house.component.html',
  styleUrls: ['./coffee-house.component.css']
})
export class CoffeeHouseComponent implements OnInit {

  // отображаемая коллекция
  drinks: Drink[] = [];

  // исходная коллекция
  source: Drink[] = [];

  constructor() {
    this.drinks = CoffeeHouse.drinkList;
    this.source = [...this.drinks];
  }

  ngOnInit(): void {
  }

  // предикат для выделения записи
  private selected: (drink: Drink) => boolean = () => false;

  get isSelect(): (drink: Drink) => boolean {
    return this.selected;
  }

  set isSelect(value: (drink: Drink) => boolean) {
    this.selected = value;
  }

  showDrinks(){
    this.drinks = CoffeeHouse.drinkList;
    this.source = [...this.drinks];
  }

  // Упорядочивание по наименованию напитка
  sortedByName(){
    this.drinks = this.source.sort((a, b) => a.name.localeCompare(b.name))
  }

  // Упорядочивание по виду топпера
  sortedByTopper(){
    this.drinks = this.source.sort((a, b) => a.topper.localeCompare(b.topper))
  }

  // Упорядочивание по убыванию цены напитка
  sortedByPriceDesc(){
    this.drinks = this.source.sort((a, b) => b.price - a.price)
  }

  // Выборка напитка по топперу
  selectByTopper(topper: string): void {
    this.selected = (d) => topper === d.topper;
  }


} // class CoffeeHouseComponent
