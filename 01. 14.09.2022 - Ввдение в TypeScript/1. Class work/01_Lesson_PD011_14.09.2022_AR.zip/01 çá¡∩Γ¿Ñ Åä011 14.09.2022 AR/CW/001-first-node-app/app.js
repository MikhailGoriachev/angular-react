console.clear();
console.log('\n\n\tПривет, Node Js\n');
