import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-history-progress',
  template: '<h3>История Вашего прогресса</h3><p>Компонент в разработке...</p>'
})
export class HistoryProgressComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
