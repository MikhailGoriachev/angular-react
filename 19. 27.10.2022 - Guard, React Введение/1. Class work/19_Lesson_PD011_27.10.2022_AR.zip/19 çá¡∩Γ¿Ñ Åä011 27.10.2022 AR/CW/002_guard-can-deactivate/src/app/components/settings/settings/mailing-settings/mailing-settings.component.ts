import { Component, OnInit } from '@angular/core';

// пока компонент не имеет функционала
@Component({
  selector: 'app-mailing-settings',
  templateUrl: './mailing-settings.component.html'
})
export class MailingSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
