import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mailing-settings',
  templateUrl: './mailing-settings.component.html'
})
export class MailingSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
