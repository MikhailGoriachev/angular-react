import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book1',
  templateUrl: './book1.component.html'
})
export class Book1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
