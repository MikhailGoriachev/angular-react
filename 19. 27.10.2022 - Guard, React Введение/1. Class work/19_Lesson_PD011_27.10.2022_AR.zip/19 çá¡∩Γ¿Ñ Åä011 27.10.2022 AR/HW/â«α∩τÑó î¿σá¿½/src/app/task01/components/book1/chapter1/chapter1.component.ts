import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chapter1',
  templateUrl: './chapter1.component.html'
})
export class Chapter1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
