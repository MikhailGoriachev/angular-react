import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chapter2',
  templateUrl: './chapter2.component.html'
})
export class Chapter2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
