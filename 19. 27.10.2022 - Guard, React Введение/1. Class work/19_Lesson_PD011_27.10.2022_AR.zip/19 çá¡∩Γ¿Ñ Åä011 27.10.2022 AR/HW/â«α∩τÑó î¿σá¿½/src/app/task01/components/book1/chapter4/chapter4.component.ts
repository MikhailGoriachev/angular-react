import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chapter4',
  templateUrl: './chapter4.component.html'
})
export class Chapter4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
