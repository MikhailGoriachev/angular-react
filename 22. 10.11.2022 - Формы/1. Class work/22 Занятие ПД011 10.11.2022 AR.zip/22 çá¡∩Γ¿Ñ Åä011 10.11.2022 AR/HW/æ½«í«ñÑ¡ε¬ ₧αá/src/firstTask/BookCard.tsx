import { Add, Remove } from "@mui/icons-material";
import { Box, Card, CardContent, CardMedia, Chip, IconButton, Tooltip, Typography } from "@mui/material";
import { useState } from "react";


export type Book = {
    title: string,
    author: string,
    publishYear: number,
    price: number,
    count: number,
    coverFileName: string
}


type BookCardProps = {
    book: Book
}


export function BookCard({ book }: BookCardProps) {
    const [count, setCount] = useState(book.count);

    return (
        <Card sx={{ display: "flex", justifyContent: "space-between" }}>
            <Box sx={{ display: 'flex', flexDirection: "column" }}>
                <CardContent sx={{ display: "flex", flexDirection: "column", flexGrow: 1 }}>
                    <Typography variant="h6" fontWeight="normal">
                        {book.title}
                    </Typography>
                    <Typography variant="subtitle2" fontWeight="lighter">
                        {`${book.author}, ${book.publishYear}`}
                    </Typography>
                    <Box flexGrow={1} sx={{ display: "flex", alignItems: "center" }} gap={2}>
                        <IconButton color="success" onClick={() => setCount(count + 1)}>
                            <Add/>
                        </IconButton>
                        <IconButton color="error" disabled={count === 0} onClick={() => setCount(count - 1)}>
                            <Remove/>
                        </IconButton>
                    </Box>
                </CardContent>
                <Box sx={{ display: "flex", alignItems: "center", pl: 1, pb: 1 }} gap={1}>
                    <Tooltip title="Количество" arrow disableInteractive>
                        <Chip label={count} size="small" variant="outlined"/>
                    </Tooltip>
                    <Tooltip title="Цена" arrow disableInteractive>
                        <Chip label={book.price} size="small" variant="outlined"/>
                    </Tooltip>
                </Box>
            </Box>
            <CardMedia
                sx={{ maxWidth: 150 }}
                component="img"
                image={`/public/covers/${book.coverFileName}`}
            />
        </Card>
    );
}