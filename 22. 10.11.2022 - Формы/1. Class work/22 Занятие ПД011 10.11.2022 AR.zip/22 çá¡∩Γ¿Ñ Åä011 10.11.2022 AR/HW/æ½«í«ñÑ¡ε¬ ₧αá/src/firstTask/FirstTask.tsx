import { Grid, Typography } from "@mui/material";
import { Book, BookCard } from "./BookCard";


const books: Book[] = [
    {
        title: "О Дивный Новый Мир",
        author: "Олдос Хаксли",
        count: 15,
        price: 4000,
        publishYear: 1932,
        coverFileName: "BraveNewWorld.jpg"
    },
    {
        title: "Государь",
        author: "Никколо Макиавелли",
        count: 2,
        price: 3000,
        publishYear: 1532,
        coverFileName: "ThePrince.jpg"
    },
    {
        title: "К себе самому",
        author: "Марк Аврелий",
        count: 4,
        price: 7000,
        publishYear: 1558,
        coverFileName: "Meditations.jpg"
    }
];


export function FirstTask() {
    return (
        <>
            <Typography variant="h3" fontWeight="lighter" marginBottom={3}>Задача 1</Typography>
            <Grid container spacing={3}>
                {books.map(book => (
                    <Grid item xs={4} sx={{
                        "& > *": {
                            height: "100%"
                        }
                    }}>
                        <BookCard book={book}/>
                    </Grid>
                ))}
            </Grid>
        </>
    );
}