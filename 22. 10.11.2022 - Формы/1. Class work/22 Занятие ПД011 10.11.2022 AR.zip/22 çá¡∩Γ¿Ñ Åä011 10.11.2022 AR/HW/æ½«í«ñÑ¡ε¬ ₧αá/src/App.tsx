import { Box, Container, Divider } from "@mui/material";
import { FirstTask } from "./firstTask/FirstTask";
import { SecondTask } from "./secondTask/SecondTask";


function App() {
    return (
        <Container>
            <Box>
                <FirstTask/>
            </Box>
            <Divider sx={{ marginY: 5 }}/>
            <Box>
                <SecondTask/>
            </Box>
        </Container>
    );
}

export default App;
