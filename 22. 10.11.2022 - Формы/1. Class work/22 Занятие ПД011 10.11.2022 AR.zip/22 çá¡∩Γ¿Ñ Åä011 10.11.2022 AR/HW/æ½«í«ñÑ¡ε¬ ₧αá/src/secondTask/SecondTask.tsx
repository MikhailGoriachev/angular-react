import { Tasks } from "./Tasks";
import { FourQuadrant } from "./FourQuadrant";
import { IsPrimeNumber } from "./IsPrimeNumber";
import { ObliqueTrianglePerimeter } from "./ObliqueTrianglePerimeter";
import { QuadraticEquationRoots } from "./QuadraticEquationRoots";


export function SecondTask() {
    return (
        <Tasks title="Задача 2" tasks={[
            { title: "Компонент 1", component: <QuadraticEquationRoots a={0} b={0} c={0}/> },
            { title: "Компонент 2", component: <ObliqueTrianglePerimeter a={0} h={0}/> },
            { title: "Компонент 3", component: <IsPrimeNumber a={0}/> },
            { title: "Компонент 4", component: <FourQuadrant x={0} y={0}/> },
        ]}/>
    );
}