import { Box, Card, CardContent, CardHeader, Grid, Typography } from "@mui/material";
import { ReactNode } from "react";


type Task = {
    title: string,
    component: ReactNode
}


type TasksProps = {
    title: string,
    tasks: Task[]
}


export function Tasks(props: TasksProps) {
    return (
        <>
            <Typography variant="h3" fontWeight="lighter" marginBottom={3}>{props.title}</Typography>
            <Grid container alignContent="center" spacing={3}>
                {props.tasks.map(task => (
                    <Grid item xs={6}>
                        <Card>
                            <CardHeader title={task.title}/>
                            <CardContent>
                                <Box>
                                    {task.component}
                                </Box>
                            </CardContent>
                        </Card>
                    </Grid>
                ))}
            </Grid>
        </>
    );
}