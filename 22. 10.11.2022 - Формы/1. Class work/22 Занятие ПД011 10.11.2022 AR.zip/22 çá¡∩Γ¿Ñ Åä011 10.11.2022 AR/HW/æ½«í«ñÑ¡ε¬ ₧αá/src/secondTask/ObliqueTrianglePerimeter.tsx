import { Box, Stack, TextField, Typography } from "@mui/material";
import { useEffect, useState } from "react";
import { NumberInput } from "../shared/NumberInput";


type ObliqueTrianglePerimeterProps = {
    a: number,
    h: number
}


export function ObliqueTrianglePerimeter(props: ObliqueTrianglePerimeterProps) {
    const [a, setA] = useState(props.a);
    const [h, setH] = useState(props.h);
    const [perimeter, setPerimeter] = useState(0);

    useEffect(() => {
        const side = Math.sqrt(Math.pow(a / 2, 2) + Math.pow(h, 2));
        const perimeterValue = a + 2 * side;

        setPerimeter(perimeterValue)
    }, [a, h]);

    return (
        <>
            <Stack gap={5} direction="row">
                <NumberInput defaultValue={props.a} label="A" dispatch={setA}/>
                <NumberInput defaultValue={props.h} label="H" dispatch={setH}/>
            </Stack>
            <Box paddingTop={5}>
                <Typography>Периметр: {perimeter}</Typography>
            </Box>
        </>
    );
}