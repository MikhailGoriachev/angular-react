import { Box, Stack, Typography } from "@mui/material";
import { useEffect, useState } from "react";
import { NumberInput } from "../shared/NumberInput";


type QuadraticEquationRootsProps = {
    a: number,
    b: number,
    c: number
}


export function QuadraticEquationRoots(props: QuadraticEquationRootsProps) {
    const [a, setA] = useState(props.a);
    const [b, setB] = useState(props.b);
    const [c, setC] = useState(props.c);
    const [roots, setRoots] = useState<number | null>(null);

    useEffect(() => {
        const discriminant = Math.pow(b, 2) - 4 * a * c;
        const rootsNumber = discriminant == 0
                            ? 1
                            : discriminant > 0
                              ? 2
                              : null;

        setRoots(rootsNumber);
    }, [a, b, c]);

    return (
        <>
            <Stack gap={5} direction="row">
                <NumberInput defaultValue={props.a} label="A" dispatch={setA}/>
                <NumberInput defaultValue={props.b} label="B" dispatch={setB}/>
                <NumberInput defaultValue={props.c} label="C" dispatch={setC}/>
            </Stack>
            <Box paddingTop={5}>
                <Typography>Кол-во корней: {roots ?? "Нет корней"}</Typography>
            </Box>
        </>
    );
}