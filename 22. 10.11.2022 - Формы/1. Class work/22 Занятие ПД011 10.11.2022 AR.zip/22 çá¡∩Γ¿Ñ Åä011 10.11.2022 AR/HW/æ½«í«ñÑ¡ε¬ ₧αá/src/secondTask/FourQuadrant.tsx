import { Box, Stack, TextField, Typography } from "@mui/material";
import { useEffect, useState } from "react";
import { NumberInput } from "../shared/NumberInput";


type FourQuadrantProps = {
    x: number,
    y: number
}


export function FourQuadrant(props: FourQuadrantProps) {
    const [x, setX] = useState(props.x);
    const [y, setY] = useState(props.y);
    const [quadrant, setQuadrant] = useState(0);

    useEffect(() => {
        setQuadrant(findQuadrant(x, y));
    }, [x, y]);

    return (
        <>
            <Stack gap={5} direction="row">
                <NumberInput defaultValue={props.x} label="X" dispatch={setX}/>
                <NumberInput defaultValue={props.y} label="Y" dispatch={setY}/>
            </Stack>
            <Box paddingTop={5}>
                <Typography>Четверть: {quadrant}</Typography>
            </Box>
        </>
    );
}

const quadrants: {
    [key: number]: (x: number, y: number) => boolean
} = {
    1: (x, y) => x > 0 && y > 0,
    2: (x, y) => x < 0 && y > 0,
    3: (x, y) => x < 0 && y < 0,
    4: (x, y) => x > 0 && y < 0
};

function findQuadrant(x: number, y: number) {
    for (let quadrant in quadrants) {
        if (quadrants[quadrant](x, y))
            return Number(quadrant);
    }

    return 0;
}