import { Box, Stack, TextField, Typography } from "@mui/material";
import { useEffect, useState } from "react";
import { NumberInput } from "../shared/NumberInput";


type IsPrimeNumberProps = {
    a: number
}


export function IsPrimeNumber(props: IsPrimeNumberProps) {
    const [a, setA] = useState(props.a);
    const [isPrime, setIsPrime] = useState(false);

    useEffect(() => {
        setIsPrime(isNumberPrime(a));
    }, [a]);

    return (
        <>
            <Stack gap={5} direction="row">
                <NumberInput defaultValue={0} label="A" dispatch={setA}/>
            </Stack>
            <Box paddingTop={5}>
                <Typography>Число простое? - {isPrime ? "Да" : "Нет"}</Typography>
            </Box>
        </>
    );
}


function isNumberPrime(num: number) {
    if (num == 2 || num == 3)
        return true;

    if (num <= 1 || num % 2 == 0 || num % 3 == 0)
        return false;

    for (let i = 5; i * i <= num ; i+=6)
        if (num % i == 0 || num % (i + 2) == 0)
            return false;

    return true;
}