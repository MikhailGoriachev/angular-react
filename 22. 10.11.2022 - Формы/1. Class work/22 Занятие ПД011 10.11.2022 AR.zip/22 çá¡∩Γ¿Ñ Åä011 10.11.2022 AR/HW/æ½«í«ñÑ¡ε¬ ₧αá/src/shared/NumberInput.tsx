import { TextField } from "@mui/material";
import { Dispatch, SetStateAction } from "react";


type NumberInputProps = {
    defaultValue: number,
    label: string,
    dispatch: Dispatch<SetStateAction<number>>,
}


export function NumberInput(props: NumberInputProps) {
    return (
        <TextField label={props.label}
                   type="number"
                   defaultValue={props.defaultValue}
                   InputLabelProps={{
                       shrink: true,
                   }}
                   onChange={e => props.dispatch(Number(e.target.value))}
        />
    );
}