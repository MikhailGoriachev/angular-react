// Решение задачи 2

//region Компонент 1
// Определить количество корней квадратного уравнения.
// пропсы: начальные значения a, b, c
// стейт: a, b, c, кол-во корней
// по клику на кнопку меняем стейт
class Component1 extends React.Component {

    constructor(props) {
        super(props);

        // копируем пропсы в стейт
        this.state = {a: props.a, b: props.b, c: props.c, roots: this.getNumRoots(props.a, props.b, props.c)};

        this["clickSolve"] = this.clickSolve.bind(this);
    }

    // определение количества корней квадратного уравнения
    getNumRoots(a, b, c) {
        let d = b * b - 4 * a * c;
        return d < 0 ? 0 : d > 0 ? 2 : 1;
    }

    // клик по кнопке для решения задачи
    clickSolve() {
        let a = getRand(-10, 10);
        let b = getRand(-10, 10);
        let c = getRand(-10, 10);

        this.setState({a: a, b: b, c: c, roots: this.getNumRoots(a, b, c)});
    } // clickSolve

    render() {
        return <div className="card">
            <div className="card-body">
                <h5 className="card-title">Компонент 1</h5>
                <p className="card-text">Количество корней квадратного уравнения</p>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item d-flex justify-content-between">Коэффициент
                    a: <b>{this.state.a.toFixed(5)}</b></li>
                <li className="list-group-item d-flex justify-content-between">Коэффициент
                    b: <b>{this.state.b.toFixed(5)}</b></li>
                <li className="list-group-item d-flex justify-content-between">Коэффициент
                    c: <b>{this.state.c.toFixed(5)}</b></li>
                <li className="list-group-item d-flex justify-content-between">Количество
                    корней: <b>{this.state.roots}</b></li>
            </ul>
            <div className="card-footer">
                <button className="btn btn-outline-success" onClick={this.clickSolve}>Вычислить</button>
            </div>
        </div>
    }
}
//endregion


//region Компонент 2
// Найти периметр равнобедренного треугольника по его основанию a и высоте h,
// проведенной к основанию. Пропсы: начальные значения a, h. Стейт: a, h, p.
// По клику на кнопку меняем стейт
class Component2 extends React.Component {
    constructor(props) {
        super(props);

        // копируем пропсы в стейт
        this.state = {a: props.a, h: props.h, p: this.perimeter(props.a, props.h)};

        this.clickSolve = this.clickSolve.bind(this);
    } // constructor


    // вычисление периметра равнобедренного треугольника по заданию
    perimeter(a, h) {
        return a + 2 * Math.sqrt(a * a / 4 + h * h);
    } // perimeter

    // клик по кнопке для решения задачи
    clickSolve() {
        let a = getRand(1, 100);
        let h = getRand(1, 100);

        this.setState({a: a, h: h, p: this.perimeter(a, h)});
    } // clickSolve

    render() {
        return <div className="card">
            <div className="card-body">
                <h5 className="card-title">Компонент 2</h5>
                <p className="card-text">Периметр равнобедренного треугольника</p>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item d-flex justify-content-between">Основание
                    a: <b>{this.state.a.toFixed(5)}</b></li>
                <li className="list-group-item d-flex justify-content-between">Высота
                    h: <b>{this.state.h.toFixed(5)}</b></li>
                <li className="list-group-item">&nbsp;</li>
                <li className="list-group-item d-flex justify-content-between">Периметр: <b>{this.state.p.toFixed(5)}</b>
                </li>
            </ul>
            <div className="card-footer">
                <button className="btn btn-outline-success" onClick={this.clickSolve}>Вычислить</button>
            </div>
        </div>
    }
}
//endregion


//region Компонент 3
// Определить, является ли простым числом число a. Пропсы: начальное значение a.
// Стейт: a, результат проверки.
// По клику на кнопку меняем стейт
class Component3 extends React.Component {
    constructor(props) {
        super(props);

        // копируем пропсы в стейт
        this.state = {a: props.a, r: this.isPrime(props.a)};

        this.clickSolve = this.clickSolve.bind(this);
    } // constructor

    // возвращает true, если число простое и false, если число составное
    isPrime(a) {
        let n = Math.sqrt(a);

        for (let i = 2; i < n; i++) {
            if (a % i === 0) return false;
        }
        return true;
    } // isPrime

    // клик по кнопке для решения задачи
    clickSolve() {
        let a = Math.floor(getRand(1, 100));

        this.setState({a: a, r: this.isPrime(a)});
    } // clickSolve

    render() {
        return <div className="card">
            <div className="card-body">
                <h5 className="card-title">Компонент 3</h5>
                <p className="card-text">Проверка числа на простоту</p>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item d-flex justify-content-between">Число a: <b>{this.state.a}</b></li>
                <li className="list-group-item">&nbsp;</li>
                <li className="list-group-item">&nbsp;</li>
                <li className="list-group-item d-flex justify-content-between">Результат проверки:
                    <b>{this.state.r?"простое":"составное"}</b></li>
            </ul>
            <div className="card-footer">
                <button className="btn btn-outline-success" onClick={this.clickSolve}>Вычислить</button>
            </div>
        </div>
    }
}
//endregion


//region Компонент 4
// Определить номер координатной четверти, в которой находится точка с ненулевыми
// координатами (x, y). Пропсы: начальные значения x, y. Стейт: x, y, номер
// координатной плоскости.
// По клику на кнопку меняем стейт
class Component4 extends React.Component {
    constructor(props) {
        super(props);

        // копируем пропсы в стейт
        this.state = {x: props.x, y: props.y, n: this.getQuarter(props.x, props.y)};

        this.clickSolve = this.clickSolve.bind(this);
    } // constructor

    // определение номера координатной плоскости по значениям координат точки
    getQuarter(x, y) {
        return x >= 0 && y >= 0? 1 : x < 0 && y >= 0? 2: x < 0 && y < 0?3:4;
    } // getQuarter

    // клик по кнопке для решения задачи
    clickSolve() {
        let x = getRand(-100, 100);
        let y = getRand(-100, 100);

        this.setState({x: x, y: y, n: this.getQuarter(x, y)});
    } // clickSolve

    render() {
        return <div className="card">
            <div className="card-body">
                <h5 className="card-title">Компонент 4</h5>
                <p className="card-text">Номер координатной плоскости точки</p>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item d-flex justify-content-between">Координата x: <b>{this.state.x.toFixed(2)}</b></li>
                <li className="list-group-item d-flex justify-content-between">Координата y: <b>{this.state.y.toFixed(2)}</b></li>
                <li className="list-group-item">&nbsp;</li>
                <li className="list-group-item d-flex justify-content-between">Номер плоскости: <b>{this.state.n}</b></li>
            </ul>
            <div className="card-footer">
                <button className="btn btn-outline-success" onClick={this.clickSolve}>Вычислить</button>
            </div>
        </div>
    }
}

// вывод компонентов
ReactDOM.createRoot(document.getElementById("app"))
.render(
    <div className="row mt-5 p-5">
        <div className="col-4 mt-3">
            <Component1 a={getRand(-10, 10)} b={getRand(-10, 10)} c={getRand(-10, 10)}/>
        </div>

        <div className="col-4 mt-3">
            <Component2 a={getRand(1, 10)} h={getRand(1, 10)}/>
        </div>

        <div className="col-4 mt-3">
            <Component3 a={Math.floor(getRand(10, 1000))}/>
        </div>

        <div className="col-4 mt-3">
            <Component4 x={getRand(-100, 100)} y={getRand(-100, 100)}/>
        </div>
    </div>
);
//endregion