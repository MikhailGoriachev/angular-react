
// генерация случайного вещественного числа
function getRand(from, to) {
    return from + (to - from)*Math.random();
} // getRand


