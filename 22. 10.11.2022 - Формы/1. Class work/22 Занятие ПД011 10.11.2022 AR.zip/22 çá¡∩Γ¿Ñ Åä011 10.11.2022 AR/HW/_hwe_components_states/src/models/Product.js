// объект, представляющий товар
// наименование, артикул, цена, количество, изображение товара
class Product {
    constructor(id, name, articul, price, quantity, image) {
        this.productId = id;
        this.productName = name;
        this.articul = articul;
        this.price = price;
        this.quantity = quantity;
        this.image = image;
    }
} // class Product
