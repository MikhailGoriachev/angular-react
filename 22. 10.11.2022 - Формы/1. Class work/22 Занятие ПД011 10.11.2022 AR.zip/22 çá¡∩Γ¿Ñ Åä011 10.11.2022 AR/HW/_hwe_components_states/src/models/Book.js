// класс, представляющий книгу
// название, автор, год издания, цена, количество в библиотеке, изображение обложки
class Book {
    constructor(id, title, author, published, quantity, price, cover) {
        this.bookId = id;
        this.bookTitle = title;
        this.author = author;
        this.published = published;
        this.quantity = quantity;
        this.price = price;
        this.cover = cover;
    }
} // class Book
