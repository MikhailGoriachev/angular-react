// Решение задачи 1

let book1 = new Book(42, 'React в действии', 'Томас М.Т.', 2019, 3, 860, '/images/task1/books/cover1.jpg');
let book2 = new Book(24, 'React быстро', 'Мардан А.', 2019, 4, 720, '/images/task1/books/cover2.jpg');
let book3 = new Book(36, 'Изучаем React на практике', 'Чиннатамби К.', 2019, 3, 680, '/images/task1/books/cover3.jpg');

function calcTotalBook() {
    return (
        book1.price * book1.quantity +
        book2.price * book2.quantity +
        book3.price * book3.quantity);
} // calcTotalBook


let product1 = new Product(24, 'Насос погружной бочковой ЗУБР НПБ-300',
    '1424538', 4050, 12, '/images/task1/products/product1.jpg');
let product2 = new Product(28, 'Насос погружной бочковой ЗУБР НПБ-600',
    '1424542', 6150, 3, '/images/task1/products/product2.jpg');
let product3 = new Product(28, 'Емкость для воды полиэтиленовая SK-500',
    '1424622', 10_863, 5, '/images/task1/products/product3.jpg');


function calcAmountProduct() {
    return (
        product1.price * product1.quantity +
        product2.price * product2.quantity +
        product3.price * product3.quantity);
} // calcAmountProduct


//region Компонент React для вывода сведений о книге
class BookComponent extends React.Component {
    constructor(props) {
        super(props);

        // копируем изменяющиеся пропсы в стейт
        this.state = {book: props.book};

        // привязка обработчиков клика к контексту объекта
        this.addClick = this.addClick.bind(this);
        this.removeClick = this.removeClick.bind(this);
    } // constructor

    // Обработчик события клик по кнопке увеличения количества книги
    addClick() {
        this.props.book.quantity++;
        this.setState({book: this.props.book});

        document.querySelector('#libraryTotal').innerHTML = calcTotalBook();
    } // addClick

    // Обработчик события уменьшения количества книг
    removeClick() {
        if (this.state.book.quantity > 0) {
            this.props.book.quantity--;
            this.setState({book: this.props.book});
        } // if

        document.querySelector('#libraryTotal').innerHTML = calcTotalBook();
    } // removeClick

    // обязательный метод для рендеринга компонента
    render() {
        return <div className="card">
            <img src={this.props.book.cover} className="card-img-top w-50 mx-auto"
                 alt={this.props.book.bookTitle}/>
            <div className="card-body">
                <h5 className="card-title">{this.props.book.author}</h5>
                <p className="card-text">{this.props.book.bookTitle}</p>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item d-flex justify-content-between px-3">ид книги: <b>{this.props.book.bookId}</b></li>
                <li className="list-group-item d-flex justify-content-between px-3">год издания: <b>{this.props.book.published}</b></li>
                <li className="list-group-item d-flex justify-content-between px-3">количество: <b>{this.state.book.quantity}</b></li>
                <li className="list-group-item d-flex justify-content-between px-3">цена: <b>{this.props.book.price}</b></li>
            </ul>
            <div className="card-footer">
                <button className="btn btn-outline-success me-3" onClick={this.addClick}>+1</button>
                <button className="btn btn-outline-secondary" onClick={this.removeClick}>-1</button>
            </div>
        </div>
    } // render
} // class BookComponent
BookComponent.defaultProps = {book: book2};
//endregion


//region Компонент React для вывода сведений о товаре
class ProductComponent extends React.Component {
    constructor(props) {
        super(props);

        // копируем изменяющиеся пропсы в стейт
        this.state = {quantity: props.product.quantity};

        // привязка обработчиков клика к контексту объекта
        this.addClick = this.addClick.bind(this);
        this.removeClick = this.removeClick.bind(this);
    } // constructor

    // Метод, обработчик события
    addClick() {
        this.props.product.quantity++;
        this.setState({quantity: this.props.product.quantity});

        document.querySelector('#basketTotal').innerHTML = calcAmountProduct();
    } // addClick

    // Метод, продолжающий обработку события
    removeClick() {
        if (this.state.quantity > 0) {
            this.props.product.quantity--;
            this.setState({quantity: this.props.product.quantity});
        } // if

        document.querySelector('#basketTotal').innerHTML = calcAmountProduct();
    } // removeClick

    // обязательный метод для рендеринга компонента
    render() {
        return <div className="card">
            <img src={this.props.product.image} className="card-img-top w-50 mx-auto"
                 alt={this.props.product.productName}/>
            <div className="card-body">
                <h5 className="card-title">{this.props.product.productName}</h5>
                <p className="card-text">lorem ipsum dolor sit amet...</p>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item d-flex justify-content-between px-3">артикул: <b>{this.props.product.articul}</b></li>
                <li className="list-group-item d-flex justify-content-between px-3">количество: <b>{this.state.quantity}</b></li>
                <li className="list-group-item d-flex justify-content-between px-3">цена: <b>{this.props.product.price}</b></li>
            </ul>
            <div className="card-footer">
                <button className="btn btn-outline-success me-3" onClick={this.addClick}>+1
                </button>
                <button className="btn btn-outline-secondary" onClick={this.removeClick}>-1
                </button>
            </div>
        </div>
    } // render
} // class ProductComponent
ProductComponent.defaultProps = { product: product2 };
//endregion


//region Разметка для вывода компонентов
// вывод компонентов - обернем их в специальный пустой тег, который введен в React
// для соблюдения правило возврата тега и в то же время, не нарушать разметку
ReactDOM.createRoot(document.getElementById("app"))
.render(
    <>
        <div className="row mt-3 p-3">
            <h3 className="col-3">Сведения о книгах</h3>
            <h4 className="col-5">Книг в библиотеке на сумму: <span id="libraryTotal">{calcTotalBook()}</span></h4>
        </div>

        <div className="row mt-3 p-3">
            <div className="col-3 mt-3 ms-3"><BookComponent book={book1} /></div>
            <div className="col-3 mt-3 ms-3"><BookComponent/></div>
            <div className="col-3 mt-3 ms-3"><BookComponent book={book3} /></div>
        </div>

        <div className="row mt-3 p-3">
            <h3 className="col-3">Сведения о товарах</h3>
            <h4 className="col-5">Товаров на сумму: <span id="basketTotal">{calcAmountProduct()}</span></h4>
        </div>

        <div className="row mt-3 p-3">
            <div className="col-3 mt-3 ms-3"><ProductComponent product={product1}/></div>
            <div className="col-3 mt-3 ms-3"><ProductComponent/></div>
            <div className="col-3 mt-3 ms-3"><ProductComponent product={product3}/></div>
        </div>
    </>
);
//endregion