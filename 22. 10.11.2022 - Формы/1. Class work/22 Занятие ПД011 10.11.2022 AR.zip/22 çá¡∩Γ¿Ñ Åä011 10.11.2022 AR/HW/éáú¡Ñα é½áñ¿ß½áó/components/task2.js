
//Компонент 1 - Определить количество корней квадратного уравнения.
// Пропсы: начальные значения a, b, c. 
// Стейт: a, b, c, кол-во корней. По клику на кнопку меняем стейт
class Component1 extends React.Component {

    constructor(props) {
        super(props);

        //Задание состояний
        this.state = {a: this.props.a, b: this.props.b, c: this.props.c, roots: 0};

        this['reloadStates'] = this.reloadStates.bind(this)
    }

    //Обработка клика по кнопке
    reloadStates(){

        let a = getRandomDouble(-10,10);
        let b = getRandomDouble(-10,10);
        let c = getRandomDouble(-10,10);

        this.setState({
            a: a,
            b: b,
            c: c,
            roots: getEquationRoots(a,b,c)
        });



    }

    //Формирование разметки
    render() {
        // let {a,b,c} = this.state;

        // this.setState({roots: getEquationRoots(a,b,c)});

        return (
            <table className="table-settings w-75 mx-auto">
                <tr>
                    <th className={"p-3 text-center"} colSpan={3}>Нахождение корней квадратногоуравнения</th>
                </tr>
                <tr>
                    <td>a: <b>{this.state.a.toFixed(2)}</b></td>
                    <td>b: <b>{this.state.b.toFixed(2)}</b></td>
                    <td>c: <b>{this.state.c.toFixed(2)}</b></td>
                </tr>
                <tr>
                    <td colSpan={2}>
                        Количество корней: <b>{this.state.roots}</b>
                    </td>
                    <td>
                        <button className={"btn btn-primary d-block mx-auto my-2"} onClick={() => this.reloadStates()}>Перезаписать state</button>
                    </td>
                </tr>
            </table>
        )

    }


} //Component1

// Компонент 2 - Найти периметр равнобедренного треугольника по его основанию a и высоте h, проведенной к основанию.
// Пропсы: начальные значения a, h.
// Стейт: a, h, p. По клику на кнопку меняем стейт
class Component2 extends React.Component {

    constructor(props) {
        super(props);

        //Задание состояний
        this.state = {a: this.props.a, h: this.props.h, p: 0};

        //Привязка
        this.reloadStates = this.reloadStates.bind(this);
    }

    //Обработка клика по кнопке
    reloadStates(){
        console.log("Обработчик перезаписи states запускается")
        let a = getRandom(1,12);
        let h = getRandom(1,12);

        //Без с использования callback
        this.setState({
                a: a,
                h: h,
                p: getTrianglePerimeter(a,h)
            });

    }

    //Формирование разметки
    render() {
        // let {a,h} = this.state;

        // this.setState({p: getTrianglePerimeter(a,h)});

        return (
            <table className="table-settings w-75 mx-auto">
                <tr>
                    <th className={"p-3 text-center"} colSpan={2}>Нахождение периметра равнобедренного треугольника</th>
                </tr>
                <tr>
                    <td>Основание (a): <b>{this.state.a.toFixed(2)}</b></td>
                    <td>Высота (h): <b>{this.state.h.toFixed(2)}</b></td>
                </tr>
                <tr>
                    <td >
                       Периметр треугольниа: <b>{this.state.p.toFixed(2)}</b>
                    </td>
                    <td>
                        <button className={"btn btn-primary d-block mx-auto my-2"} onClick={() => this.reloadStates()}>Перезаписать state</button>
                    </td>
                </tr>
            </table>
        )

    }


} //Component2

// Компонент 3 - Определить является ли простым числом число a.
// Пропсы: начальное значение a.
// Стейт: a, результат проверки. По клику на кнопку меняем стейт
class Component3 extends React.Component {

    constructor(props) {
        super(props);

        //Задание состояний
        this.state = {a: this.props.a,result: false};

        //Привязка
        this.reloadStates = this.reloadStates.bind(this);
    }

    //Обработка клика по кнопке
    reloadStates(){

        //Асинхронное изменение с использованием callback
        this.setState((prevState, props) => {
            let a = getRandomInt(1,12);
            return {a: a, result: isPrimeNumber(a)}
        });

    }

    //Формирование разметки
    render() {
        let a = this.state.a;

        //Корректно не работает
        /*this.setState((prev,props) => { return {result: IsPrimeNumber(a)}});*/

        return (
            <table className="table-settings w-75 mx-auto">
                <tr>
                    <th className={"p-3 text-center"} colSpan={2}>Определение типа числа</th>
                </tr>
                <tr>
                    <td colSpan={2}>Заданное число: <b>{this.state.a}</b></td>
                </tr>
                <tr>
                    <td >
                       Тип числа: <b>{/*this.state.result*/isPrimeNumber(a) ? "простое" : "составное"}</b>
                    </td>
                    <td>
                        <button className={"btn btn-primary d-block mx-auto my-2"} onClick={() => this.reloadStates()}>Перезаписать state</button>
                    </td>
                </tr>
            </table>
        )

    }


} //Component3

// Компонент 4 - Определить номер координатной четверти, в которой находится точка с ненулевыми координатами (x, y).
// Пропсы: начальные значения x, y.
// Стейт: x, y, номер координатной плоскости по клику на кнопку меняем стейт
class Component4 extends React.Component {

    constructor(props) {
        super(props);

        //Задание состояний
        this.state = {x: this.props.x,y: this.props.y,quarter: 0};

        //Привязка
        this.reloadStates = this.reloadStates.bind(this);
    }

    //Обработка клика по кнопке
    reloadStates(){
        console.log("Обработчик перезаписи states. Component 4");

        let x =  getRandomDouble(-20, 20);
        let y =  getRandomDouble(-20, 20);
        this.setState({x: x, y: y,quarter: getQuarterNumber(x,y)});

        //С использованием callback
        /*this.setState((prevState, props) => {return {
            x: getRandomDouble(-20, 20),
            y: getRandomDouble(-20, 20),
        }});*/

    }

    //Формирование разметки
    render() {
        // let {x,y} = this.state;
        //
        // //Корректно не работает
        // this.setState({quarter: getQuarterNumber(x,y)});

        return (
            <table className="table-settings w-75 mx-auto">
                <tr>
                    <th className={"p-3 text-center"} colSpan={2}>Определение номера координатной плоскости</th>
                </tr>
                <tr>
                    <td >X: <b>{this.state.x}</b></td>
                    <td >Y: <b>{this.state.y}</b></td>
                </tr>
                <tr>
                    <td >
                       Номер плоскости: <b>{this.state.quarter}</b>
                    </td>
                    <td>
                        <button className={"btn btn-primary d-block mx-auto my-2"} onClick={() => this.reloadStates()}>Перезаписать state</button>
                    </td>
                </tr>
            </table>
        )

    }


} //Component4


function callComponent1(){

    ReactDOM.createRoot($("component1"))
        .render(
            <Component1 a={getRandomDouble(-10, 10)}
                        b={getRandomDouble(-10, 10)}
                        c={getRandomDouble(-10, 10)}/>
        )
}
function callComponent2(){

    ReactDOM.createRoot($("component2"))
        .render(
            <Component2 a={getRandomDouble(1, 10)}
                        h={getRandomDouble(1, 10)}/>
        )
}
function callComponent3(){

    ReactDOM.createRoot($("component3"))
        .render(
            <Component3 a={getRandomInt(1, 50)}/>
        )
}
function callComponent4(){

    ReactDOM.createRoot($("component4"))
        .render(
            <Component4 x={getRandomInt(-20, 20)}
                        y={getRandomInt(-20, 20)}/>
        )
}

(() => {
    callComponent1();
    callComponent2();
    callComponent3();
    callComponent4();
})()
