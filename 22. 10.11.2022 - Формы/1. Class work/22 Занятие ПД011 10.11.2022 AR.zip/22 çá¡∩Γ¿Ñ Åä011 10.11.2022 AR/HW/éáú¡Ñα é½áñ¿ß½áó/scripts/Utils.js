//Получение элемента
$ = (id) => {
    return document.getElementById(id);
};

//Генерация значений
function getRandomDouble(lo, hi) {
    return lo + (hi-lo)*Math.random();
}
function getRandomInt(lo, hi) {
    return  Math.round(lo + (hi-lo)*Math.random());
}

function getEquationRoots(a,b,c) {
    let d = b**2-4*a*c;

    //Вычислить кол-во корней
    return d>0 ? 2 : d === 0 ? 1 : 0;
}

//Периметр равнобедренного треугольника
function getTrianglePerimeter (a,h) {return a+2*Math.sqrt((a/2)**2+h**2)}

//Определение типа числа
function isPrimeNumber(num) {
    let res = num === 2 || num === 3;

    if (!res) {
        let n = num/2;

        for (let i = 2; i <= n; i++) {
            //Составное число
            if (num%i === 0){
                res = false;
                break;
            }

            //Простое число
            res = true;
        }
    }
    return res;
}

//Определение номера координатной плоскости
function getQuarterNumber(x,y) {
    return x>0 && y > 0 ? 1 :
            x < 0 && y > 0 ? 2 :
            x < 0 && y < 0 ? 3 :
            x > 0 && y < 0 ? 4 : 0;
}
