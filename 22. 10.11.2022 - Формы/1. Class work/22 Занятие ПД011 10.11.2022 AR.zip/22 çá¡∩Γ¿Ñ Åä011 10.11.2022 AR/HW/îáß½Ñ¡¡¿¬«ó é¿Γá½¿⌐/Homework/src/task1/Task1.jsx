const book = {
    image: "cover.jpg",
    author: "Стив Макконнелл",
    title: "Совершенный код",
    amount: 4,
    year: 1993,
    price: 800
};

const book2 = {
    image: "cover3.jpg",
    author: "Васильев А.Н.",
    title: "Программирование на JavaScript",
    amount: 8,
    year: 2019,
    price: 800
}

const product = {
    name: "Монитор 24\" AOC",
    nomenclature: "C24G2AE",
    image: "monitor.jpeg",
    price: 15590,
    amount: 5
};

const product2 = {
    name: "Монитор 32\" Philips",
    nomenclature: "32M1N5500VS",
    image: "monitor2.jpg",
    price: 35990,
    amount: 3
};

function Task1() {
    return (
        <>
            <div className="row mt-2">
                <div className="col-auto">
                    <Book amount={book.amount} author={book.author} image={book.image} year={book.year} price={book.price}
                          title={book.title}/>
                </div>
                <div className="col-auto">
                    <Book amount={book2.amount} author={book2.author} image={book2.image} year={book2.year} price={book2.price}
                          title={book2.title}/>
                </div>
                <div className="col-auto">
                    <Book/>
                </div>
            </div>

            <div className="row mt-5">
                <div className="col-auto">
                    <Product product={product}/>
                </div>
                <div className="col-auto">
                    <Product product={product2}/>
                </div>
                <div className="col-auto">
                    <Product/>
                </div>
            </div>
        </>
    );
}