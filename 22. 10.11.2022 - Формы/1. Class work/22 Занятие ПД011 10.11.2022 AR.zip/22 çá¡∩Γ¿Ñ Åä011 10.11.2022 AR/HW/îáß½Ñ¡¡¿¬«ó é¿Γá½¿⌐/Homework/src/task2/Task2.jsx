function Task2() {
    return (
        <>
            <div className="row mt-2">
                <div className="col-auto">
                    <Component1/>
                </div>
                <div className="col-auto">
                    <Component2/>
                </div>
            </div>

            <div className="row mt-5">
                <div className="col-auto">
                    <Component3/>
                </div>
                <div className="col-auto">
                    <Component4/>
                </div>
            </div>
        </>
    );
}