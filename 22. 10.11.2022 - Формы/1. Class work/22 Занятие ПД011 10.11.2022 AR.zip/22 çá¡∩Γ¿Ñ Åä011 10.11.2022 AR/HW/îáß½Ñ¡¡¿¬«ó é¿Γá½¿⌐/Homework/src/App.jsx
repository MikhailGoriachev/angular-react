class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = { title: "Главная" };
    }

    render() {
        return (
            <>
                <Header title={this.state.title}/>

                <div className="container-fluid mh-80-vh mt-4 px-5">
                    <TabPanel onSelect={title => this.setState({ title })}
                              tabs={[
                                  { title: "Главная", content: <Task/> },
                                  { title: "Задача 1", content: <Task1/> },
                                  { title: "Задача 2", content: <Task2/> },
                              ]}/>
                </div>

                <Footer/>
            </>
        );
    }
}