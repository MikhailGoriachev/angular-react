class Product extends React.Component {

    constructor(props) {
        super(props);
        this.state = { amount: props.product.amount };
    }

    incrementAmount = () => {
        this.setState({ amount: this.state.amount + 1 });
    }

    decrementAmount = () => {
        if (this.state.amount > 0)
            this.setState({ amount: this.state.amount - 1 });
    }

    render() {
        const product = this.props.product;

        return (
            <div className="card w-240-px">
                <img src={`images/products/${product.image}`} className="card-img-top" alt={product.name}/>
                <div className="card-header bg-body h-80-px">
                    <h5 className="card-title">{product.name}</h5>
                </div>
                <div className="card-body bg-body">
                    <ul className="list-group list-group-flush">
                        <li className="list-group-item">Артикул: {product.nomenclature}</li>
                        <li className="list-group-item">Цена: {product.price} ₽</li>
                        <li className="list-group-item">Количество: {this.state.amount}</li>
                    </ul>
                </div>
                <div className="card-footer bg-body">
                    <button onClick={this.incrementAmount} className="btn btn-outline-secondary px-3 ms-2"
                            title="Добавить в корзину">+
                    </button>
                    <button onClick={this.decrementAmount} className="btn btn-outline-secondary ms-2 px-3"
                            title="Убрать из корзины" disabled={!this.state.amount}>-
                    </button>
                </div>
            </div>
        );
    }
}

Product.defaultProps = {
    product: {
        name: "Монитор 27\" Acer Nitro",
        nomenclature: "VG270Sbmiipx",
        image: "monitor3.jpeg",
        price: 23990,
        amount: 1
    }
};