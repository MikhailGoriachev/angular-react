function TabPanel({ tabs, onSelect }) {
    return (
        <>
            <nav>
                <div className="nav nav-tabs mt-4" id="nav-tab" role="tablist">
                    {tabs.map((t, i) =>
                            <button className={`nav-link ${!i ? "active" : ""}`}
                                    data-bs-toggle="tab"
                                    data-bs-target={`#tab${i + 1}`}
                                    type="button"
                                    onClick={() => onSelect(t.title)}>
                                {t.title}
                            </button>)}
                </div>
            </nav>

            <div className="tab-content" id="tabs-content">
                {tabs.map((t, i) =>
                        <div className={`pt-4 tab-pane ${!i ? "fade show active" : ""}`}
                             id={`tab${i + 1}`}>
                            {t.content}
                        </div>)}
            </div>
        </>);
}


