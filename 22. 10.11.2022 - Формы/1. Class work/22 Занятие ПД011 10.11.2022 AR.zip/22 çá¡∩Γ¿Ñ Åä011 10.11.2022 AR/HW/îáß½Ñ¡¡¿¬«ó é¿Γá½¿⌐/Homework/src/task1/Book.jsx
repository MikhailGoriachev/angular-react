class Book extends React.Component {

    constructor(props) {
        super(props);

        this.state = { amount: props.amount };
    }

    incrementAmount = () => {
        this.setState({ amount: this.state.amount + 1 });
    }

    decrementAmount = () => {
        if (this.state.amount > 0)
            this.setState({ amount: this.state.amount - 1 });
    }

    render() {
        const { title, author, image, year, price } = this.props;

        return (
            <div className="card w-240-px">
                <img src={`images/books/${image}`} className="card-img-top" alt={title}/>
                <div className="card-header bg-body h-80-px">
                    <h5 className="card-title">{title}</h5>
                </div>
                <div className="card-body bg-body py-1">
                    <ul className="list-group list-group-flush">
                        <li className="list-group-item text-nowrap">Автор: {author}</li>
                        <li className="list-group-item">Год издания: {year}</li>
                        <li className="list-group-item">Цена: {price} ₽</li>
                        <li className="list-group-item">Количество: {this.state.amount}</li>
                    </ul>
                </div>
                <div className="card-footer bg-body">
                    <button onClick={this.incrementAmount} className="btn btn-outline-secondary px-3 ms-2"
                            title="Внести книгу">+
                    </button>
                    <button onClick={this.decrementAmount} className="btn btn-outline-secondary ms-2 px-3"
                            title="Списать книгу" disabled={!this.state.amount}>-
                    </button>
                </div>
            </div>
        );
    }
}

Book.defaultProps = {
    title: "Изучаем Java",
    author: "К. Бейтс",
    image: "cover2.jpg",
    year: 2019,
    price: 900,
    amount: 6
}