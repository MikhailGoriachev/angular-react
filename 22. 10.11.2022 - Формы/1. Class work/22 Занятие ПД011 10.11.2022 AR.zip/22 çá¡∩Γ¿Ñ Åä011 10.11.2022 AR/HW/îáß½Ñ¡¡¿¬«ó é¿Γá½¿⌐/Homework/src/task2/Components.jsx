// Количество корней квадратного уравнения
class Component1 extends React.Component {

    constructor(props) {
        super(props);
        this.state = { a: props.a, b: props.b, c: props.c, roots: null };
    }

    getNumRoots(a, b, c) {
        if (a === 0) return "не является квадратным уравнением"
        let d = b * b - 4 * a * c;
        return d < 0
            ? "нет корней"
            : d > 0
                ? 2
                : 1;
    }

    solve = () => {
        const a = getRandomInt(-10, 10);
        const b = getRandomInt(-10, 10);
        const c = getRandomInt(-10, 10);
        this.setState({ a, b, c, roots: this.getNumRoots(a, b, c) });
    }

    render() {
        return <div className="card  w-400-px">
            <div className="card-header">
                <h5 className="card-title">Компонент 1</h5>
                <p className="card-text">Количество корней квадратного уравнения</p>
            </div>
            <div className="card-body h-220-px">
                <ul className="list-group list-group-flush">
                    <li className="list-group-item">Коэффициент a: <b>{this.state.a}</b></li>
                    <li className="list-group-item">Коэффициент b: <b>{this.state.b}</b></li>
                    <li className="list-group-item">Коэффициент c: <b>{this.state.c}</b></li>
                    <li className="list-group-item">Количество корней: <b>{this.state.roots}</b></li>
                </ul>
            </div>
            <div className="card-footer">
                <button className="btn btn-outline-secondary" onClick={this.solve}>Вычислить</button>
            </div>
        </div>
    }
}

// Периметр равнобедренного треугольника
class Component2 extends React.Component {
    constructor(props) {
        super(props);
        this.state = { a: props.a, h: props.h, perimeter: null };
    }

    getPerimeter(a, h) {
        const side = Math.sqrt(Math.pow(a / 2, 2) + Math.pow(h, 2));
        return a + 2 * side;
    }

    solve = () => {
        const a = getRandom(1, 10);
        const h = getRandom(1, 10);
        this.setState({ a, h, perimeter: this.getPerimeter(a, h) });
    }

    render() {
        return <div className="card w-400-px">
            <div className="card-header">
                <h5 className="card-title">Компонент 2</h5>
                <p className="card-text">Периметр равнобедренного треугольника</p>
            </div>
            <div className="card-body h-220-px">
                <ul className="list-group list-group-flush">
                    <li className="list-group-item">Основание a: <b>{this.state.a?.toFixed(2)}</b></li>
                    <li className="list-group-item">Высота h: <b>{this.state.h?.toFixed(2)}</b></li>
                    <li className="list-group-item">Периметр: <b>{this.state.perimeter?.toFixed(2)}</b></li>
                </ul>
            </div>
            <div className="card-footer">
                <button className="btn btn-outline-secondary" onClick={this.solve}>Вычислить</button>
            </div>
        </div>
    }
}

// Проверка на простое число
class Component3 extends React.Component {
    constructor(props) {
        super(props);
        this.state = { a: this.props.a, result: null }
    }

    isNumberPrime = num => {
        for (let i = 2, s = Math.sqrt(num); i <= s; i++)
            if (num % i === 0) return "нет";
        return num > 1 ? "да" : "нет";
    }

    solve = () => {
        const a = getRandomInt(0, 20)
        this.setState({ a, result: this.isNumberPrime(a) });
    }

    render() {
        return <div className="card w-400-px">
            <div className="card-header">
                <h5 className="card-title">Компонент 3</h5>
                <p className="card-text">Проверка числа на простоту</p>
            </div>
            <div className="card-body h-160-px">
                <ul className="list-group list-group-flush">
                    <li className="list-group-item">Число a: <b>{this.state.a}</b></li>
                    <li className="list-group-item">Является простым числом: <b>{this.state.result}</b></li>
                </ul>
            </div>
            <div className="card-footer">
                <button className="btn btn-outline-secondary" onClick={this.solve}>Вычислить</button>
            </div>
        </div>
    }
}

// Определение номера координатной четверти
class Component4 extends React.Component {
    constructor(props) {
        super(props);
        this.state = { x: this.props.x, y: this.props.y, quadrant: null };
    }

    findQuadrant(x, y) {
        if (x === 0 || y === 0)
            return 'на оси координат';

        const xPos = x > 0;
        const yPos = y > 0;

        return 3 + xPos - yPos - 2 * xPos * yPos;
    }

    solve = () => {
        let x = getRandomInt(-10, 10);
        let y = getRandomInt(-10, 10);
        this.setState({ x, y, quadrant: this.findQuadrant(x, y) });
    }

    render() {
        return <div className="card w-400-px">
            <div className="card-header">
                <h5 className="card-title">Компонент 4</h5>
                <p className="card-text">Номер координатной плоскости точки</p>
            </div>
            <div className="card-body h-160-px">
                <ul className="list-group list-group-flush">
                    <li className="list-group-item">Координата x: <b>{this.state.x}</b></li>
                    <li className="list-group-item">Координата y: <b>{this.state.y}</b></li>
                    <li className="list-group-item">Номер плоскости: <b>{this.state.quadrant}</b></li>
                </ul>
            </div>
            <div className="card-footer">
                <button className="btn btn-outline-secondary" onClick={this.solve}>Вычислить</button>
            </div>
        </div>
    }
}
