import React, { useEffect, useState } from "react";
import { getRandomInt } from "../shared/utils";
import { Button, Card, ListGroup } from "react-bootstrap";

// Количество корней квадратного уравнения

export function Component1(props) {
    const [a, setA] = useState(props.a);
    const [b, setB] = useState(props.b);
    const [c, setC] = useState(props.c);
    const [roots, setRoots] = useState(null);

    useEffect(() => setRoots(getNumRoots(a, b, c)), [a, b, c]);

    const getNumRoots = (a, b, c) => {
        if (a === 0) return "не является квадратным уравнением"
        let d = b * b - 4 * a * c;
        return d < 0
            ? "нет корней"
            : d > 0
                ? 2
                : 1;
    }

    const generate = () => {
        setA(getRandomInt(-10, 10));
        setB(getRandomInt(-10, 10));
        setC(getRandomInt(-10, 10));
    }

    return (
        <>
            <Card className="w-400-px">
                <Card.Header>
                    <Card.Title>Компонент 1</Card.Title>
                    <Card.Text>Количество корней квадратного уравнения</Card.Text>
                </Card.Header>
                <Card.Body className="h-220-px">
                    <ListGroup variant="flush">
                        <ListGroup.Item>Коэффициент a: <b>{a}</b></ListGroup.Item>
                        <ListGroup.Item>Коэффициент b: <b>{b}</b></ListGroup.Item>
                        <ListGroup.Item>Коэффициент c: <b>{c}</b></ListGroup.Item>
                        <ListGroup.Item>Количество корней: <b>{roots}</b></ListGroup.Item>
                    </ListGroup>
                </Card.Body>
                <Card.Footer>
                    <Button variant="outline-primary" onClick={generate}>Вычислить</Button>
                </Card.Footer>
            </Card>
        </>
    );
}

Component1.defaultProps = { a: getRandomInt(-10, 10), b: getRandomInt(-10, 10), c: getRandomInt(-10, 10) };
