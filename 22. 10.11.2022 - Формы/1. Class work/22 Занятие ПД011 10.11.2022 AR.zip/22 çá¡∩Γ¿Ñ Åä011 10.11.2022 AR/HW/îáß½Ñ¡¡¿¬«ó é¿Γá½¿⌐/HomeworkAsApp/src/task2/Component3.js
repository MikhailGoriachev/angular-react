import React, { useEffect, useState } from "react";
import { getRandomInt } from "../shared/utils";
import { Button, Card, ListGroup } from "react-bootstrap";

// Проверка на простое число
export function Component3(props) {
    const [a, setA] = useState(props.a);
    const [result, setResult] = useState(false);

    useEffect(() => setResult(isNumberPrime(a)), [a]);

    const isNumberPrime = num => {
        for (let i = 2, s = Math.sqrt(num); i <= s; i++)
            if (num % i === 0) return "нет";
        return num > 1 ? "да" : "нет";
    }

    const generate = () => {
        setA(getRandomInt(0, 20));
    }

    return (
        <>
            <Card className="w-400-px">
                <Card.Header className="w-400-px">
                    <Card.Title>Компонент 3</Card.Title>
                    <Card.Text>Проверка числа на простоту</Card.Text>
                </Card.Header>
                <Card.Body className="h-160-px">
                    <ListGroup variant="flush">
                        <ListGroup.Item>Число a: <b>{a}</b></ListGroup.Item>
                        <ListGroup.Item>Является простым числом: <b>{result}</b></ListGroup.Item>
                    </ListGroup>
                </Card.Body>
                <Card.Footer>
                    <Button variant="outline-primary" onClick={generate}>Вычислить</Button>
                </Card.Footer>
            </Card>
        </>
    );
}

Component3.defaultProps = { a: getRandomInt(0, 20) }

