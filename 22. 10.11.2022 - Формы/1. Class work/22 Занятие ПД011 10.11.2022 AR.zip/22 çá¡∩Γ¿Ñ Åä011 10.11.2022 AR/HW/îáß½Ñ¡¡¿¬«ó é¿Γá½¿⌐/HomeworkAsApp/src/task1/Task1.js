import { Book } from "./Book";
import { Product } from "./Product";
import { Col, Row } from "react-bootstrap";

const book = {
    image: "cover.jpg",
    author: "Стив Макконнелл",
    title: "Совершенный код",
    amount: 4,
    year: 1993,
    price: 800
};

const book2 = {
    image: "cover3.jpg",
    author: "Васильев А.Н.",
    title: "Программирование на JavaScript",
    amount: 8,
    year: 2019,
    price: 800
}

const product = {
    name: "Монитор 24\" AOC",
    nomenclature: "C24G2AE",
    image: "monitor.jpeg",
    price: 15590,
    amount: 5
};

const product2 = {
    name: "Монитор 32\" Philips",
    nomenclature: "32M1N5500VS",
    image: "monitor2.jpg",
    price: 35990,
    amount: 3
};

export function Task1() {
    return (
        <>
            <Row className="mt-5">
                <Col md={"auto"}>
                    <Book book={book}/>
                </Col>
                <Col md={"auto"}>
                    <Book book={book2}/>
                </Col>
                <Col md={"auto"}>
                    <Book/>
                </Col>
            </Row>

            <Row className="mt-5">
                <Col md={"auto"}>
                    <Product product={product}/>
                </Col>
                <Col md={"auto"}>
                    <Product product={product2}/>
                </Col>
                <Col md={"auto"}>
                    <Product/>
                </Col>
            </Row>
        </>
    );
}