import { Col, Row } from "react-bootstrap";
import { Component1 } from "./Component1";
import { Component2 } from "./Component2";
import { Component3 } from "./Component3";
import { Component4 } from "./Component4";

export function Task2() {
    return (
        <>
            <Row className="mt-5">
                <Col md={"auto"}>
                    <Component1/>
                </Col>
                <Col md={"auto"}>
                    <Component2/>
                </Col>
            </Row>

            <Row className="mt-5">
                <Col md={"auto"}>
                    <Component3/>
                </Col>
                <Col md={"auto"}>
                    <Component4/>
                </Col>
            </Row>
        </>
    );
}