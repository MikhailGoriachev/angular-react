import React, { useEffect, useState } from "react";
import { getRandomInt } from "../shared/utils";
import { Button, Card, ListGroup } from "react-bootstrap";

// Определение номера координатной четверти
export function Component4(props) {
    const [x, setX] = useState(props.x);
    const [y, setY] = useState(props.y);
    const [quadrant, setQuadrant] = useState(0);

    useEffect(() => setQuadrant(findQuadrant(x, y)), [x, y]);

    const findQuadrant = (x, y) => {
        if (x === 0 || y === 0)
            return 'на оси координат';

        const xPos = x > 0;
        const yPos = y > 0;

        return 3 + xPos - yPos - 2 * xPos * yPos;
    }

    const generate = () => {
        setX(getRandomInt(-10, 10));
        setY(getRandomInt(-10, 10));
    }

    return (
        <>
            <Card className="w-400-px">
                <Card.Header className="w-400-px">
                    <Card.Title>Компонент 4</Card.Title>
                    <Card.Text>Номер координатной плоскости точки</Card.Text>
                </Card.Header>
                <Card.Body className="h-160-px">
                    <ListGroup variant="flush">
                        <ListGroup.Item>Координата x: <b>{x}</b></ListGroup.Item>
                        <ListGroup.Item>Координата y: <b>{y}</b></ListGroup.Item>
                        <ListGroup.Item>Номер плоскости: <b>{quadrant}</b></ListGroup.Item>
                    </ListGroup>
                </Card.Body>
                <Card.Footer>
                    <Button variant="outline-primary" onClick={generate}>Вычислить</Button>
                </Card.Footer>
            </Card>
        </>
    );
}

Component4.defaultProps = { x: getRandomInt(-10, 10), y: getRandomInt(-10, 10) }
