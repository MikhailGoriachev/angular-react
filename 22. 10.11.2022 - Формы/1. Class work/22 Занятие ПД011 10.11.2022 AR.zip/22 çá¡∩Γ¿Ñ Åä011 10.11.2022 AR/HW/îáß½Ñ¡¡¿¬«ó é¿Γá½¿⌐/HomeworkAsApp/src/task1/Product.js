import { Button, Card, ListGroup } from "react-bootstrap";
import { useState } from "react";

export function Product({ product }) {
    const [amount, setAmount] = useState(product.amount);

    return (
        <>
            <Card className="w-240-px">
                <Card.Img variant="top" src={`/images/products/${product.image}`} alt={product.name}/>
                <Card.Header className="bg-body h-80-px pt-3">
                    <Card.Title>{product.name}</Card.Title>
                </Card.Header>
                <Card.Body>
                    <ListGroup variant="flush">
                        <ListGroup.Item>Артикул: {product.nomenclature}</ListGroup.Item>
                        <ListGroup.Item>Цена: {product.price} ₽</ListGroup.Item>
                        <ListGroup.Item>Количество: {amount}</ListGroup.Item>
                    </ListGroup>
                </Card.Body>
                <Card.Footer>
                    <Button className="px-3 ms-2" onClick={() => setAmount(amount + 1)} variant="outline-primary"
                            title="Увеличить количество">
                        +
                    </Button>
                    <Button className="px-3 ms-2" onClick={() => setAmount(amount - 1)} variant="outline-primary"
                            title="Уменьшить количество"
                            disabled={!amount}>
                        -
                    </Button>
                </Card.Footer>
            </Card>
        </>
    );
}

Product.defaultProps = {
    product: {
        name: "Монитор 27\" Acer Nitro",
        nomenclature: "VG270Sbmiipx",
        image: "monitor3.jpeg",
        price: 23990,
        amount: 1
    }
};