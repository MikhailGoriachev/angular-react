import React, { useEffect, useState } from "react";
import { getRandom } from "../shared/utils";
import { Button, Card, ListGroup } from "react-bootstrap";

// Периметр равнобедренного треугольника
export function Component2(props) {
    const [a, setA] = useState(props.a);
    const [h, setH] = useState(props.h);
    const [perimeter, setPerimeter] = useState(0);

    useEffect(() => setPerimeter(getPerimeter(a, h)), [a, h]);

    const getPerimeter = (a, h) => {
        const side = Math.sqrt(Math.pow(a / 2, 2) + Math.pow(h, 2));
        return a + 2 * side;
    }

    const generate = () => {
        setA(getRandom(1, 10));
        setH(getRandom(1, 10));
    }

    return (
        <>
            <Card className="w-400-px">
                <Card.Header className="w-400-px">
                    <Card.Title>Компонент 2</Card.Title>
                    <Card.Text>Периметр равнобедренного треугольника</Card.Text>
                </Card.Header>
                <Card.Body className="h-220-px">
                    <ListGroup variant="flush">
                        <ListGroup.Item>Основание a: <b>{a?.toFixed(2)}</b></ListGroup.Item>
                        <ListGroup.Item>Высота h: <b>{h?.toFixed(2)}</b></ListGroup.Item>
                        <ListGroup.Item>Периметр: <b>{perimeter?.toFixed(2)}</b></ListGroup.Item>
                    </ListGroup>
                </Card.Body>
                <Card.Footer>
                    <Button variant="outline-primary" onClick={generate}>Вычислить</Button>
                </Card.Footer>
            </Card>
        </>);
}

Component2.defaultProps = { a: getRandom(1, 10), h: getRandom(1, 10) };

