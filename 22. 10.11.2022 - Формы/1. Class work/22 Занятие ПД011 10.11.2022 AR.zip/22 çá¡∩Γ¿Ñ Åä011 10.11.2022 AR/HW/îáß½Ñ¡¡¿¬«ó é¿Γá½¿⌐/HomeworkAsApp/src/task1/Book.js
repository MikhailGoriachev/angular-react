import { Button, Card, ListGroup } from "react-bootstrap";
import { useState } from "react";


export function Book({ book }) {
    const [amount, setAmount] = useState(book.amount);

    return (
        <>
            <Card className="w-240-px">
                <Card.Img variant="top" src={`/images/books/${book.image}`} alt={book.title}/>
                <Card.Header className="bg-body h-80-px pt-2">
                    <Card.Title>{book.title}</Card.Title>
                </Card.Header>
                <Card.Body>
                    <ListGroup variant="flush">
                        <ListGroup.Item className="text-nowrap">Автор: {book.author}</ListGroup.Item>
                        <ListGroup.Item>Год издания: {book.year}</ListGroup.Item>
                        <ListGroup.Item>Цена: {book.price} ₽</ListGroup.Item>
                        <ListGroup.Item>Количество: {amount}</ListGroup.Item>
                    </ListGroup>
                </Card.Body>
                <Card.Footer>
                    <Button className="px-3 ms-2" onClick={() => setAmount(amount + 1)} variant="outline-primary" title="Внести книгу">
                        +
                    </Button>
                    <Button className="px-3 ms-2" onClick={() => setAmount(amount - 1)} variant="outline-primary" title="Списать книгу"
                            disabled={!amount}>
                        -
                    </Button>
                </Card.Footer>
            </Card>
        </>);
}


Book.defaultProps = {
    book: {
        title: "Изучаем Java",
        author: "К. Бейтс",
        image: "cover2.jpg",
        year: 2019,
        price: 900,
        amount: 6
    }
}