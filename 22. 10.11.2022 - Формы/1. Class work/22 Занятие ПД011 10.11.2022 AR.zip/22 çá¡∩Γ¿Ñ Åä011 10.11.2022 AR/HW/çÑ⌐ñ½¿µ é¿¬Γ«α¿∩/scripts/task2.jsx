// Компонент 1
// Определить количество корней квадратного уравнения.
// пропсы: начальные значения a, b, c
// стейт: a, b, c, кол-во корней
// по клику на кнопку меняем стейт
class Component1 extends React.Component {
    constructor(props) {
        super(props);

        // копируем пропсы в стейт
        this.state = {a: props.a, b: props.b, c: props.c, roots: 0};

        this.clickSolve = this.clickSolve.bind(this);
    }

    // определение количества корней квадратного уравнения
    getNumRoots(a, b, c) {
        let d = b * b - 4 * a * c;
        return d < 0 ? 0 : d > 0 ? 2 : 1;
    }

    // клик по кнопке для решения задачи
    clickSolve() {
        let a = getRand(-10, 10).toFixed(3);
        let b = getRand(-10, 10).toFixed(3);
        let c = getRand(-10, 10).toFixed(3);

        this.setState({a: a, b: b, c: c, roots: this.getNumRoots(a, b, c)});
    } // clickSolve

    render() {
        return  <div className="card">
            <div className="card-header">
                <h4 className="text-center">Компонент 1</h4>
            </div>
            <div className="card-body">
                <h5 className="card-title">Количество корней квадратного уравнения</h5>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item">коэффициент a: <b>{this.state.a}</b></li>
                <li className="list-group-item">коэффициент b: <b>{this.state.b}</b></li>
                <li className="list-group-item">коэффициент c: <b>{this.state.c}</b></li>
                <li className="list-group-item">количество корней: <b>{this.state.roots}</b></li>
            </ul>
            <div className="card-footer text-center">
                <button className="btn btn-outline-primary" onClick={this.clickSolve}>Вычислить</button>
            </div>
        </div>
    }
} // class Component1

// Компонент 2.
// Найти периметр равнобедренного треугольника по его основанию a и высоте h, проведенной к основанию
// пропсы: начальные значения a, h
// стейт: a, h, p
// по клику на кнопку меняем стейт
class Component2 extends React.Component {
    constructor(props) {
        super(props);
        // копируем пропсы в стейт
        this.state = {a: props.a, h: props.h, p: this.getPerimeter(props.a, props.h)};

        this.clickSolve = this.clickSolve.bind(this);
    }

    // вычисление периметр равнобедренного треугольника
    getPerimeter(a, h) {
        // длина боковой стороны
        let l = Math.sqrt(((a/2)**2) + h**2);
       return a + 2*l;
    }

    // клик по кнопке для решения задачи
    clickSolve() {
        let a = getRand(1, 5);
        let h = getRand(1, 7);

        this.setState({a: a, h: h, p: this.getPerimeter(a, h)});
    } // clickSolve


    render() {
        return  <div className="card">
            <div className="card-header">
                <h4 className="text-center">Компонент 2</h4>
            </div>
            <div className="card-body">
                <h5 className="card-title">Периметр равнобедренного треугольника</h5>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item">Основание a: <b>{this.state.a.toFixed(3)}</b></li>
                <li className="list-group-item">Высота h: <b>{this.state.h.toFixed(3)}</b></li>
                <li className="list-group-item">периметр: <b>{this.state.p.toFixed(3)}</b></li>

            </ul>
            <div className="card-footer text-center">
                <button className="btn btn-outline-primary" onClick={this.clickSolve}>Вычислить</button>
            </div>
        </div>
    }

} // class Component2

// Компонент 3.
// Опредлить является ли простым числом число a
// пропсы: начальное значение a
// стейт: a, результат проверки
// по клику на кнопку меняем стейт
class Component3 extends React.Component {
    constructor(props) {
        super(props);
        // копируем пропсы в стейт
        this.state = {a: props.a, simpleNum: ""};

        this.clickSolve = this.clickSolve.bind(this);
    }

    // опредлить является ли простым числом
    getSimple(a) {
        let j = Math.sqrt(a);
        for(let i = 2; i <= j; i++)
            if(a % i === 0)
                return false;
        return true;
    }

    // клик по кнопке для решения задачи
    clickSolve() {
        let a = Math.round(getRand(5, 100));

        this.setState({a: a, simpleNum: this.getSimple(a)?"Простое число":"Составное число"});
    } // clickSolve

    render() {
        return  <div className="card">
            <div className="card-header">
                <h3 className="text-center">Компонент 3</h3>
            </div>
            <div className="card-body">
                <p className="card-title">Проверка числа на простоту</p>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item">Число a: <b>{this.state.a}</b></li>
                <li className="list-group-item">Результат проверки: <b>{this.state.simpleNum}</b></li>
            </ul>
            <div className="card-footer text-center">
                <button className="btn btn-outline-primary" onClick={this.clickSolve}>Вычислить</button>
            </div>
        </div>
    }

} // class Component3

// Компонент 4.
// Определить номер координатной четверти, в которой находится точка
// с ненулевыми координатами (x, y).
// пропсы: начальные значения x, y
// стейт: x, y, номер координатной плоскости
// по клику на кнопку меняем стейт
class Component4 extends React.Component {
    constructor(props) {
        super(props);
        // копируем пропсы в стейт
        this.state = {x: props.x, y: props.y, numPlane: 0};

        this.clickSolve = this.clickSolve.bind(this);
    }

    getCoordinates(x, y) {
        if (x>0 && y>0){ return 1;}
        if (x<0 && y>0){ return 2;}
        if (x<0 && y<0){ return 3;}
        if (x>0 && y<0){ return 4;}
    }

    // клик по кнопке для решения задачи
    clickSolve() {
        let x = Math.round(getRand(-10, 10));
        let y = Math.round(getRand(-10, 10));

        this.setState({x: x, y: y, numPlane: this.getCoordinates(x, y)});

    } // clickSolve

    render() {
        return  <div className="card">
            <div className="card-header">
                <h3 className="text-center">Компонент 4</h3>
            </div>
            <div className="card-body">
                <p className="card-title">Номер координатной плоскости точки</p>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item">Координата x: <b>{this.state.x}</b></li>
                <li className="list-group-item">Координата y: <b>{this.state.y}</b></li>
                <li className="list-group-item">Номер плоскости: <b>{this.state.numPlane}</b></li>
            </ul>
            <div className="card-footer text-center">
                <button className="btn btn-outline-primary" onClick={this.clickSolve}>Вычислить</button>
            </div>
        </div>
    }


} // class Component4


// вывод компонентов
ReactDOM.createRoot(document.getElementById("app"))
    .render(
            <div className="row p-5">
                <div className="col-sm-6">
                    <Component1 a={1} b={2} c={5} />
                </div>

                <div className="col-sm-6">
                    <Component2 a={3.2} h={5.8}/>
                </div>

                <div className="col-sm-6 mt-5">
                    <Component3 />
                </div>

                <div className="col-sm-6 mt-5">
                    <Component4 />
                </div>
            </div>
    );


// генерация случайного вещественного числа
function getRand(from, to) {
    return from + (to - from)*Math.random();
} // getRand