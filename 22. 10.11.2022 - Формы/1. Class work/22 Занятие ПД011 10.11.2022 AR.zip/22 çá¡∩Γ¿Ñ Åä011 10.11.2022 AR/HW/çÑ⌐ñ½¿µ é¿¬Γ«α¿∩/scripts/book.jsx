// объект данных о книге:
// название, автор,
// год издания, цена,
// количество книг, изображение обложки
class Book {
    constructor(title, author, year, total, price, image) {
        this.title = title;
        this.author = author;
        this.year = year;
        this.total = total;
        this.price = price;
        this.image = image;
    }
} // class Book

let book1 = new Book('FullStack React', 'Нейт Мюррей', 2015, 5, 2048, 'book1.jpg' )
let book2 = new Book('Рефакторинг', 'Мартин Фаурель', 2005, 3, 1520, 'book2.jpg' )

class BookComponent extends React.Component{
    constructor(props) {
        super(props);

        // копируем пропсы в стейт
        this.state = {total: props.total};

        this.clickIncrement = this.clickIncrement.bind(this);
        this.clickDecrement = this.clickDecrement.bind(this);
    }


    // обработчик клика по кнопке
    clickIncrement() {
        this.setState({total: this.state.total+1});
    }

    clickDecrement() {
        if (this.state.total > 0)
            this.setState({total: this.state.total-1});
    }

    // рендеринга компонента
    render() {

        return <>
            <div className="card w-20rem">
            <div className="card-header">
                <img srcSet={`../img/${this.props.image}`} className="d-block mx-auto h-20rem" alt="book"/>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item">Название: <b>{this.props.title}</b></li>
                <li className="list-group-item">Автор: <b>{this.props.author}</b></li>
                <li className="list-group-item">Год издания: <b>{this.props.year}</b></li>
                <li className="list-group-item">Цена: <b>{this.props.price} ₽</b></li>
                <li className="list-group-item">Количество: <b id="booksAmount">{this.state.total}</b></li>

            </ul>
                <div className="card-footer">
                    <button className="btn btn-outline-primary" onClick={this.clickIncrement}>Добавить</button>
                    <button className="btn btn-outline-success mx-3" onClick={this.clickDecrement}>Списать</button>
                </div>
            </div>

            <div className="col-auto ms-3 lead">
                Стоимость книг в библиотеке: <h5 id="booksSummary">всего на сумму: {this.state.total * this.props.price}</h5>
            </div>

        </>

    } // render

} // class BookComponent

// статическое свойство - значения props по умолчанию
BookComponent.defaultProps = {title: "Тест", author: "Тест", year: "2000", price: "1000", total: "1"};

ReactDOM.createRoot(document.getElementById("app"))
    .render(
        <div className="row">
           <div className="col-4">
            <BookComponent image={book1.image} title={book1.title} author={book1.author} year={book1.year} price={book1.price} total={book1.total}/>
           </div>
        </div>
    );