// объект данных о товаре:
// наименование, артикул,
// цена, количество,
// изображение товара

class Product {
    constructor(name, vendorCode, price, total, image) {
        this.name = name;
        this.vendorCode = vendorCode;
        this.price = price;
        this.total = total;
        this.image = image;
    }
} // class Book

let product1 = new Product('Ноутбук ASUS Zenbook Flip S', '364869', 45800, 2, 'product1.jpg');
let product2 = new Product('Ноутбук GIGABYTE Aero 15', '524571', 65200, 1, 'product2.jpg');

class ProductComponent extends React.Component{
    constructor(props) {
        super(props);

        // копируем пропсы в стейт
        this.state = {total: props.total};

        this.clickIncrement = this.clickIncrement.bind(this);
        this.clickDecrement = this.clickDecrement.bind(this);
    }

    getAdd(){
        this.state.total++;
        document.querySelector("#productsAmount").innerHTML = `${this.state.total}`;
        document.querySelector("#productsSummary").innerHTML = `всего на сумму: ${this.state.total * this.props.price}`;
        return this.state.total;

    }

    getRemove(){
        if (this.state.total > 0)
        this.state.total--;

        document.querySelector("#productsAmount").innerHTML = `${this.state.total}`;
        document.querySelector("#productsSummary").innerHTML = `всего на сумму: ${this.state.total * this.props.price}`;
        return this.state.total;
    }

    // обработчик клика по кнопке
    clickIncrement() {
        this.setState({total: this.getAdd()});
    }

    clickDecrement() {
        this.setState({total: this.getRemove()});
    }

    // рендеринга компонента
    render() {

        return <div>
            <div className="card w-20rem">
                <div className="card-header">
                    <img srcSet={`../img/${this.props.image}`} className="card-img-top d-block mx-auto h-15rem" alt="product"/>
                </div>
                <ul className="list-group list-group-flush">
                    <li className="list-group-item">Название: <b>{this.props.name}</b></li>
                    <li className="list-group-item">Артикул: <b>{this.props.vendorCode}</b></li>
                    <li className="list-group-item">Цена: <b>{this.props.price} ₽</b></li>
                    <li className="list-group-item">Количество: <b id="productsAmount">{this.state.total}</b></li>
                </ul>
                <div className="card-footer">
                    <button className="btn btn-outline-primary" onClick={this.clickIncrement}>Добавить</button>
                    <button className="btn btn-outline-success mx-3" onClick={this.clickDecrement}>Удалить</button>
                </div>
            </div>

        </div>


    } // render

} // class ProductComponent

ProductComponent.defaultProps = {name: "Тест", vendorCode: "000001", price: "1000", total: "1"};

ReactDOM.createRoot(document.getElementById("app"))
    .render(
        <div className="row">
            <div className="col-4">
                <ProductComponent image={product1.image} name={product1.name} vendorCode={product1.vendorCode} price={product1.price} total={product1.total}/>
            </div>

            <div className="col-auto ms-3 lead">
                Стоимость товаров в корзине: <h5 id="productsSummary">Товара</h5>
            </div>
        </div>
    );