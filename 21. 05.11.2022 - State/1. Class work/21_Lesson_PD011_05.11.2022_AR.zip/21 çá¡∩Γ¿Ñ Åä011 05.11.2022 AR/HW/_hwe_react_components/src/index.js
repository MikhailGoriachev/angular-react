// класс, представляющий книгу
// название, автор, год издания, цена, количество в библиотеке, изображение обложки
class Book {
    constructor(id, title, author, published, quantity, price, cover) {
        this.bookId = id;
        this.bookTitle = title;
        this.author = author;
        this.published = published;
        this.quantity = quantity;
        this.price = price;
        this.cover = cover;
    }
} // class Book

// объект, представляющий товар
// наименование, артикул, цена, количество, изображение товара
class Product {
    constructor(id, name, articul, price, quantity, image) {
        this.productId = id;
        this.productName = name;
        this.articul = articul;
        this.price = price;
        this.quantity = quantity;
        this.image = image;
    }
} // class Product

let book1 = new Book(42, 'React в действии', 'Томас М.Т.', 2019, 3, 860, 'images/cover1.jpg');
let book2 = new Book(24, 'React быстро', 'Мардан А.', 2019, 4, 720, 'images/cover2.jpg');
let totalBook = book1.quantity + book2.quantity;
let amountBook = book1.price * book1.quantity + book2.price * book2.quantity;

let product1 = new Product(24, 'Насос погружной бочковой ЗУБР НПБ-300',
    '1424538', 4050, 12, 'images/product1.jpg');
let product2 = new Product(28, 'Насос погружной бочковой ЗУБР НПБ-600',
    '1424542', 6150, 3, 'images/product2.jpg');
let amountProduct = product1.price * product1.quantity  + product1.price * product2.quantity;

// компонент React для вывода сведений о книге
class BookComponent extends React.Component {
    constructor(props) {
        super(props);
    } // constructor

    // Метод, продолжающий обработку события
    addClick = (book1, book2) => {
        book1.quantity++;
        book2.quantity++;

        totalBook = book1.quantity + book2.quantity;
        amountBook = book1.price * book1.quantity + book2.price * book2.quantity;
        document.querySelector('#libraryTotal').innerHTML =
            `Книг в библиотеке: <b>${totalBook}</b> на сумму ${amountBook} руб.`;
    } // addClick

    // Метод, продолжающая обработку события
    removeClick = (book1, book2) => {
        if (book1.quantity > 0) book1.quantity--;
        if (book2.quantity > 0) book2.quantity--;

        totalBook = book1.quantity + book2.quantity;
        amountBook = book1.price * book1.quantity + book2.price * book2.quantity;

        document.querySelector('#libraryTotal').innerHTML =
            `Книг в библиотеке: <b>${totalBook}</b> на сумму ${amountBook} руб.`;
    } // removeClick

    // обязательный метод для рендеринга компонента
    render() {
        // для простоты определим функцию-обработчик события прямо в разметке
        return  <div className="card">
            <img src={this.props.value.image} className="card-img-top w-50 mx-auto"
                 alt={this.props.value.bookTitle}/>
            <div className="card-body">
                <h5 className="card-title">{this.props.value.author}</h5>
                <p className="card-text">{this.props.value.bookTitle}</p>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item">год издания: <b>{this.props.value.published}</b></li>
                <li className="list-group-item">цена: <b>{this.props.value.price}</b></li>
            </ul>
            <div className="card-footer">
                <button className="btn btn-outline-success" onClick={() => this.addClick(book1, book2)}>+1</button>
                <button className="btn btn-outline-secondary" onClick={() => this.removeClick(book1, book2)}>-1</button>
            </div>
        </div>
    } // render
} // class BookComponent
BookComponent.defaultProps = {value: {
        bookId: book2.bookId,
        bookTitle: book2.bookTitle,
        author: book2.author,
        published: book2.published,
        price: book2.price,
        quantity: book2.quantity,
        cover: book2.cover}};

// компонент React для вывода сведений о товаре
class ProductComponent extends React.Component {
    constructor(props) {
        super(props);
    } // constructor

    // Метод, продолжающий обработку события
    addClick = (product1, product2) => {
        product1.quantity++;
        product2.quantity++;

        amountProduct = product1.price * product1.quantity  + product1.price * product2.quantity;
        document.querySelector('#basketTotal').innerHTML =
            `Товаров в корзине на сумму: <b>${amountProduct}</b> руб.`;
    } // addClick

    // Метод, продолжающий обработку события
    removeClick = (product1, product2) => {
        if (product1.quantity > 0) product1.quantity--;
        if (product2.quantity > 0) product2.quantity--;

        amountProduct = product1.price * product1.quantity  + product1.price * product2.quantity;
        document.querySelector('#basketTotal').innerHTML =
            `Товаров в корзине на сумму: <b>${amountProduct}</b> руб.`;
    } // removeClick

    // обязательный метод для рендеринга компонента
    render() {
        return <div className="card">
            <img src={this.props.product.image} className="card-img-top w-50 mx-auto" alt={this.props.product.productName}/>
            <div className="card-body">
                <h5 className="card-title">{this.props.product.productName}</h5>
                <p className="card-text">lorem ipsum dolor sit amet...</p>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item">артикул: {this.props.product.articul}</li>
                <li className="list-group-item">количество: {this.props.product.quantity}</li>
                <li className="list-group-item">цена: {this.props.product.price}</li>
            </ul>
            <div className="card-footer">
                <button className="btn btn-outline-success" onClick={() => this.addClick(product1, product2)}>+1</button>
                <button className="btn btn-outline-secondary" onClick={() => this.removeClick(product1, product2)}>-1</button>
            </div>
        </div>
    } // render
} // class ProductComponent
ProductComponent.defaultProps = {product: {
        productId:   product2.productId,
        productName: product2.productName,
        articul:     product2.articul,
        quantity:    product2.quantity,
        price:       product2.price,
        image:       product2.image
    }};