//Получение элемента
$ = (id) => {
    let elem = document.getElementById(id)
    /*console.log(`Element by id:${id}`);
    console.dir(elem)*/
    return elem;
};

//Генерация значений
function getRandomDouble(lo, hi) {
    return lo + (hi-lo)*Math.random();
}
function getRandomInt(lo, hi) {
    return  Math.round(lo + (hi-lo)*Math.random());
}