﻿/* 
*  Задача 1. 
* Установите Node.JS, и с его помощью установите TypeScript глобально. 
* Разработайте приложение TypeScript с выводом обработанных данных на 
* страницу HTML по заданию.
* Создайте класс с открытыми полями a, b для хранения параметров вычисления
* выражений 14 и 15, методами z1v14(), z2v14(), z1v15(), z2v15() для вычислений
*  z1, z2 выражений 14, 15 соответственно.
* 
* Выполните вычисления для 5 пар значений a, b. 
*
* */

class Calc {
    // открытые свойства/поля класса - по заданию
    public a: number;
    public b: number;

    // конструктор с параметрами
    constructor(a: number = 0, b: number = 5) {
        this.a = a;
        this.b = b;
    } // constructor
    
    // методы класса для вычислений по заданию
    
    // Вычисление z1 по варианту 14
    z1v14(): number {
        return (Math.cos(this.a) + Math.sin(this.a)) / (Math.cos(this.a) - Math.sin(this.a));
    } // z1v14
    
    // Вычисление z2 по варианту 14
    z2v14(): number {
        return Math.tan(2*this.a) + 1 / Math.cos(2 * this.a); 
    } // z2v14

    // Вычисление z1 по варианту 15
    z1v15(): number {
        return Math.sqrt(2 * this.b + 2 * Math.sqrt(this.b**2 - 4)) /
            (Math.sqrt(this.b * this.b - 4) + this.b + 2);
    } // z1v15
    
    // Вычисление z2 по варианту 15
    z2v15(): number {
        return 1 / Math.sqrt(this.b + 2);
    } // z2v15
} // class Calc

// функция - генератор случайных чисел
function getRand(from: number, to: number): number {
    return from + (to - from)*Math.random();
} // getRand

// настройка события загрузки страницы на слушателя этого события
window.addEventListener('load', handler, true);

// обработчик события - вычисление по заданию, на 5 парах случайных чисел
function handler() {
    // количество циклов вычисления
    const n: number = 5;

    // нижняя граница для варианат 14 - произвольное значение
    const low14: number = -10;

    // нижняя граница для варианта 15 - из области определения варианта 15
    const low15 = 2;

    const high = 10;

    // объект для работы с ним
    let calc = new Calc();

    // разметка для вывода исходных данных и результатов
    let tableRows: string = '';

    // цикл обработки по заданию
    for (let i = 1; i <= n; i++) {
        // очередной набор данных
        calc.a = getRand(low14, high);
        calc.b = getRand(low15, high);

        // вычислить результат и вывести его
        let z1v14 = calc.z1v14();
        let z2v14 = calc.z2v14();
        let z1v15 = calc.z1v15();
        let z2v15 = calc.z2v15();

        tableRows = tableRows.concat(`
            <tr>
            <td>${i}</td>
            <td>${calc.a.toFixed(3)}</td>
            <td>${calc.b.toFixed(3)}</td>
            <td>${z1v14.toFixed(7)}</td>
            <td>${z2v14.toFixed(7)}</td>
            <td>${z1v15.toFixed(7)}</td>
            <td>${z2v15.toFixed(7)}</td>
            </tr>`);
    } // for i

    // вывод сформированного тела таблицы
    document.getElementById('out-result').innerHTML = tableRows;
} // handler