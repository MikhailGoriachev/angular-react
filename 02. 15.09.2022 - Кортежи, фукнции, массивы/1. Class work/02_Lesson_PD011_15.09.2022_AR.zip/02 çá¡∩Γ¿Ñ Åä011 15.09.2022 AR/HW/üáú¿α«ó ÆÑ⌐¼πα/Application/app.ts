// класс Примера
class Expression{
   
    // поля класса
    public a:number;
    public b:number;

    // конструктор
    constructor(a: number, b: number) {
        this.a = a;
        this.b = b;
    }

    // вычисление z1 в 14 варианте
    z1v14():number{
        // для упрощения записи примера
        let a = this.a
        let solution = (Math.cos(a) + Math.sin(a)) / (Math.cos(a) - Math.sin(a));
        return solution
    }

    // вычисление z2 в 14 варианте
    z2v14():number{
        let solution = Math.tan(2 * this.a) + 1 / Math.cos(2 * this.a); 
        return solution
    }

    // вычисление z1 в 15 варианте
    z1v15():number {
        // для упрощения записи примера
        let b = this.b
        let solution = (Math.sqrt(2 * b + 2 * Math.sqrt(b * b - 4))) / (Math.sqrt(b * b - 4) + b + 2);
        return solution
    }

    // вычисление z2 в 15 варианте
    z2v15():number{
        let solution = 1 / Math.sqrt(this.b + 2); 
        return solution
    }
} // class Instance

// генератор случайных чисел
function randomNumber(min:number, max:number){
    if (min >= max) return -1;
    return Math.random() * (max - min) + min;
}

// кол-во выводов подсчета выражений
const N = 5;
for (let i = 0; i < N; i++) {
    
    // диапозон для генерации
    let max = 30, min = 10;
    
    // кол-во цифр после запятой
    let factionDigits = 6;
    
    // получаем строку таблицы, по ее id
    let tr = document.getElementById(`Expression${i+1}`);
    
    // инициализация, параметры генерируются
    let expr = new Expression(randomNumber(min,max), randomNumber(min,max));
    tr.getElementsByTagName('td')[0].innerHTML = `${expr.a.toFixed(factionDigits)}`;
    tr.getElementsByTagName('td')[1].innerHTML = `${expr.b.toFixed(factionDigits)}`;
    tr.getElementsByTagName('td')[2].innerHTML = `${expr.z1v14().toFixed(factionDigits)}`;
    tr.getElementsByTagName('td')[3].innerHTML = `${expr.z2v14().toFixed(factionDigits)}`;
    tr.getElementsByTagName('td')[4].innerHTML = `${expr.z1v15().toFixed(factionDigits)}`;
    tr.getElementsByTagName('td')[5].innerHTML = `${expr.z2v15().toFixed(factionDigits)}`;
} 
 
