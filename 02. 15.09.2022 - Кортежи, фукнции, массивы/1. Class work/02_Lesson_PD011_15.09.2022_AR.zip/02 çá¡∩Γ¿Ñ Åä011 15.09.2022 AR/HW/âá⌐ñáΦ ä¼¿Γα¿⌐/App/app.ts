// класс Примера
class Instance{
    // поля класса
    public a:number;
    public b:number;

    // Конструктор
    constructor(a: number, b: number) {
        this.a = a;
        this.b = b;
    }

    //методы класса
    z1v14():number{
        let solution = (Math.cos(this.a)+Math.sin(this.a))/(Math.cos(this.a)-Math.sin(this.a));
        return solution;
    }

    z2v14():number{
        let solution = Math.tan(2*this.a)+1/Math.cos(2*this.a);
        return solution;
    }

    z1v15():number{
        let solution = (Math.sqrt(2*this.b+2*Math.sqrt(this.b*this.b-4)))/(Math.sqrt(this.b*this.b-4)+this.b+2);
        return solution;
    }

    z2v15():number{
        let solution = 1/(Math.sqrt(this.b+2));
        return solution;
    }

} // class Instance

// кол-во выводов
const N = 5

for (let i = 0; i < N; i++) {
    let div = document.getElementById(`Solution${i+1}`);
    let inst = new Instance(21.5+i, 21.5-i);

    div.getElementsByTagName('p')[0].innerHTML = `<h3>z1v14 = ${inst.z1v14()}</h3>`;
    div.getElementsByTagName('p')[1].innerHTML = `<h3>z2v14 = ${inst.z2v14()}</h3>`;
    div.getElementsByTagName('p')[2].innerHTML = `<h3>z1v15 = ${inst.z1v15()}</h3>`;
    div.getElementsByTagName('p')[3].innerHTML = `<h3>z2v15 = ${inst.z2v15()}</h3>`;
}
