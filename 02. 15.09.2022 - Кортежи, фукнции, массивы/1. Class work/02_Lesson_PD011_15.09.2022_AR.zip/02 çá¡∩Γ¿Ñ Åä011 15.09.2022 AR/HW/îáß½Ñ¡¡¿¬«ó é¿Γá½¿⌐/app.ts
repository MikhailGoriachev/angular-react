﻿class Task1 {
    constructor(public a: number, public b: number) {
        this.a = a;
        this.b = b;
    }
    
    z1v14() {
        return (Math.cos(this.a) + Math.sin(this.a)) / (Math.cos(this.a) - Math.sin(this.a));
    }
    
    z2v14() {
        return Math.tan(2 * this.a) + 1 / Math.cos(2 * this.a);
    }
    
    z1v15() {
        let buffered: number = Math.sqrt(this.b * this.b - 4);
        return (Math.sqrt(2 * this.b + 2 * buffered)) / (buffered + this.b + 2);
    }
    
    z2v15() {
        return 1 / Math.sqrt(this.b + 2);
    }
    
    getSolvedV14Html() {
        return `<div>z1 = <span class="text-secondary">${this.z1v14().toFixed(10)}</span></div> 
                <div>z2 = <span class="text-secondary">${this.z2v14().toFixed(10)}</span></div>`;
    }

    getSolvedV15Html() {
        return `<div>z1 = <span class="text-secondary">${this.z1v15().toFixed(10)}</span></div>
                <div>z2 = <span class="text-secondary">${this.z2v15().toFixed(10)}</span></div>`;
    }

    getParametersHtml() {
        return `<div>a = <span class="text-secondary">${this.a.toFixed(10)}</span></div>
                <div>b = <span class="text-secondary">${this.b.toFixed(10)}</span></div>`;
    }
    
}

window.addEventListener("load", () => {
    $("task").style.display = "none";
    
    $("pageHome").addEventListener("click", () => {
        $("brief").style.display = "block";
        $("task").style.display = "none";
        $("pageHome").classList.add("active");
        $("pageTask1").classList.remove("active");
    });
    
    $("pageTask1").addEventListener("click", () => {
        $("brief").style.display = "none";
        $("task").style.display = "block";
        $("pageHome").classList.remove("active");
        $("pageTask1").classList.add("active");
        $("output").innerHTML = "";
        
        const counts = 5;
        const minGenerateNum = 5;
        const maxGenerateNum = 20;
        let task1 : Task1;
        
        for (let i = 0; i < counts; i++) {
            task1 = new Task1(getRandom(minGenerateNum,maxGenerateNum), getRandom(minGenerateNum,maxGenerateNum));
            
            $("output").innerHTML += 
                `<tr><td>${i + 1}</td><td>14</td><td>${task1.getParametersHtml()}</td><td>${task1.getSolvedV14Html()}</td></tr>
                 <tr><td>${i + 1}</td><td>15</td><td>${task1.getParametersHtml()}</td><td>${task1.getSolvedV15Html()}</td></tr>`;
        }        
    })
})

function getRandom(min: number, max: number){
    return Math.random() * (max - min) + min;
}

function $(element: string) {
    return document.getElementById(element)!;
}

