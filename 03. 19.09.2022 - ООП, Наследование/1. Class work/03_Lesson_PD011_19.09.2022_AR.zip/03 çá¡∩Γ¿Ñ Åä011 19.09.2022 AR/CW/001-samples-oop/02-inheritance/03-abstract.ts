// abstract - ключевое слово, которое позволяет создавать абстрактные методы
// и абстрактные классы.
// Абстрактный класс - это класс, который может выступать только в роли
// базового класса.
// Создать экземпляр абстрактного класса не получится.
// Абстрактный метод - это метод, который не имеет реализации в текущем
// классе, но обязательно должен быть реализован в производном классе.
// Абстрактные методы могут создаваться только в абстрактных классах.

abstract class Animal { // абстрактный класс
    constructor(public name: string) { }

    abstract makeSound(); // абстрактный метод

    public move(): void {
        console.log(this.name + " передвигается")
    }
} // class Animal

class Cat extends Animal {
    constructor() {
        super("Кот");
    }

    // обязательная реализация абстрактного метода из базового класса.
    // Попробуйте удалить этот метод из класса Cat
    makeSound() {
        console.log("Мяу-Мяу");
    }
} // class Cat


class Cow extends Animal {
    constructor() {
        super("Корова");
    }

    makeSound() {
        console.log("Му-у-у-у");
    }
} // class Cow

// -------------------------------------------------------------------

let murzik: Cat = new Cat();
murzik.makeSound();
murzik.move();

let burenka: Cow = new Cow();
burenka.makeSound();
burenka.move();
