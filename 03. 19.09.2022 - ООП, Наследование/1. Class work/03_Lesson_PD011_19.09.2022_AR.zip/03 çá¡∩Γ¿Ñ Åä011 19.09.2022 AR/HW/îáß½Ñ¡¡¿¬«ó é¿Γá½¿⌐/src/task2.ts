﻿// Тип кортежа для средних арифметического и геометрического
type Means = [aMean: number | undefined, gMean: number | undefined];

// Перечисления для именованного обращения к элементам кортежа Means
enum MeansEnum { aMean, gMean }

class Calc {
    // Мин. и макс. значения чисел для генерации
    private static _defMinValue = -10 as const;
    private static _defMaxValue = 10 as const;
    
    constructor(public x: number = Utils.getRandomInt(Calc._defMinValue, Calc._defMaxValue),
                public y: number = Utils.getRandomInt(Calc._defMinValue, Calc._defMaxValue)) {
    }    
    
    // Заполнить x и y случайными значениями 
    fillRandomXY(minValue: number = Calc._defMinValue, maxValue: number = Calc._defMaxValue) {
        this.x = Utils.getRandomInt(minValue, maxValue);
        this.y = Utils.getRandomInt(minValue, maxValue);
    }

    // Вычислить ср. арифметическое и ср. геометрическое двух чисел
    mean() {
        return Calc.mean(this.x, this.y);
    }
    
    // Вычислить ср. арифметическое и ср. геометрическое двух чисел
    static mean(x: number, y: number): Means {
        return x >= 0 && y >= 0 
            ? [(x + y) / 2, Math.sqrt(x * y)] 
            : [undefined, undefined];
    }    
}

// Вычисления и рендеринг по заданию
function initTask2(){
    let task2 = new Calc();
    
    const counts = 5;

    for (let i = 0; i < counts; i++) {
        const mean = task2.mean();
        
        $("#output").append($("<tr/>")
            .append($("<td/>").text(i + 1))
            .append($("<td/>").text(task2.x))
            .append($("<td/>").text(task2.y))
            .append($("<td/>").text( mean[MeansEnum.aMean] ?? "—"))
            .append($("<td/>").text(mean[MeansEnum.gMean]?.toFixed(2) ?? "—"))
            );
        
        task2.fillRandomXY();
    }
}

$(() => initTask2());