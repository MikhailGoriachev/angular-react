﻿
// Класс с обработками по первой задаче
class Task1 {
    constructor(public array: number[] = Utils.createIntArray(16, -10, 10)) {
    }
    
    // Количество элементов в массиве, равных нулю
    zeroesCount(): number { return this.array.filter(v => v === 0).length; }

    // Количество отрицательных элементов в массиве
    negativesCount(): number { return this.array.filter(v => v < 0).length; }
    
    // Сумма элементов массива, расположенных после последнего вхождения элемента с минимальным значением
    sumAfterMin(): number {
        return this.array.slice(this.array.lastIndexOf(Math.min(...this.array)) + 1)
            .reduce((acc,cur) => acc + cur, 0);
    }

    // Сумма модулей элементов массива, расположенных после минимального по модулю элемента
    sumAbsAfterMinAbs(): number {
        let lastMinAbsIndex = this.array.lastIndexOf(Math.min(...this.array.map(v => Math.abs(v))));
        return this.array.slice(lastMinAbsIndex + 1)
            .reduce((acc,cur) => acc + Math.abs(cur), 0);
    }
    
    // Массив, упорядоченный по возрастанию модулей
    orderedByAbs(): number[] {
        return this.array.sort((a, b) => Math.abs(a) - Math.abs(b));
    }
    
    // Массив с замененными всеми отрицательными элементами на их квадраты и упорядоченный по возрастанию элементов
    replaceNegativesAndSort(): number[] {
        return this.array.map(v => v < 0 ? v * v : v)
            .sort((a, b) => a - b);
    }
    
    // Данные массива для вывода в HTML-разметку
    arrayToHtml(): JQuery {
        return Task1.arrayToHtml(this.array);
    }

    // Данные массива для вывода в HTML-разметку с выделенными нулями 
    arrayToHtmlHighlightZeroes(): JQuery {
        return Task1.arrayToHtml(this.array, (v) => v > 0);
    }

    // Данные массива для вывода в HTML-разметку с выделенными отрицательными значениями
    arrayToHtmlHighlightNegatives(): JQuery {
        return Task1.arrayToHtml(this.array, (v) => v < 0);
    }

    // Данные массива для вывода в HTML-разметку с выделенными элементов, расположенных после минимального
    arrayToHtmlHighlightAfterMin(): JQuery {
        return Task1.arrayToHtml(this.array, (v, i) => 
            i > this.array.lastIndexOf(Math.min(...this.array)));
    }

    // Данные массива для вывода в HTML-разметку с выделенными элементов, расположенных после минимального по модулю
    arrayToHtmlHighlightAfterMinAbs(): JQuery {
        return Task1.arrayToHtml(this.array, (v, i) => 
            i > this.array.lastIndexOf(Math.min(...this.array.map(v => Math.abs(v)))));
    }

    // Данные массива для вывода в HTML-разметку c подстветкой по предикату
    static arrayToHtml(array: number[],
                       highlightPredic: (v: number, i: number) => boolean = () => false): JQuery {
        return array.reduce<JQuery>((acc,cur, ind) => 
                acc.append($("<td/>")
                    .text(cur)
                    .addClass("px-3")
                    .addClass(highlightPredic(cur, ind) ? "table-active color-1" : "")),
                $("<tr/>"));
    }
}

// Рендеринг обработок по заданию
function initTask1() {
    let task1 = new Task1();

    $("#outputMain").append(task1.arrayToHtml());

    $("#outputZeroes").append(task1.arrayToHtmlHighlightZeroes());
    $("#outputZeroesCount").text(task1.zeroesCount());

    $("#outputNegatives").append(task1.arrayToHtmlHighlightNegatives());
    $("#outputNegativesCount").text(task1.negativesCount());

    $("#outputAfterMin").append(task1.arrayToHtmlHighlightAfterMin());
    $("#outputAfterMinSum").text(task1.sumAfterMin());

    $("#outputAfterMinAbs").append(task1.arrayToHtmlHighlightAfterMinAbs());
    $("#outputAfterMinAbsSumAbs").text(task1.sumAbsAfterMinAbs());

    $("#outputAbsOrdered").append(Task1.arrayToHtml(task1.orderedByAbs()));

    $("#outputReplaceNegAndSort").append(Task1.arrayToHtml(task1.replaceNegativesAndSort()));
}

$(() => initTask1());

