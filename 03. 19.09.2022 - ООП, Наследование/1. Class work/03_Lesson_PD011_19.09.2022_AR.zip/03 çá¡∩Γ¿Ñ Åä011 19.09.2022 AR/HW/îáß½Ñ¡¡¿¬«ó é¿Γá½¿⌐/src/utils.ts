﻿
class Utils {
    // Генерация случайного вещественного числа
    static getRandom(min: number, max:number): number {
        return Math.random() * (max - min) + min;
    }

    // Генерация случайного целого числа
    static getRandomInt(min: number, max: number): number {
        return Math.floor(Math.random() * (max - min + 1) + min);
    }
    
    static getCoupleRandomInts(min: number, max: number): [number, number] {
        return [this.getRandomInt(min, max), this.getRandomInt(min, max)];
    }
    
    // Генерация массива вещественных значений
    static createArray(size: number, min: number, max: number): number[] {
        return [...Array(size)].map(_ => this.getRandom(min, max));
    }

    // Генерация массива целочисленных значений
    static createIntArray(size: number, min: number, max: number): number[] {
        return [...Array(size)].map(_ => this.getRandomInt(min, max));
    }
}