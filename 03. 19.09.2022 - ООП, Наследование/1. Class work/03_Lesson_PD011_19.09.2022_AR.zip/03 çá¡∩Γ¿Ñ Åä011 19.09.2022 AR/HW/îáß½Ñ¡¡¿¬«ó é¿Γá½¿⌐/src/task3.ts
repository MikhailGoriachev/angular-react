﻿// Тип кортежа для пары координат точки
type Coord = [x: number, y: number];

// Перечисления для именованного обращения к элементам кортежа Coord
enum CoordEnum { X, Y}

// Тип кортежа для вычисления периметра и площади прямоугольника
type RectangleCalcs = [perimeter: number, area: number];

// Перечисления для именованного обращения к элементам кортежа RectangleCalcs
enum RectangleCalcsEnum { Perimeter, Area}

class Rectangle {
    // Мин. и макс. значения чисел для генерации
    private static _defMinValue = -10 as const;
    private static _defMaxValue = 10 as const;
    
    constructor(public vertex1: Coord = Utils.getCoupleRandomInts(Rectangle._defMinValue, Rectangle._defMaxValue),
                public vertex2: Coord = Utils.getCoupleRandomInts(Rectangle._defMinValue, Rectangle._defMaxValue)) {
    }

    // Заполнить значения вершин прямоугольника случайными значениями 
    fillVerticesRandom(minValue: number = Rectangle._defMinValue, maxValue: number = Rectangle._defMaxValue) {
        this.vertex1 = Utils.getCoupleRandomInts(Rectangle._defMinValue, Rectangle._defMaxValue);
        this.vertex2 = Utils.getCoupleRandomInts(Rectangle._defMinValue, Rectangle._defMaxValue);
    }
    
    // Вычислить периметр и площадь прямоугольника
    rectPS(): RectangleCalcs {
        return Rectangle.rectPS(this.vertex1, this.vertex2);
    }

    // Вычислить периметр и площадь прямоугольника
    static rectPS(vertex1: Coord, vertex2: Coord) : RectangleCalcs {
        const sideA = Math.abs(vertex1[CoordEnum.X] - vertex2[CoordEnum.X]);
        const sideB = Math.abs(vertex1[CoordEnum.Y] - vertex2[CoordEnum.Y]);
        
        return [2 * (sideA + sideB), sideA * sideB];
    }
    
    static vertexToString(vertex: Coord): string {
        return `x = ${vertex[CoordEnum.X]},  y = ${vertex[CoordEnum.Y]}`;
    }
}

// Вычисления и рендеринг по заданию
function initTask3() {
    let task3 = new Rectangle();

    const counts = 3;

    for (let i = 0; i < counts; i++) {
        const rectangleCalcs = task3.rectPS();

        $("#output").append($("<tr/>")
            .append($("<td/>").text(i + 1))
            .append($("<td/>").text(Rectangle.vertexToString(task3.vertex1)))
            .append($("<td/>").text(Rectangle.vertexToString(task3.vertex2)))
            .append($("<td/>").text(rectangleCalcs[RectangleCalcsEnum.Perimeter]))
            .append($("<td/>").text(rectangleCalcs[RectangleCalcsEnum.Area]))
        );

        task3.fillVerticesRandom();
    }
}

$(() => initTask3());