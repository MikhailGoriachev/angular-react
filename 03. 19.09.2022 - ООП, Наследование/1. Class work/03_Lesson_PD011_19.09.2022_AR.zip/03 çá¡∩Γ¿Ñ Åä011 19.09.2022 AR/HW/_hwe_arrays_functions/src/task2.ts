﻿/* 
* Задача 2.
* Описать функцию mean(x, y), вычисляющую среднее арифметическое aMean=(x+y)/2
* и среднее геометрическое gMean=√(x∙y), двух положительных чисел x и y.
* Возвращать aMean, gMean из функции в кортеже. С помощью этой функции найти
* среднее арифметическое и среднее геометрическое для трех пар случайных чисел
* из диапазона значений [-10, 10].
*
* */

// настройка события загрузки страницы на слушателя этого события
window.addEventListener('load', task2, true);

// обработчик события - вычисление по заданию
function task2() {
    const n = 3;
    const lo = -10, hi = 10;
    let data: [x: number, y: number, aMean: number, gMean: number][] = [];

    //  Вычисление средних арифметических и средних геометрических
    // n пар случайных чисел
    for (let i = 0; i < n; i++) {
        let x = getRand(lo, hi);  // x
        let y = getRand(lo, hi);  // y

        let aMean, gMean;
        [aMean, gMean] = mean(x, y);

        // добавление очередного блока данных в массив для визуализации
        data.push([x, y, aMean, gMean]);
    } // for i

    // вывод массива сформированных данных в таблицу на странице
    let row = 1;
    $("task2-out").innerHTML = data
        .reduce((acc, datum) => acc +
        `<tr class="text-end me-5">
            <td>${row++}</td>
            <td>${datum[0].toFixed(3)}</td>
            <td>${datum[1].toFixed(3)}</td>
            <td>${datum[2].toFixed(3)}</td>
            <td>${datum[3].toFixed(3)}</td>
        </tr>`, "");
} // task2

// вычисляет среднее арифметическое aMean и среднее геометрическое
// gMean, двух положительных чисел x и y
function mean(x: number, y: number): [aMean: number, gMean: number] {
    // при некорректных параметрах не выполнять вычислений
    if (x < 0 || y < 0) return [0, 0];

    // вычисление средних арифметического и геометрического по заданию
    let aMean = (x + y) / 2;
    let gMean = Math.sqrt(x * y);

    // вернуть кортеж с результатами
    return [aMean, gMean];
} // mean