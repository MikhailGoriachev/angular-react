﻿/* 
*  Задача 3.
* Описать функцию rectPS(x1, y1, x2, y2), вычисляющую периметр и площадь
* прямоугольника со сторонами, параллельными осям координат, по координатам
* (x1, y1), (x2, y2) его противоположных вершин. Функция возвращает кортеж
* с периметром и площадью. С помощью этой функции найти периметры и площади
* трех прямоугольников с данными противоположными вершинами.
*
* */

// настройка события загрузки страницы на слушателя этого события
window.addEventListener('load', task3, true);

// обработчик события - вычисление по заданию
function task3() {
    const n = 3;
    const lo = -10, hi = 10;
    let data: [x1: number, y1: number, x2: number, y2: number, perimeter: number, area: number][] = [];

    //  Вычисление периметра и площади трех прямоугольников с данными
    //  противоположными вершинами
    for (let i = 0; i < n; i++) {
        let x1 = getRand(lo, hi);  // x1
        let y1 = getRand(lo, hi);  // y1
        let x2 = getRand(lo, hi);  // x2
        let y2 = getRand(lo, hi);  // y2

        let perimeter, area;
        [perimeter, area] = rectPS(x1, y1, x2, y2);

        data.push([x1, y1, x2, y2, perimeter, area]);
    } // for i

    // вывод массива сформированных данных в таблицу на странице
    let row = 1;
    $("task3-out").innerHTML = data.reduce((acc, datum) => acc +
       `<tr class="text-end me-5">
            <td>${row++}</td>
            <td>${datum[0].toFixed(3)}</td>
            <td>${datum[1].toFixed(3)}</td>
            <td>${datum[2].toFixed(3)}</td>
            <td>${datum[3].toFixed(3)}</td>
            <td>${datum[4].toFixed(3)}</td>
            <td>${datum[5].toFixed(3)}</td>
        </tr>`, "");
} // task3

// Функция вычисляет периметр и площадь прямоугольника со сторонами,
// параллельными осям координат, по координатам (x1, y1), (x2, y2)
// его противоположных вершин.
function rectPS(x1: number, y1: number, x2: number, y2: number): [perimeter: number, area: number] {
    // длины сторон прямоугольников
    let a = Math.abs(x1 - x2);
    let b = Math.abs(y1 - y2);

    // периметр
    let perimeter = 2* (a + b);

    // площадь
    let area = a * b;

    return [perimeter, area];
} // rectPS