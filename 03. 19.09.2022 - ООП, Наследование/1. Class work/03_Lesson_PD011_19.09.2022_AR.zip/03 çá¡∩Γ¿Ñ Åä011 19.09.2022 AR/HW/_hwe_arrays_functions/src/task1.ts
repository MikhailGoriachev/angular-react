﻿/* 
*  Задача 1. 
* В одномерном массиве, состоящем из n чисел вычислить:
*     • Количество элементов массива, равных нулю
*     • Количество отрицательных элементов массива
*     • Сумму элементов массива, расположенных после
*       минимального элемента
*     • Сумму модулей элементов массива, расположенных
*       после минимального по модулю элемента
*     • Упорядочить элементы массива по возрастанию модулей
*     • Заменить все отрицательные элементы массива их квадратами
*       и упорядочить элементы массива по возрастанию
*
* */


// настройка события загрузки страницы на слушателя этого события
window.addEventListener('load', task1, true);

// обработчик события - вычисление по заданию
function task1() {
    // создание и заполнение массива n случайными числами
    let data: number[] = createArray(Math.floor(getRand(12, 22)));

    // вывод массива в разметку
    $('task1-src-array').innerHTML = data.reduce(
        (acc, datum) => acc + `<td>${datum.toFixed(3)}</td>`,
        '');

    // Количество элементов массива, равных нулю
    let zeroes = data.filter(datum => datum === 0).length;
    $("task1-zeroes").innerHTML = `${zeroes}`;

    // Количество отрицательных элементов массива
    let negatives = data.filter(datum => datum < 0).length;
    $("task1-negatives").innerHTML = `${negatives}`;

    // Сумму элементов массива, расположенных после
    // минимального элемента
    let sumAfterMin = data
        .slice(data.lastIndexOf(Math.min(...data)) + 1)
        .reduce((acc, datum) => acc + datum, 0);
    $("task1-sum-after-min").innerHTML = `${sumAfterMin.toFixed(3)}`;

    // Сумму модулей элементов массива, расположенных
    // после минимального по модулю элемента
    let dataAbs = data.map(datum => Math.abs(datum));
    let sumAfterMinAbs = data
        .slice(dataAbs.lastIndexOf(Math.min(...dataAbs)) + 1)
        .reduce((acc, datum) => acc + Math.abs(datum), 0);
    $("task1-sum-after-min-abs").innerHTML = `${sumAfterMinAbs.toFixed(3)}`;

    // Упорядочить элементы массива по возрастанию модулей
    data = data.sort((a, b) =>  Math.abs(a) - Math.abs(b));

    // вывод упорядоченного массива
    $('task1-array-abs-ordered').innerHTML = data.reduce(
        (acc, datum) => acc + `<td>${datum.toFixed(3)}</td>`,
        '');

    // Заменить все отрицательные элементы массива их квадратами
    // и упорядочить элементы массива по возрастанию
    data = data
        .map(datum => datum < 0? datum**2:datum)
        .sort();

    // вывод преобразованного и упорядоченного массива
    $('task1-array-map-ordered').innerHTML = data.reduce(
        (acc, datum) => acc + `<td>${datum.toFixed(3)}</td>`,
        '');
} // task1