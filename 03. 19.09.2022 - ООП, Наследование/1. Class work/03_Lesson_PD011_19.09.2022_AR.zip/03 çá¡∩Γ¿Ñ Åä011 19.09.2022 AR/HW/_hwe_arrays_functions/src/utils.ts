// функция - генератор случайных чисел, все значения по модулю меньшие 1
// заменяем нулями
function getRand(from: number, to: number): number {
    let value: number = from + (to - from)*Math.random();
    if (Math.abs(value) < 1) {
        value = 0;
    } // if

    return value
} // getRand

// Генерация массива из n элементов, заполненного случайными числами
function createArray(n: number, lo: number = -10, hi: number = 10): number[] {
    return [...Array(n)].map(item => this.getRand(lo, hi));
} // createArray

// поиск элемента DOM-дерева по его идентификатору
function $(id: string) {
    return document.getElementById(id);
} // $