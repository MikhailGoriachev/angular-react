// Решение задачи 2

//region Компонент 1
// Определить количество корней квадратного уравнения.
// пропсы: начальные значения a, b, c
// стейт: a, b, c, кол-во корней
// по клику на кнопку меняем стейт
class Component1 extends React.Component {

    constructor(props) {
        super(props);

        // копируем пропсы в стейт
        this.state = {a: props.a, b: props.b, c: props.c, roots: this.getNumRoots(props.a, props.b, props.c)};

		// обработчик клика на кнопку "Вычислить"
        this["clickSolve"] = this.clickSolve.bind(this);

        // создание ссылок (рефов) для полей ввода
        this.coefA = React.createRef();
        this.coefB = React.createRef();
        this.coefC = React.createRef();
    }

    // определение количества корней квадратного уравнения
    getNumRoots(a, b, c) {
        let d = b * b - 4 * a * c;
        return d < 0 ? 0 : d > 0 ? 2 : 1;
    }

    // клик по кнопке для решения задачи
    clickSolve(e) {
        // обязательный вызов
		e.preventDefault();

        let a = +this.coefA.current.value;
        let b = +this.coefB.current.value;
        let c = +this.coefC.current.value;

        this.setState({a: a, b: b, c: c, roots: this.getNumRoots(a, b, c)});
    } // clickSolve

    render() {
        return <div className="card">
            <div className="card-body">
                <h5 className="card-title">Компонент 1</h5>
                <p className="card-text">Количество корней квадратного уравнения</p>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item d-flex justify-content-between">Коэффициент
                    a: <b>{this.state.a.toFixed(5)}</b></li>
                <li className="list-group-item d-flex justify-content-between">Коэффициент
                    b: <b>{this.state.b.toFixed(5)}</b></li>
                <li className="list-group-item d-flex justify-content-between">Коэффициент
                    c: <b>{this.state.c.toFixed(5)}</b></li>
                <li className="list-group-item d-flex justify-content-between">Количество
                    корней: <b>{this.state.roots}</b></li>
            </ul>
            <div className="card-footer p-3">
				<form onSubmit={this.clickSolve}>
                    <div className="row mb-3">
                        <div className="col-3 me-3">
                            <label className="form-label">a:</label>
                            <input ref={this.coefA} type="number" step="any" className="form-control"/>
                        </div>

                        <div className="col-3 me-3">
                            <label className="form-label">b:</label>
                            <input ref={this.coefB} type="number" step="any" className="form-control"/>
                        </div>

                        <div className="col-3 me-3">
                            <label className="form-label">c:</label>
                            <input ref={this.coefC} type="number" step="any" className="form-control"/>
                        </div>
                    </div>
					
					<div className="mb-3">
						<input type="submit" className="btn btn-outline-success" value="Вычислить"/>
					</div>	
				</form>
            </div>
        </div>
    }
}
//endregion


//region Компонент 2
// Найти периметр равнобедренного треугольника по его основанию a и высоте h,
// проведенной к основанию. Пропсы: начальные значения a, h. Стейт: a, h, p.
// По клику на кнопку меняем стейт.
// Вводимые данные должны быть положительными, не нулевыми.
class Component2 extends React.Component {
    constructor(props) {
        super(props);

        // копируем пропсы в стейт
        // потенциальная проблема - всегда считаем исходные данные валидными...
        this.state = {
            a: props.a,
            h: props.h,
            isValidA: this.isValidA(props.a),
            isValidH: this.isValidH(props.h),
            p: this.perimeter(props.a, props.h)
        };

        // создание ссылок (рефов) для полей ввода
        this.a = React.createRef();
        this.h = React.createRef();

        this.clickSolve = this.clickSolve.bind(this);
        this.onChangeA = this.onChangeA.bind(this);
        this.onChangeH = this.onChangeH.bind(this);
    } // constructor

    // проверка валидности полей ввода для основания a и высоты h
    isValidA(a) { return isPositive(a); }
    isValidH(h) { return isPositive(h); }

    // обработчик изменения поля ввода A
    onChangeA(e) {
        let val = +e.target.value;
        let valid = this.isValidA(val);

        // т.к. напрямую вывод в компонент недоступен, то в p
        // записываем значение, приводящее к очистке поля вывода
        // !! Очистка - нашим кодом в методе render() !!
        this.setState({a: val, isValidA: valid, p: Number.NaN});
    } // onChangeA

    // обработчик изменения поля ввода H
    onChangeH(e) {
        let val = +e.target.value;
        let valid = this.isValidH(val);

        // т.к. напрямую вывод в компонент недоступен, то в p
        // записываем значение, приводящее к очистке поля вывода
        // !! Очистка - нашим кодом в методе render() !!
        this.setState({h: val, isValidH: valid, p: Number.NaN});
    } // onChangeA


    // вычисление периметра равнобедренного треугольника по заданию
    perimeter(a, h) {
        return a + 2 * Math.sqrt(a * a / 4 + h * h);
    } // perimeter

    // клик по кнопке для решения задачи
    clickSolve(e) {
        // обязательный вызов для React
        e.preventDefault();

        // при невалидных полях не выполняем вычислений
        if (!this.state.isValidA || !this.state.isValidH) return;

        let a = +this.a.current.value;
        let h = +this.h.current.value;

        this.setState({a: a, h: h, p: this.perimeter(a, h)});
    } // clickSolve

    render() {
        let p = this.state.p;

        return <div className="card">
            <div className="card-body">
                <h5 className="card-title">Компонент 2</h5>
                <p className="card-text">Периметр равнобедренного треугольника</p>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item d-flex justify-content-between">Основание
                    a: <b>{this.state.a.toFixed(5)}</b></li>
                <li className="list-group-item d-flex justify-content-between">Высота
                    h: <b>{this.state.h.toFixed(5)}</b></li>
                <li className="list-group-item">&nbsp;</li>
                <li className="list-group-item d-flex justify-content-between">Периметр:
                    <b>{Number.isNaN(p)?"":p.toFixed(5)}</b>
                </li>
            </ul>
            <div className="card-footer">
                <form onSubmit={this.clickSolve}>
                    <div className="row mb-3">
                        <div className="col-5 me-3">
                            <label className="form-label">Основание a:</label>
                            <input ref={this.a} type="number" step="any"
                                   onChange={this.onChangeA}
                                   className={`form-control ${this.state.isValidA?"":"is-invalid"}`}/>
                        </div>

                        <div className="col-5">
                            <label className="form-label">Высота h:</label>
                            <input ref={this.h} type="number" step="any"
                                   onChange={this.onChangeH}
                                   className={`form-control ${this.state.isValidH?"":"is-invalid"}`}/>
                        </div>
                    </div>

                    <div className="mb-3">
                        <input type="submit" className="btn btn-outline-success" value="Вычислить"/>
                    </div>
                </form>
            </div>
        </div>
    }
}
//endregion


//region Компонент 3
// Определить, является ли простым числом число a. Пропсы: начальное значение a.
// Стейт: a, результат проверки.
// По клику на кнопку меняем стейт.
// Проверяемое число должно быть положительным, не нулевым.
class Component3 extends React.Component {
    constructor(props) {
        super(props);

        // копируем пропсы в стейт
        this.state = {a: props.a, isValid: this.isValidA(props.a), r: this.isPrime(props.a)};

        // создание ссылки на поле ввода
        this.a = React.createRef();

        // привязка к контенту класса обрабтчика клика по кнопке
        this.clickSolve = this.clickSolve.bind(this);
        this.onChangeA = this.onChangeA.bind(this);
    } // constructor

    // проверка валидности поля a
    isValidA(a) { return a > 0; }

    // обработчик изменения поля ввода A
    onChangeA(e) {
        let val = +e.target.value;
        let valid = this.isValidA(val);

        // т.к. напрямую вывод в компонент недоступен, то в r
        // записываем значение, приводящее к очистке поля вывода
        // !! Очистка - нашим кодом в методе render() !!
        this.setState({a: val, isValid: valid, r: Number.NaN});
    } // onChangeA

    // возвращает true, если число простое и false, если число составное
    isPrime(a) {
        let n = Math.sqrt(a);

        for (let i = 2; i < n; i++) {
            if (a % i === 0) return false;
        }
        return true;
    } // isPrime

    // клик по кнопке для решения задачи
    clickSolve(e) {
        e.preventDefault();

        // не выполняем вычислений при невалидном поле данных
        if (!this.state.isValid) return;

        // получение числа из поля ввода формы
        let a = +this.a.current.value;

        this.setState({a: a, r: this.isPrime(a)});
    } // clickSolve

    render() {
        // для упрощения доступа к полю состояния
        let isValid = this.state.isValid;

        return <div className="card">
            <div className="card-body">
                <h5 className="card-title">Компонент 3</h5>
                <p className="card-text">Проверка числа на простоту</p>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item d-flex justify-content-between">Число a: <b>{this.state.a}</b></li>
                <li className="list-group-item">&nbsp;</li>
                <li className="list-group-item">&nbsp;</li>
                <li className="list-group-item d-flex justify-content-between">Результат проверки:
                    <b>{Number.isNaN(this.state.r)?"":(this.state.r?"простое":"составное")}</b></li>
            </ul>
            <div className="card-footer">
                <form onSubmit={this.clickSolve}>
                    <div className="my-3">
                        <label className="form-label">Значение для проверки:</label>
                        <input ref={this.a} onChange={this.onChangeA} type="number"
                               className={`form-control ${isValid?'':'is-invalid'}`}/>
                    </div>

                    <div className="mb-3">
                        <input type="submit" className="btn btn-outline-success" value="Вычислить"/>
                    </div>
                </form>
            </div>
        </div>
    }
}
//endregion


//region Компонент 4
// Определить номер координатной четверти, в которой находится точка с ненулевыми
// координатами (x, y). Пропсы: начальные значения x, y. Стейт: x, y, номер
// координатной плоскости.
// По клику на кнопку меняем стейт
class Component4 extends React.Component {
    constructor(props) {
        super(props);

        // копируем пропсы в стейт
        this.state = {x: props.x, y: props.y, n: this.getQuarter(props.x, props.y)};

        // создание ссылок (рефов) для полей ввода
        this.x = React.createRef();
        this.y = React.createRef();

        this.clickSolve = this.clickSolve.bind(this);
    } // constructor

    // определение номера координатной плоскости по значениям координат точки
    getQuarter(x, y) {
        return x >= 0 && y >= 0? 1 : x < 0 && y >= 0? 2: x < 0 && y < 0?3:4;
    } // getQuarter

    // клик по кнопке для решения задачи
    clickSolve(e) {
        // обязательный вызов :)
        e.preventDefault();

        let x = +this.x.current.value;
        let y = +this.y.current.value;

        this.setState({x: x, y: y, n: this.getQuarter(x, y)});
    } // clickSolve

    render() {
        return <div className="card">
            <div className="card-body">
                <h5 className="card-title">Компонент 4</h5>
                <p className="card-text">Номер координатной плоскости точки</p>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item d-flex justify-content-between">Координата x: <b>{this.state.x.toFixed(2)}</b></li>
                <li className="list-group-item d-flex justify-content-between">Координата y: <b>{this.state.y.toFixed(2)}</b></li>
                <li className="list-group-item">&nbsp;</li>
                <li className="list-group-item d-flex justify-content-between">Номер плоскости: <b>{this.state.n}</b></li>
            </ul>
            <div className="card-footer">
                <form onSubmit={this.clickSolve}>
                    <div className="row mb-3">
                        <div className="col-5 me-3">
                            <label className="form-label">x:</label>
                            <input ref={this.x} type="number" step="any" className="form-control"/>
                        </div>

                        <div className="col-5">
                            <label className="form-label">y:</label>
                            <input ref={this.y} type="number" step="any" className="form-control"/>
                        </div>
                    </div>

                    <div className="mb-3">
                        <input type="submit" className="btn btn-outline-success" value="Вычислить"/>
                    </div>
                </form>
            </div>
        </div>
    }
}

// вывод компонентов
ReactDOM.createRoot(document.getElementById("app"))
.render(
    <div className="row mt-5 p-5">
        <div className="col-4 mt-3">
            <Component1 a={getRand(-10, 10)} b={getRand(-10, 10)} c={getRand(-10, 10)}/>
        </div>

        <div className="col-4 mt-3">
            <Component2 a={getRand(1, 10)} h={getRand(1, 10)}/>
        </div>

        <div className="col-4 mt-3">
            <Component3 a={Math.floor(getRand(10, 1000))}/>
        </div>

        <div className="col-4 mt-3">
            <Component4 x={getRand(-100, 100)} y={getRand(-100, 100)}/>
        </div>
    </div>
);
//endregion