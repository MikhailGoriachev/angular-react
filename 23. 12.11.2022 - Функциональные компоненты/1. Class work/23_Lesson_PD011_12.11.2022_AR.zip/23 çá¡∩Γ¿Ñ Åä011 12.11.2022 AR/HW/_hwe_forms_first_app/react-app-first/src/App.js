let minTemperature = -31;
let maxTemperature = 41;

function App() {
  return (
    <>
      <p className="my-5">
        <b>Задача 2.</b> Создайте приложение React при помощи react-create-app,
        выведете в единственном компоненте приложения сведения о максимальной
        и минимальной температуре (по данным Википедии) в городе Вашего проживания.
      </p>
      <ul className="ms-5">
        <li>Минимальная температура в Донецке {minTemperature}<sup>o</sup>C </li>
        <li>Максимальная температура в Донецке {maxTemperature}<sup>o</sup>C </li>
      </ul>
    </>
  );
}

export default App;
