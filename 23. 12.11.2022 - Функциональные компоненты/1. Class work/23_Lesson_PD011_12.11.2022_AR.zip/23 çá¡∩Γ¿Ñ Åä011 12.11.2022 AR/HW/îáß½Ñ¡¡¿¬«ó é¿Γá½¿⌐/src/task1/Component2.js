import React from "react";
import { Button, Col, FloatingLabel, Form, FormControl, Row } from "react-bootstrap";

// Периметр равнобедренного треугольника
export class Component2 extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            a: props.a, h: props.h, perimeter: null,
            validated: false,
            errors: { a: "", h: "" },
            validA: false,
            validH: false,
            touched: { a: false, h: false },
        };
    }

    getPerimeter(a, h) {
        const side = Math.sqrt(Math.pow(a / 2, 2) + Math.pow(h, 2));
        return a + 2 * side;
    }

    validateH = (value) => {
        let error = "";

        if(value === ""){
            error = "Обязательный параметр!";
        }else if (Number(value) <= 0) {
            error = "Основание должно быть больше нуля";
        }

        this.setState({validH: !error, errors: {h: error}});
        return !error;
    }

    validateA = (value) => {
        let error = "";

        if(value === ""){
            error = "Обязательный параметр!";
        }else if (Number(value) <= 0) {
            error = "Основание должно быть больше нуля";
        }

        this.setState((state, props) => ({validA: !error, errors: {a: error}}))
        return !error;
    }

    handleSubmit = e => {
        e.preventDefault();

        const form = e.currentTarget;
        console.log(this.state);

        if (form.checkValidity() && this.state.validA && this.state.validH) {
            this.setState({ perimeter: this.getPerimeter(this.state.a, this.state.h), validated: false });
            return;
        }
        this.setState({ validated: true });
    }

    onChangeA = e => {
        const value = e.currentTarget.value;
        this.validateA(value);
        this.setState({ a: value, validated: false });
    }

    onChangeH = e => {
        const value = e.currentTarget.value;
        this.validateH(value);
        this.setState((state, props) => ({ h: value, validated: false }));
    }

    onBlurA = e => {
        this.setState({ touched: { a: true } });
        this.validateA(e.currentTarget.value);
    }

    onBlurH = e => {
        this.setState({ touched: { h: true } });
        this.validateH(e.currentTarget.value);
    }

    render() {
        return <>
            <Form noValidate className="mx-4" onSubmit={this.handleSubmit} validated={this.state.validated}>
                <fieldset title="Компонент 2">
                    <Row className="mb-3">
                        <Col md="12">
                            <div className="lead text-nowrap fs-4">Периметр равнобедренного треугольника:</div>
                        </Col>
                    </Row>
                    <Row className="mb-2">
                        <Col md="6">
                            <Form.Group>
                            <FloatingLabel label="Основание:">
                                <FormControl className="text-end"
                                             type="number" value={this.state.a}
                                             onChange={this.onChangeA}
                                             onBlur={this.onBlurA}
                                             isValid={this.state.touched.a && this.state.validA}
                                             isInvalid={this.state.touched.a && !this.state.validA}
                                             required/>
                                <Form.Control.Feedback type="invalid">
                                    {this.state.errors.a || "Обязательный параметр"}
                                </Form.Control.Feedback>
                            </FloatingLabel>
                            </Form.Group>
                        </Col>
                    </Row>
                    <Row className="mb-2">
                        <Col md="6">
                            <Form.Group>
                            <FloatingLabel label="Высота:">
                                <FormControl className="text-end" type="number" value={this.state.h}
                                             onChange={this.onChangeH}
                                             onInput={this.onChangeH}
                                             onBlur={this.onBlurH}
                                             isValid={this.state.touched.h && this.state.validH}
                                             isInvalid={this.state.touched.h && !this.state.validH}
                                             required/>
                                <Form.Control.Feedback type="invalid">
                                    {this.state.errors.h || "Обязательный параметр"}
                                </Form.Control.Feedback>
                            </FloatingLabel>
                            </Form.Group>
                        </Col>
                    </Row>

                    <Row className="mb-3">
                        <Col md="6">
                            <div className="lead">Периметр: <b>{this.state.perimeter === null
                                ? ""
                                : Number(this.state.perimeter).toFixed(2)}
                            </b></div>
                        </Col>
                    </Row>

                    <Row className="mb-3">
                        <Col md="5">
                            <Button variant="outline-secondary"
                                    disabled={!this.state.validA || !this.state.validH}
                                    type="submit">Вычислить</Button>
                        </Col>
                    </Row>
                </fieldset>
            </Form>
        </>
    }
}

Component2.defaultProps = { a: "", h: "" };
