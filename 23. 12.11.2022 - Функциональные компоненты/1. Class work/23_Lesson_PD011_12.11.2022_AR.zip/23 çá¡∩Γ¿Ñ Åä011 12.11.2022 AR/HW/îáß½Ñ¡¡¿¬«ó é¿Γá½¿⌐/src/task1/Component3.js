import React from "react";
import { Button, Col, FloatingLabel, Form, FormControl, Row } from "react-bootstrap";


// Проверка на простое число
export class Component3 extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            a: this.props.a, result: null, validated: false,
            errors: { a: ""},
            validA: false,
            touched: { a: false }
        }
    }

    isNumberPrime = num => {
        for (let i = 2, s = Math.sqrt(num); i <= s; i++)
            if (num % i === 0) return "нет";
        return num > 1 ? "да" : "нет";
    }

    validateA = (value) => {
        let error = "";

        if(value === ""){
            error = "Обязательный параметр!";
        }else if (Number(value) <= 0) {
            error = "Число должно быть больше нуля";
        }

        this.setState((state, props) => ({validA: !error}))
        return !error;
    }

    handleSubmit = e => {
        e.preventDefault();

        const form = e.currentTarget;
        console.log(this.state);

        if (form.checkValidity() && this.state.validA) {
            this.setState({ result: this.isNumberPrime(this.state.a, this.state.h), validated: false });
            return;
        }
        this.setState({ validated: true });
    }

    onChangeA = e => {
        const value = e.currentTarget.value;
        this.validateA(value);
        this.setState({ a: value, validated: false });
    }

    onBlurA = e => {
        this.setState({ touched: { a: true } });
        this.validateA(e.currentTarget.value);
    }

    render() {
        return( <>
            <Form noValidate className="mx-4" onSubmit={this.handleSubmit} validated={this.state.validated}>
                <fieldset title="Компонент 3" className="border-2">
                    <Row className="mb-3">
                        <Col md="12">
                            <div className="lead text-nowrap fs-4">Проверка числа на простоту:</div>
                        </Col>
                    </Row>
                    <Row className="mb-2">
                        <Col md="6">
                            <FloatingLabel label="Параметр a:">
                                <FormControl className="text-end" type="number" value={this.state.a}
                                             onChange={this.onChangeA}
                                             onBlur={this.onBlurA}
                                             isValid={this.state.touched.a && this.state.validA}
                                             isInvalid={this.state.touched.a && !this.state.validA}
                                             required/>
                                <Form.Control.Feedback type="invalid">
                                    {this.state.errors.a || "Обязательный параметр"}
                                </Form.Control.Feedback>
                            </FloatingLabel>
                        </Col>
                    </Row>

                    <Row className="mb-3">
                        <Col md="auto">
                            <div className="lead">Является простым числом: <b>{this.state.result}</b></div>
                        </Col>
                    </Row>
                    <Row className="mb-3">
                        <Col md="5">
                            <Button variant="outline-secondary"
                                    disabled={!this.state.validA}
                                    type="submit">Вычислить</Button>
                        </Col>
                    </Row>
                </fieldset>
            </Form>
        </>);
    }

}
Component3.defaultProps = { a: "" }
