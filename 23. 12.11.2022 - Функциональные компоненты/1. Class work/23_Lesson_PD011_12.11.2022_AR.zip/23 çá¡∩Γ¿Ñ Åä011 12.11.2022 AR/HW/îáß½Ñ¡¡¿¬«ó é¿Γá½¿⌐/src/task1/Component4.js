import React from "react";
import { Button, Col, FloatingLabel, Form, FormControl, Row } from "react-bootstrap";

// Определение номера координатной четверти
export class Component4 extends React.Component {
    constructor(props) {
        super(props);
        this.state = { x: this.props.x, y: this.props.y, quadrant: null };
    }

    findQuadrant(x, y) {
        if (x === 0 || y === 0)
            return 'на оси координат';

        const xPos = x > 0;
        const yPos = y > 0;

        return 3 + xPos - yPos - 2 * xPos * yPos;
    }

    handleSubmit = e => {
        e.preventDefault();

        const form = e.currentTarget;

        if (form.checkValidity()) {
            this.setState({ quadrant: this.findQuadrant(this.state.x, this.state.y) });
        }

        this.setState({ validated: true });
    }

    render() {
        return (
            <>
                <Form noValidate className="mx-4" onSubmit={this.handleSubmit} validated={this.state.validated}>
                    <fieldset title="Компонент 4" className="border-2">
                        <Row className="mb-3">
                            <Col md="12">
                                <div className="lead text-nowrap fs-4">Номер координатной плоскости точки:</div>
                            </Col>
                        </Row>
                        <Row className="mb-2">
                            <Col md="6">
                                <FloatingLabel label="Координата x:">
                                    <FormControl className="text-end" type="number" value={this.state.x}
                                                 onChange={e => this.setState({ x: e.currentTarget.value })}
                                                 required/>
                                    <Form.Control.Feedback type="invalid">
                                        Обязательный параметр
                                    </Form.Control.Feedback>
                                </FloatingLabel>
                            </Col>
                        </Row>
                        <Row className="mb-2">
                            <Col md="6">
                                <FloatingLabel label="Координата y:">
                                    <FormControl className="text-end" type="number" value={this.state.y}
                                                 onChange={e => this.setState({ y: e.currentTarget.value })}
                                                 required/>
                                    <Form.Control.Feedback type="invalid">
                                        Обязательный параметр
                                    </Form.Control.Feedback>
                                </FloatingLabel>
                            </Col>
                        </Row>
                        <Row className="mb-3">
                            <Col md="auto">
                                <div className="lead">Результат: <b>{this.state.quadrant}</b></div>
                            </Col>
                        </Row>
                        <Row className="mb-3">
                            <Col md="5">
                                <Button variant="outline-secondary" type="submit">Вычислить</Button>
                            </Col>
                        </Row>
                    </fieldset>
                </Form>
            </>
        );
    }
}

Component4.defaultProps = { x: "", y: "" }
