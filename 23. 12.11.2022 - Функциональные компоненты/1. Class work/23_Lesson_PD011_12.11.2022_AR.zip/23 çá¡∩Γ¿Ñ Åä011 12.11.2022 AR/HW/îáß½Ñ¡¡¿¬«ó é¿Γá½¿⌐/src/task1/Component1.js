import React from "react";
import { Button, Col, FloatingLabel, Form, FormControl, Row } from "react-bootstrap";

// Количество корней квадратного уравнения

export class Component1 extends React.Component {

    constructor(props) {
        super(props);
        this.state = { a: props.a, b: props.b, c: props.c, rootsResult: null, validated: false };
    }

    getNumRoots(a, b, c) {
        if (Number(a) === 0) return "не является квадратным уравнением"

        const d = b * b - 4 * a * c;
        return d < 0
            ? "нет корней"
            : d > 0
                ? "2"
                : "1";
    }

    handleSubmit = e => {
        const form = e.currentTarget;

        if (form.checkValidity()) {
            this.setState({ rootsResult: this.getNumRoots(this.state.a, this.state.b, this.state.c) });
        }

        this.setState({ validated: true });
        e.preventDefault();
    }

    render() {
        return <>
            <Form noValidate className="mx-4" onSubmit={this.handleSubmit} validated={this.state.validated}>
                <fieldset title="Компонент 1" className="border-2">
                    <Row className="mb-3">
                        <Col md="12">
                            <div className="lead text-nowrap fs-4">Количество корней квадратного уравнения:</div>
                        </Col>
                    </Row>
                    <Row className="mb-2">
                        <Col md="6">
                            <FloatingLabel label="Параметр a:">
                                <FormControl className="text-end" type="number" value={this.state.a}
                                             onChange={e => this.setState({ a: e.currentTarget.value })}
                                             required/>
                                <Form.Control.Feedback type="invalid">
                                    Обязательный параметр
                                </Form.Control.Feedback>
                            </FloatingLabel>
                        </Col>
                    </Row>
                    <Row className="mb-2">
                        <Col md="6">
                            <FloatingLabel label="Параметр b:">
                                <FormControl className="text-end" type="number" value={this.state.b}
                                             onChange={e => this.setState({ b: e.currentTarget.value })}
                                             required/>
                                <Form.Control.Feedback type="invalid">
                                    Обязательный параметр
                                </Form.Control.Feedback>
                            </FloatingLabel>
                        </Col>
                    </Row>
                    <Row className="mb-3">
                        <Col md="6">
                            <FloatingLabel label="Параметр c:">
                                <FormControl className="text-end" type="number" value={this.state.c}
                                             onChange={e => this.setState({ c: e.currentTarget.value })}
                                             required/>
                                <Form.Control.Feedback type="invalid">
                                    Обязательный параметр
                                </Form.Control.Feedback>
                            </FloatingLabel>
                        </Col>
                    </Row>
                    <Row className="mb-3">
                        <Col md="auto">
                            <div className="lead">Результат: <b>{this.state.rootsResult}</b></div>
                        </Col>
                    </Row>
                    <Row className="mb-3">
                        <Col md="5">
                            <Button variant="outline-secondary" type="submit">Вычислить</Button>
                        </Col>
                    </Row>
                </fieldset>
            </Form>
        </>;
    }
}
Component1.defaultProps = { a: "", b: "", c: "" };