export function Footer() {
    return (
        <footer className="container-fluid mt-4">
            <div className="row align-items-center bg-light h-60-px">
                <h6 className="text-center">&copy;{new Date().getFullYear()}, Масленников Виталий, г. Донецк, КА «ШАГ», ПД011.</h6>
            </div>
        </footer>
    );
}