export function Header({ title }) {
    return (
        <header className="container-fluid">
            <div className="top-bar row align-items-center ps-4">
                <h1 id="header">{title}</h1>
            </div>
        </header>
    );
}