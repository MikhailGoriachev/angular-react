// сведения о планетах Солнечной системы – название, среднее расстояние
// до Солнца, радиус, масса, изображение, количество известных спутников,
// группа (газовый гигант, ледяной гигант, земной тип)
class Planet {
  constructor(public name: string, public distance: number,
              public radius: number, public mass: number,
              public imageFile: string, public satellites: number,
              public group: string) {}

  // для сортировки по группам планет
  groupWeight(): number {
    switch (this.group) {
      case "газовый гигант": return 1;
      case "ледяной гигант": return 2;
      default: return 3;
    } // switch
  } // groupWeight

  // вывод в строку таблицы
  toTableRow(): string {
    return "";
  } // toTableRow
} // class Planet
