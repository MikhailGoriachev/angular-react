// Сведения о заявке на авиабилет: пункт назначения, номер рейса,
// фамилию и инициалы пассажира, стоимость билета
class Order {
  constructor(public destination: string, public fly: string,
              public passenger: string, public cost: number) {}

  // вывод данных о пассажире в строку таблицы
  toTableRow(): string {
    return "";
  } // toTableRow
} // class Order
