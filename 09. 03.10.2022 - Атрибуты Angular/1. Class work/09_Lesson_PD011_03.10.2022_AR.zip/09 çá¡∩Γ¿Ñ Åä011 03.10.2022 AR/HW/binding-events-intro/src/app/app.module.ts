import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import {AppRoutingModule} from "./app-routing.module";
import { PlanetsAllComponent } from './planets-all/planets-all.component';
import { HomeComponent } from './home/home.component';
import { PlanetsOrderbyAvgDistanceComponent } from './planets-orderby-avg-distance/planets-orderby-avg-distance.component';
import { PlanetsOrderbyGroupComponent } from './planets-orderby-group/planets-orderby-group.component';
import { PlanetsOrderbyNumberSatellitesComponent } from './planets-orderby-number-satellites/planets-orderby-number-satellites.component';
import { PlanetsFilterGroupComponent } from './planets-filter-group/planets-filter-group.component';
import { PlanetsFilterNumberSatellitesComponent } from './planets-filter-number-satellites/planets-filter-number-satellites.component';
import { OrdersAllComponent } from './orders-all/orders-all.component';
import { OrdersOrderbyDestinationComponent } from './orders-orderby-destination/orders-orderby-destination.component';
import { OrdersOrderbyCostComponent } from './orders-orderby-cost/orders-orderby-cost.component';
import { OrdersOrderbyFlightComponent } from './orders-orderby-flight/orders-orderby-flight.component';
import { OrdersFilterCostComponent } from './orders-filter-cost/orders-filter-cost.component';

@NgModule({
  declarations: [
    AppComponent,
    PlanetsAllComponent,
    HomeComponent,
    PlanetsOrderbyAvgDistanceComponent,
    PlanetsOrderbyGroupComponent,
    PlanetsOrderbyNumberSatellitesComponent,
    PlanetsFilterGroupComponent,
    PlanetsFilterNumberSatellitesComponent,
    OrdersAllComponent,
    OrdersOrderbyDestinationComponent,
    OrdersOrderbyCostComponent,
    OrdersOrderbyFlightComponent,
    OrdersFilterCostComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule  /* подключение модуля маршрутизации  */
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
