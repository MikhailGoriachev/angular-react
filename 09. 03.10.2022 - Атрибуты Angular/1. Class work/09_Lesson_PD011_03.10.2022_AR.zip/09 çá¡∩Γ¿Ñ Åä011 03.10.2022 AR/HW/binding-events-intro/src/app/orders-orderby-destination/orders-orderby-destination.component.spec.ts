import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdersOrderbyDestinationComponent } from './orders-orderby-destination.component';

describe('OrdersOrderbyDestinationComponent', () => {
  let component: OrdersOrderbyDestinationComponent;
  let fixture: ComponentFixture<OrdersOrderbyDestinationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrdersOrderbyDestinationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrdersOrderbyDestinationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
