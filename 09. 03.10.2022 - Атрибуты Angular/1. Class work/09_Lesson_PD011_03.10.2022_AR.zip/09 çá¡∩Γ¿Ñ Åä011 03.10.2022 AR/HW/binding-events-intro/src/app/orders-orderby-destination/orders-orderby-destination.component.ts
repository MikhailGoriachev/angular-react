import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orders-orderby-destination',
  templateUrl: './orders-orderby-destination.component.html',
  styleUrls: ['./orders-orderby-destination.component.css']
})
export class OrdersOrderbyDestinationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
