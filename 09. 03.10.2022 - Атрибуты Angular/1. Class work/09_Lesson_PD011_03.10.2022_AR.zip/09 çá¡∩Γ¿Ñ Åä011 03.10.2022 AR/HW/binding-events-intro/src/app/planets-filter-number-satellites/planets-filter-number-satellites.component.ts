import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-planets-filter-number-satellites',
  templateUrl: './planets-filter-number-satellites.component.html',
  styleUrls: ['./planets-filter-number-satellites.component.css']
})
export class PlanetsFilterNumberSatellitesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
