import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {HomeComponent} from "./home/home.component";

import {PlanetsAllComponent} from "./planets-all/planets-all.component";
import {PlanetsOrderbyAvgDistanceComponent} from "./planets-orderby-avg-distance/planets-orderby-avg-distance.component";
import {PlanetsOrderbyGroupComponent} from "./planets-orderby-group/planets-orderby-group.component";
import {
  PlanetsOrderbyNumberSatellitesComponent
} from "./planets-orderby-number-satellites/planets-orderby-number-satellites.component";
import {PlanetsFilterGroupComponent} from "./planets-filter-group/planets-filter-group.component";
import {
  PlanetsFilterNumberSatellitesComponent
} from "./planets-filter-number-satellites/planets-filter-number-satellites.component";

import {OrdersAllComponent} from "./orders-all/orders-all.component";
import {OrdersOrderbyDestinationComponent} from "./orders-orderby-destination/orders-orderby-destination.component";
import {OrdersOrderbyCostComponent} from "./orders-orderby-cost/orders-orderby-cost.component";
import {OrdersOrderbyFlightComponent} from "./orders-orderby-flight/orders-orderby-flight.component";
import {OrdersFilterCostComponent} from "./orders-filter-cost/orders-filter-cost.component";


const routes: Routes = [
  // маршруты приложения
  {path: '', component: HomeComponent},

  {path: 'planets_all', component: PlanetsAllComponent},
  {path: 'planets_orderby_avg_distance', component: PlanetsOrderbyAvgDistanceComponent},
  {path: 'planets_orderby_group', component: PlanetsOrderbyGroupComponent},
  {path: 'planets_orderby_number_satellites', component: PlanetsOrderbyNumberSatellitesComponent},
  {path: 'planets_filter_group', component: PlanetsFilterGroupComponent},
  {path: 'planets_filter_number_satellites', component: PlanetsFilterNumberSatellitesComponent},

  {path: 'orders_all', component: OrdersAllComponent},
  {path: 'orders_orderby_destination', component: OrdersOrderbyDestinationComponent},
  {path: 'orders_orderby_cost', component: OrdersOrderbyCostComponent},
  {path: 'orders_orderby_flight', component: OrdersOrderbyFlightComponent},
  {path: 'orders_filter_cost', component: OrdersFilterCostComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
