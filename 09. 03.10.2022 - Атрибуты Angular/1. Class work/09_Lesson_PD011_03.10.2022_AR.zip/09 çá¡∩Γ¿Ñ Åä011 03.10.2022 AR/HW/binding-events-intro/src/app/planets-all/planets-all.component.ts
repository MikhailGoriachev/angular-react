import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-planets-all',
  templateUrl: './planets-all.component.html',
  styleUrls: ['./planets-all.component.css']
})
export class PlanetsAllComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
