import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-planets-orderby-avg-distance',
  templateUrl: './planets-orderby-avg-distance.component.html',
  styleUrls: ['./planets-orderby-avg-distance.component.css']
})
export class PlanetsOrderbyAvgDistanceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
