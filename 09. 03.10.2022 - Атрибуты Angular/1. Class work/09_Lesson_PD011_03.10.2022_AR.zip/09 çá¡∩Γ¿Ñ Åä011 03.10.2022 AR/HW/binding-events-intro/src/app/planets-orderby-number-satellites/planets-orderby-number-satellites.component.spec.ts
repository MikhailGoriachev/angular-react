import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanetsOrderbyNumberSatellitesComponent } from './planets-orderby-number-satellites.component';

describe('PlanetsOrderbyNumberSatellitesComponent', () => {
  let component: PlanetsOrderbyNumberSatellitesComponent;
  let fixture: ComponentFixture<PlanetsOrderbyNumberSatellitesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlanetsOrderbyNumberSatellitesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PlanetsOrderbyNumberSatellitesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
