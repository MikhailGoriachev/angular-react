import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orders-all',
  templateUrl: './orders-all.component.html',
  styleUrls: ['./orders-all.component.css']
})
export class OrdersAllComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
