import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdersOrderbyCostComponent } from './orders-orderby-cost.component';

describe('OrdersOrderbyCostComponent', () => {
  let component: OrdersOrderbyCostComponent;
  let fixture: ComponentFixture<OrdersOrderbyCostComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrdersOrderbyCostComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrdersOrderbyCostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
