import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-planets-filter-group',
  templateUrl: './planets-filter-group.component.html',
  styleUrls: ['./planets-filter-group.component.css']
})
export class PlanetsFilterGroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
