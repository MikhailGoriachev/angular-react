import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdersOrderbyFlightComponent } from './orders-orderby-flight.component';

describe('OrdersOrderbyFlightComponent', () => {
  let component: OrdersOrderbyFlightComponent;
  let fixture: ComponentFixture<OrdersOrderbyFlightComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrdersOrderbyFlightComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrdersOrderbyFlightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
