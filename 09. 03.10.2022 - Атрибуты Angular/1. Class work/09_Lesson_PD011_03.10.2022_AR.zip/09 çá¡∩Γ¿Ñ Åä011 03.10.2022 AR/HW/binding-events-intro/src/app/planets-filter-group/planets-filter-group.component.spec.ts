import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanetsFilterGroupComponent } from './planets-filter-group.component';

describe('PlanetsFilterGroupComponent', () => {
  let component: PlanetsFilterGroupComponent;
  let fixture: ComponentFixture<PlanetsFilterGroupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlanetsFilterGroupComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PlanetsFilterGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
