import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-planets-orderby-number-satellites',
  templateUrl: './planets-orderby-number-satellites.component.html',
  styleUrls: ['./planets-orderby-number-satellites.component.css']
})
export class PlanetsOrderbyNumberSatellitesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
