import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orders-orderby-flight',
  templateUrl: './orders-orderby-flight.component.html',
  styleUrls: ['./orders-orderby-flight.component.css']
})
export class OrdersOrderbyFlightComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
