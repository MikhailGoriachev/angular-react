import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orders-orderby-cost',
  templateUrl: './orders-orderby-cost.component.html',
  styleUrls: ['./orders-orderby-cost.component.css']
})
export class OrdersOrderbyCostComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
