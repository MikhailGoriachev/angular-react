import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-planets-orderby-group',
  templateUrl: './planets-orderby-group.component.html',
  styleUrls: ['./planets-orderby-group.component.css']
})
export class PlanetsOrderbyGroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
