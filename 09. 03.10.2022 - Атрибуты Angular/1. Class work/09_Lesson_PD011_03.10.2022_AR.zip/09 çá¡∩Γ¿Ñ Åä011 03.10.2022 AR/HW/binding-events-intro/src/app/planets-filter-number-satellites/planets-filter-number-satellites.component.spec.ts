import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanetsFilterNumberSatellitesComponent } from './planets-filter-number-satellites.component';

describe('PlanetsFilterNumberSatellitesComponent', () => {
  let component: PlanetsFilterNumberSatellitesComponent;
  let fixture: ComponentFixture<PlanetsFilterNumberSatellitesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlanetsFilterNumberSatellitesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PlanetsFilterNumberSatellitesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
