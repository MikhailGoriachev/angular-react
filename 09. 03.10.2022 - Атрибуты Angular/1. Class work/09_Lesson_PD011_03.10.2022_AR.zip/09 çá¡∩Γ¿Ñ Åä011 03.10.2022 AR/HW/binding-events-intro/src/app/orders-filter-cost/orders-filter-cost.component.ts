import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orders-filter-cost',
  templateUrl: './orders-filter-cost.component.html',
  styleUrls: ['./orders-filter-cost.component.css']
})
export class OrdersFilterCostComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
