// Класс сведения о планетах Солнечной системы –
// название,
// среднее расстояние до Солнца,
// радиус,
// масса,
// изображение,
// количество известных спутников,
// группа (газовый гигант, ледяной гигант, земной тип)
import {Group} from "./group";

export class Planet{
  constructor(public name: string,
              public distance: number,
              public radius: number,
              public weight: number,
              public image:string,
              public numSatellites: number,
              public groups :Group) {
  }

}
