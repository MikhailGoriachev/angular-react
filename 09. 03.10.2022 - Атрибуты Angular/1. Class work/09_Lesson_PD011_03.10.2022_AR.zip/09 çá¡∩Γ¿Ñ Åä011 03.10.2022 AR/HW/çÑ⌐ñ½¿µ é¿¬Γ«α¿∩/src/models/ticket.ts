// Класс авиабилет содержит:
// пункт назначения,
// номер рейса,
// фамилию и инициалы пассажира,
// стоимость билета

export class Ticket{
  constructor(public fullName:string,
              public destination: string,
              public flight: string,
              public price: number) {
  }


}

export class BookOffice{
  private ticketsList: Ticket[] = [
    { fullName: "Рымарь О.А.", destination: "Сочи", flight: "S5 121", price: 2300},
    { fullName: "Воронцов И.А.", destination: "Милан", flight: "S7 125", price: 5300},
    { fullName: "Романова П.В.", destination: "Москва", flight: "S8 521", price: 2800},
    { fullName: "Рогов Э.Э.", destination: "Париж", flight: "S7 121", price: 4300},
    { fullName: "Горбовски Д.В.", destination: "Рига", flight: "S4 124", price: 2900},
    { fullName: "Жукова Р.Б.", destination: "Стамбул", flight: "S7 421", price: 3300},
    { fullName: "Кондратьев М.Ю.", destination: "Адлер", flight: "S2 127", price: 2100},
    { fullName: "Василенко В.Ю.", destination: "Калуга", flight: "S4 221", price: 1300},
    { fullName: "Беляков К.В.", destination: "Мадрид", flight: "S8 124", price: 4300},
    { fullName: "Горбовски Д.В.", destination: "Барселона", flight: "S2 126", price: 3800},
    { fullName: "Лукин А.В.", destination: "Сочи", flight: "S7 151", price: 2300},
    { fullName: "Комаров О.А.", destination: "Дубаи", flight: "S6 321", price: 5900},
  ]

  getTicket(): Ticket[] {
    return this.ticketsList
  }

  // Копия коллекции, отсортированная по пунктам назначения
  getSortedByDestination() {
    return [...this.ticketsList].sort((a, b) => a.destination.localeCompare(b.destination))
  }

  // Копия коллекции, отсортированная по стоимости билета
  getSortedByTicketCost() {
    return [...this.ticketsList].sort((a, b) => a.price - b.price)
  }

  // Копия коллекции, отсортированная по номеру рейса
  getSortedByFlight() {
    return [...this.ticketsList].sort((a, b) => a.flight.localeCompare(b.flight))
  }

} // class BookOffice
