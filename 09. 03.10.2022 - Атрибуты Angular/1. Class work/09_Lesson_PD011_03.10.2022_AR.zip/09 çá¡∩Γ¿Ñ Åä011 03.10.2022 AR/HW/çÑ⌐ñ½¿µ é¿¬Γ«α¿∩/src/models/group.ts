// Класс Группа (газовый гигант, ледяной гигант, земной тип)
export class Group{
  constructor(public nameGroup: string) {
  }
}
