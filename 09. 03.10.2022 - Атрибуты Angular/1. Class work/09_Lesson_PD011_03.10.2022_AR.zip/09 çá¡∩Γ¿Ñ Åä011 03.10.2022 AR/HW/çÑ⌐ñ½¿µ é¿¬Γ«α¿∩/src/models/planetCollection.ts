import {Planet} from "./planet";
import {Group} from "./group";

// Класс коллекция планет
export class PlanetCollection {

  private planetsList: Planet[] = [
    {
      name: "Юпитер",
      distance: 778.57,
      radius: 69911,
      weight: 317.8,
      image: "upiter.jpg",
      numSatellites: 80,
      groups: new Group("газовый гигант")
    },
    {
      name: "Уран",
      distance: 2.8,
      radius: 25559,
      weight: 14.54,
      image: "uran.jpg",
      numSatellites: 27,
      groups: new Group("ледяной гигант")
    },
    {
      name: "Венера",
      distance: 108,
      radius: 0.9499,
      weight: 0.815,
      image: "venera.png",
      numSatellites: 1,
      groups: new Group("земной тип")
    },
    {
      name: "Марс",
      distance: 228,
      radius: 0.532,
      weight: 0.107,
      image: "mars.jpg",
      numSatellites: 2,
      groups: new Group("земной тип")
    },
    {
      name: "Нептун",
      distance: 4.55,
      radius: 24622,
      weight: 17.147,
      image: "neptun.jpg",
      numSatellites: 14,
      groups: new Group("ледяной гигант")
    },
  ]

  getPlanet(): Planet[] {
    return this.planetsList
  }

  // Копия коллекции, отсортированная по расстоянию до солнца
  getSortedByDistance() {
     return [...this.planetsList].sort((a, b) => a.distance - b.distance)
  }


  // Копия коллекции, отсортированная по категориям
  getSortedByGroup(){
    return [...this.planetsList].sort((a, b) => a.groups.nameGroup > b.groups.nameGroup ? 1 : -1)
  }

   // Копия коллекции, отсортированная по количеству спутников
  getSortedBySatellites() {
    return [...this.planetsList].sort((a, b) => a.numSatellites - b.numSatellites)
  }

  // Выборка планет по заданной группе
  getSelectGroup() {

  }


} // class PlanetCollection
