import { Component, OnInit } from '@angular/core';
import {BookOffice, Ticket} from "../../models/ticket";

@Component({
  selector: 'app-second',
  templateUrl: './second.component.html',
  styleUrls: ['./second.component.css'],
  providers: [BookOffice]
})
export class SecondComponent implements OnInit {

  tickets: Ticket[] = []

  constructor(private bookOffice : BookOffice) { }

  ngOnInit(): void {
    this.tickets = this.bookOffice.getTicket()
  }

  // Упорядочивание по пунктам назначения
  sortedByDestination(){
    this.tickets = this.bookOffice.getSortedByDestination()
  }

  // Упорядочивание по стоимости билета
  sortedByCost(){
    this.tickets = this.bookOffice.getSortedByTicketCost()
  }

  // Упорядочивание по номеру рейса
  sortedByFlight(){
    this.tickets = this.bookOffice.getSortedByFlight()
  }

} // class SecondComponent
