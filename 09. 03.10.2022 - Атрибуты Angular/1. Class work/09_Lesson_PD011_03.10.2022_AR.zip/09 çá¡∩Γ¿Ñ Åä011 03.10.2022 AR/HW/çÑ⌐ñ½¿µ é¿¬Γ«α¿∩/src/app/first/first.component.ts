import { Component, OnInit } from '@angular/core';
import {group} from "@angular/animations";
import {Planet} from "../../models/planet";
import {PlanetCollection} from "../../models/planetCollection";

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css'],
  // коллекция providers компонента
  // для получения объекта в конструкторе компонента
  providers: [PlanetCollection]
})
export class FirstComponent implements OnInit {

  planets: Planet[] = []

  constructor(private planetCollection : PlanetCollection) { }

  ngOnInit() {
    this.planets = this.planetCollection.getPlanet()
  }

  // Упорядочивание по расстоянию
  sortedByDistance(){
    this.planets = this.planetCollection.getSortedByDistance()
  }

  // Упорядочивание по категориям
  sortedByGroup(){
    this.planets = this.planetCollection.getSortedByGroup()
  }

  // Упорядочивание по количеству спутников
  sortedBySatellites(){
    this.planets = this.planetCollection.getSortedBySatellites()
  }

  // Выборка планет по заданной группе

} // class FirstComponent
