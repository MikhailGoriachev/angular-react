import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { MainComponent } from './main/main.component';
import { FirstComponent } from './first/first.component';
import {RouterLinkWithHref, RouterOutlet, RouterModule, Routes} from "@angular/router";
import { SecondComponent } from './second/second.component';


// маршруты приложения (компонента app - по сути, приложения)
const routes: Routes = [
  {path: '', component: MainComponent},
  {path: 'first', component: FirstComponent},
  {path: 'second', component: SecondComponent}

];

@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    MainComponent,
    SecondComponent
  ],
  imports: [
    BrowserModule,
    RouterOutlet,
    RouterLinkWithHref,

    // регистрация маршрутов приложения
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
