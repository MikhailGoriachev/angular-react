﻿
export enum PlanetCategory {
    GasGiant = 1,
    IceGiant,
    Terrestrial,
    DwarfPlanet
}