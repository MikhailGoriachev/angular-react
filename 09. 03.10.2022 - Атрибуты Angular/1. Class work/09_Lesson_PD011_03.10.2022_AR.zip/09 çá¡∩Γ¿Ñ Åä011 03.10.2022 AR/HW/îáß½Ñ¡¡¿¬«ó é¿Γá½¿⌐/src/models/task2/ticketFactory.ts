﻿import { getRandomInt } from "../../util/randoms";
import { Flight } from "./flight";
import { Ticket } from "./ticket";

export class TicketFactory {

    static generate(amount: number){
        return [...Array(amount)].map((t,i) =>
            new Ticket(i + 1, this.randomFlightInfo(), this.randomFullName(), getRandomInt(1000, 5_000)));
    }

    static randomFullName(): string{
        return this.names[getRandomInt(0, this.names.length - 1)];
    }

    static randomFlightInfo(): Flight {
        return this.flights[getRandomInt(0, this.flights.length - 1)];
    }
    
    static names: string[] = ["Гущин Ф. А.", "Симонов Н.А.", "Молчанов А.А.", "Емельянов Ц.И.", "Беляков К.В.",
        "Доронин У.И.", "Несвитайло Д.П.", "Кондратьев М.Ю.", "Симонов Ч.В.", "Тягай С.В.",
        "Василенко В.Ю.", "Дзюба Д.Д.", "Константинов Д.П.", "Лукин А.В.", "Марков Й.В.",
        "Несвитайло Р.В.", "Титов П.Ф.", "Анисимов Е.В.", "Миклашевский Д.В.", "Зыков Э.Б.",
        "Комаров С.Л.", "Рогов Э.Э.", "Королёв О.В.", "Воронцов И.А.", "Семенов Р.М.",
        "Дунаев В.Б.",   "Харламова Ю.В.", "Олегова И.В.", "Янковский В.В.", "Абалкин Л.Ж.",
        "Горбовски Д.В.", "Каммерер М.А.", "Романова П.В.",  "Воликова И.А.", "Жукова Р.Б.",
        "Денисова Д.А.", "Соколов Д.В.",   "Лебедев К.К."];
    
    static flights: Flight[] = [
        new Flight("АФ4567","Сочи"),                   new Flight("FL91AS","Геленджик"),
        new Flight("PB9812","Воронеж"),                new Flight("ALF081","Берлин"),
        new Flight("PB9231","Саратов"),                new Flight("AFL002","Иваново"),
        new Flight("PB1233","Шарм-эш-Шейх"),           new Flight("FL98AS","Ростов-на-дону"),
        new Flight("AFL033","Париж, шарль де-Голль"),  new Flight("АФ9811","Москва, Внуково"),
        new Flight("АФ0011","Владивосток"),            new Flight("AFL021","Париж, Орли"),
        new Flight("АФ9821","Москва, Домодедово"),     new Flight("PB0911","Симферополь"),
        new Flight("PB7812", "Ярославль"),             new Flight("PB2271","Астрахань"),
    ];
    
}