﻿import { Flight } from "./flight";

export class Ticket {
    constructor(public id:number = 0,
                public flight: Flight,
                public paxFullName: string, 
                public price: number) {
    }
}