﻿
export class Flight {
    constructor(public number: string, public destination: string) {
    }
}