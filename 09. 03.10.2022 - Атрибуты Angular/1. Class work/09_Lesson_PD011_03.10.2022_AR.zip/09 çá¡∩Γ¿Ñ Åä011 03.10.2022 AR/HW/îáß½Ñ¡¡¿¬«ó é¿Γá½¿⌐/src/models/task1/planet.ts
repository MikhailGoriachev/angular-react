﻿import { PlanetCategory } from "./enums";
import { Category } from "./category";

// Модель данных о планете

export class Planet {
    constructor(public name: string,
                public avgSunDistance: number,
                public radius: number,
                public mass: number,
                public image: string,
                public moons: number,
                public category: Category
    ) {
        
    }
}
