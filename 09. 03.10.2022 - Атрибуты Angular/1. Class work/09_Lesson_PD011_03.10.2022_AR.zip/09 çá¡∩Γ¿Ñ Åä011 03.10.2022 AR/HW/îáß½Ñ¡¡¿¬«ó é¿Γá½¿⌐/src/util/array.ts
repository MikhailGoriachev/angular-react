﻿
export function sortBy<T>(array: T[], path: string) {
    let properties: string[]  = path.split('.');
    
    array.sort((a, b) => {
        const left: string | number = properties.reduce((prev: any, curr) => prev?.[curr], a);
        const right: string | number = properties.reduce((prev: any, curr) => prev?.[curr], b);

        if(typeof left == 'string' && typeof right == 'string')
            return left.localeCompare(right);
        else if(typeof left == 'number' && typeof right == 'number')
            return left - right;

        return 0;
    })
}