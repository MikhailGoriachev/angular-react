import { Component, OnInit } from '@angular/core';
import { Planet } from "../../models/task1/planet";
import { PlanetCategory } from "../../models/task1/enums";
import { Category } from "../../models/task1/category";
import { sortBy } from "../../util/array";

@Component({
    selector: 'app-task1',
    templateUrl: './task1.component.html',
    styleUrls: ['./task1.component.css']
})
export class Task1Component implements OnInit {

    categories = {
        "GasGiant":    new Category(PlanetCategory.GasGiant, "Газовый гигант"),
        "IceGiant":    new Category(PlanetCategory.IceGiant, "Ледяной гигант"),
        "Terrestrial": new Category(PlanetCategory.Terrestrial, "Земной тип"),
        "DwarfPlanet": new Category(PlanetCategory.DwarfPlanet, "Карликовая планета")
    } as const;
    
    source: Planet[];  // исходная коллекция
    planets: Planet[]; // данные для отображения
    
    // Параметры выделения
    selectedCategory: PlanetCategory | null = null;
    selectedMoons: number | null = null;

    constructor() {
        this.source = [
            new Planet("Плутон", 5914, 1151, 1.79E22, "pluto.jpg", 5,     this.categories.DwarfPlanet),
            new Planet("Нептун", 4496, 24760, 1.03E26, "neptune.jpg", 14, this.categories.IceGiant),
            new Planet("Уран", 2869, 25560, 8.7E25, "uranus.jpg", 27,     this.categories.IceGiant),
            new Planet("Сатурн", 1427, 60270, 5.68E26, "saturn.png", 83,  this.categories.GasGiant),
            new Planet("Юпитер", 778, 71490, 1.9E27, "jupiter.jpg", 80,   this.categories.GasGiant),
            new Planet("Марс", 228, 3397, 6.44E23, "mars.jpg", 2,         this.categories.Terrestrial),
            new Planet("Земля", 149.7, 6378, 5.98E24, "earth.png", 1,     this.categories.Terrestrial),
            new Planet("Венера", 108.2, 6052, 4.9E24, "venus.jpg", 0,     this.categories.Terrestrial),
            new Planet("Меркурий", 58, 2440, 3.3E23, "mercury.jpg", 0,    this.categories.Terrestrial),
        ]
        this.planets = [...this.source];
    }   
    
    ngOnInit(): void {
    }


    selectCategory(target: EventTarget | null) {
        this.selectedCategory = +(target as HTMLInputElement).value;
    }
    
    selectMoons(target: EventTarget | null) {
        this.selectedMoons = +(target as HTMLInputElement).value;
    }
    
    // Проверка соответствия критерию количества спутников
    checkMoons(moons: number): boolean {
        if(this.selectedMoons == null)
            return false;
        
        return this.selectedMoons > 2 
            ? moons >= this.selectedMoons 
            : moons == this.selectedMoons;
    }

    // Сортировка по свойству
    OnOrderChanged(value: string) {
        if(value == 'origin') {
            this.planets = [...this.source];
            return;
        }

        sortBy(this.planets, value);
    }
    
    // Форматирование вывода больших чисел
    avoidScientificNotation(value: number): string {
        return value.toString().replace(/e\+(\d+)$/gi, " * 10<sup>$1</sup>");
    }
}
