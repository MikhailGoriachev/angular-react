import { Component, OnInit } from '@angular/core';
import { Ticket } from "../../models/task2/ticket";
import { TicketFactory } from "../../models/task2/ticketFactory";
import { sortBy } from "../../util/array";

@Component({
    selector: 'app-task2',
    templateUrl: './task2.component.html',
    styleUrls: ['./task2.component.css']
})
export class Task2Component implements OnInit {
    private ticketsAmount = 12;

    source: Ticket[];
    tickets: Ticket[];
    
    priceFrom: number | null = null;
    timeoutHandler: NodeJS.Timeout | undefined;

    constructor() {
        this.source = TicketFactory.generate(this.ticketsAmount);
        this.tickets = [...this.source];
    }

    ngOnInit(): void {
    }

    // Сортировка по свойству
    OnOrderChanged(value: string) {
        if(value == 'origin') {
            this.tickets = [...this.source];
            return;
        }
        
        sortBy(this.tickets, value);
    }

    // Обработчик ввода в input стоимости билета
    onInputChange(e: Event) {
        this.priceFrom = +this.getValue(e);
        
        clearTimeout(this.timeoutHandler);
        this.timeoutHandler = setTimeout(() => this.priceFrom = null, 10000)
    }
    
    getValue(event: Event): string {
        return (event.target as HTMLInputElement).value;
    }
}
