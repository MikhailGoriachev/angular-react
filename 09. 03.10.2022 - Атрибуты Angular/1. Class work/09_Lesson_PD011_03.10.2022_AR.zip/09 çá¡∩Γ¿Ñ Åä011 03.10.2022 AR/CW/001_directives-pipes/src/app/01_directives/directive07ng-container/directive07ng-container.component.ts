import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directive07ng-container',
  templateUrl: './directive07ng-container.component.html'
})
export class Directive07ngContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
