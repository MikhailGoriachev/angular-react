﻿// гендер
export enum Gender {

    // мужчина
    male,

    // женщина
    female,
}
