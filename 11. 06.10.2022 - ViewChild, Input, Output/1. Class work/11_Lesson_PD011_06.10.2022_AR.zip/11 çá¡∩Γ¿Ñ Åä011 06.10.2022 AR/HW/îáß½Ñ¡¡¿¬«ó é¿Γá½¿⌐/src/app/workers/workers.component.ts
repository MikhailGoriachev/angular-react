import { Component, OnInit } from '@angular/core';
import { IconNamesEnum } from "ngx-bootstrap-icons";
import { Worker } from "../../models/worker"
import { WorkerFactory } from "../../models/workerFactory";
import { sortBy } from "../../util/array";

@Component({
  selector: 'app-workers',
  templateUrl: './workers.component.html',
  styleUrls: ['./workers.component.css']
})
export class WorkersComponent implements OnInit {
  private localStorageKey:string = "mv_workers";
  
  // время выделения
  private readonly timeoutDelay: number = 15_000;
  // таймер для выделения
  private timeoutHandler: NodeJS.Timeout | undefined;

  // названия иконок
  iconNames = IconNamesEnum;

  // исходные данные
  sourceData: Worker[] | undefined;
  // данные для отображения
  workers: Worker[];
  
  positions: string[];
  years: number[];

  // настройка заголовков колонок
  columns = [
    { name: 'Id', sortProp: 'id' },
    { name: 'Фото' },
    { name: 'Фамилия И.О.', sortProp: 'fullName' },
    { name: 'Пол', sortProp: 'gender' },
    { name: 'Должность', sortProp: 'position' },
    { name: 'Год поступления', sortProp: 'admissionYear' },
    { name: 'Стаж', sortProp: 'lengthOfService' },
    { name: 'Оклад', sortProp: 'salary' },
  ];

  isOrderDescend: boolean = false;        // текущий порядок сортировки в таблице   
  lastSorted: string = "id";                // последний сортированный столбец
  
  // Критерии выделения
  minSalary: boolean = false;
  maxSalary: boolean = false;
  lengthOfService: number | null = null;
  position: string | null = null;
  admYear: number | null = null;
  
  
  constructor() {
    if(!this.loadFromLocalStorage()) {
      this.sourceData =  WorkerFactory.generateCollection(10);
      localStorage.setItem(this.localStorageKey, JSON.stringify(this.sourceData));
    }
   
    this.workers = [...this.sourceData!];

    this.positions = this.workers.map(v => v.position)
        .filter((v, i, ar) => i == ar.indexOf(v))
        .sort((a, b) => a.localeCompare(b));
    
    this.years = this.workers.map(v => v.admissionYear)
        .filter((v, i, ar) => i == ar.indexOf(v))
        .sort();
  }

  ngOnInit(): void {
  }

  // сортировка таблицы
  onOrderChanged(property: string) {

    if (property == this.lastSorted)
      this.isOrderDescend = !this.isOrderDescend;

    this.lastSorted = property;
    
    if(property == 'lengthOfService') {
      this.workers.sort((a, b) => {
        return (a.lengthOfService() - b.lengthOfService()) * (this.isOrderDescend ? -1 : 1);
      })
    }else {
      sortBy(this.workers, property, this.isOrderDescend);
    }
  }


  // запуск таймера
  setSelectionTimeout() {
    clearTimeout(this.timeoutHandler);
    this.timeoutHandler = setTimeout(() => {
      this.minSalary = this.maxSalary = false;
      this.lengthOfService = this.position = this.admYear = null;
    }, this.timeoutDelay);
  }


  // проверка на необходимость выделения элемента
  checkSelection(worker: Worker): boolean {
    let isSelected = true;
    
    const salaries = this.workers.map(v => v.salary);
    
    if(this.minSalary && worker.salary != Math.min(...salaries))
      isSelected = false;

    if(this.maxSalary && worker.salary != Math.max(...salaries))
      isSelected = false;
    
    if(this.lengthOfService && worker.lengthOfService() <= this.lengthOfService)
      isSelected = false;
    
    if(this.position && worker.position != this.position)
      isSelected = false;
    
    if(this.admYear && worker.admissionYear != this.admYear)
      isSelected = false;
    
    if(!this.minSalary && !this.maxSalary
        && !this.lengthOfService && !this.position && !this.admYear)
      isSelected = false;

    return isSelected;
  }

  selectMinSalaries() {
    this.minSalary = !this.minSalary;
    this.maxSalary = false;
    this.setSelectionTimeout()
  }
  
  selectMaxSalaries() {
    this.maxSalary = !this.maxSalary;
    this.minSalary = false;
    this.setSelectionTimeout()
  }

  loadFromLocalStorage(): boolean {
    let load: string | null = localStorage.getItem("mv_workers")
    if(!load) return false;
    this.sourceData = JSON.parse(load).map((w: Worker) => new Worker().assign(w))
    return true;
  }
}
