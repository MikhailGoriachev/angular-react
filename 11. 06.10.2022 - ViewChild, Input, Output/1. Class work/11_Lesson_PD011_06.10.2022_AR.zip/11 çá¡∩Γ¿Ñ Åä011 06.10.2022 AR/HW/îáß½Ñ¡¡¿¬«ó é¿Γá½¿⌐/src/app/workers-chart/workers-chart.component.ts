import { Component, OnInit } from '@angular/core';
import { Worker } from "../../models/worker";
import { WorkerFactory } from "../../models/workerFactory";

@Component({
  selector: 'app-workers-chart',
  templateUrl: './workers-chart.component.html',
  styleUrls: ['./workers-chart.component.css']
})
export class WorkersChartComponent implements OnInit {

  private localStorageKey:string = "mv_workers";
  // исходные данные
  sourceData: Worker[] | undefined;
  
  constructor() {
    if(!this.loadFromLocalStorage()) {
      this.sourceData =  WorkerFactory.generateCollection(10);
      localStorage.setItem(this.localStorageKey, JSON.stringify(this.sourceData));
    }
  }

  ngOnInit(): void {
    this.createBarChart("chartContainer",
        this.sourceData!.map(w => w.lengthOfService()).sort(), 700,300,"lightseagreen");
  }


  loadFromLocalStorage(): boolean {
    let load: string | null = localStorage.getItem("mv_workers")
    if(!load) return false;
    this.sourceData = JSON.parse(load).map((w: Worker) => new Worker().assign(w))
    return true;
  }

  createBarChart(element: string, data: any, width: number, height: number, color: string) {

    let canvas: HTMLCanvasElement = document.getElementById(element) as HTMLCanvasElement;
    
    canvas.width = width;
    canvas.height = height;
   
    let context = canvas.getContext("2d");

    // находим максимальное значение в массиве данных
    let max = Math.max(...data);

    let scale = height / max;
    let barWidth = Math.floor(width / data.length);

    // создаем отдельный элемент диаграммы
    for (let i = 0; i < data.length; i++) {

      let barHeight = data[i] * scale,
          x = barWidth * i,
          y = height - barHeight;

      context!.fillStyle = color;
      context!.fillRect(x, y, barWidth - 2, barHeight);


      context!.fillStyle = "black";
      context!.font = "bold 12px Arial";
      context!.fillText(data[i], x + barWidth / 2 - 6 , y + 12);
    }
  }
}
