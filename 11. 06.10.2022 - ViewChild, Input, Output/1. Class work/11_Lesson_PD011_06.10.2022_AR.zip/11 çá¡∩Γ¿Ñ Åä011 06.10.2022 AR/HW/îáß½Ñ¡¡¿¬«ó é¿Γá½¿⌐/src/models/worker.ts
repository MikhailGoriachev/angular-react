﻿export class Worker {
    constructor(public id: number = 0,
                public fullName: string = "",
                public position: string = "",
                public gender: string = "",
                public admissionYear: number = 0,
                public photoImg: string = "",
                public salary: number = 0) {
    }

    lengthOfService() { 
        return new Date().getFullYear() - this.admissionYear; 
    }

    assign(worker: Worker) {
        Object.assign(this, worker);
        return this;
    }
}