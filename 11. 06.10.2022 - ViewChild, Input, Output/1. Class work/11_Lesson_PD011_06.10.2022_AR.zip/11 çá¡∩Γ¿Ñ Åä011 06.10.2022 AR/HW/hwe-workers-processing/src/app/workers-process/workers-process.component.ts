import { Component, OnInit } from '@angular/core';
import {Worker} from "../../models/Workers";
import {Enterprise} from "../../models/Enterprise";

@Component({
  selector: 'app-workers-process',
  templateUrl: './workers-process.component.html',
  styleUrls: ['./workers-process.component.css']
})
export class WorkersProcessComponent implements OnInit {

  // коллекция для хранения
  private _workers: Array<Worker>;

  // коллекция для отображения
  private _displayWorkers: Array<Worker>;
  get displayWorkers(): Array<Worker> { return this._displayWorkers; }

  //region Начальные значения для заполнения контролов параметров выборки
  // список должностей для элемента выбора (для выборки)
  positions: Array<string>;

  // список лет начала работы
  years: Array<number>;
  //endregion

  // длительность интервала отображения выбранных записей
  static readonly showInterval: number = 15_000;

  constructor() {
    // имитация получения данных от провайдера
    this._workers = Enterprise.getWorkers();

    // копируем ссылку на коллекцию данных в свойство для вывода
    this._displayWorkers = this._workers;

    // получить список должностей
    this.positions = [...new Set(this._workers.map(w => w.position))].sort();

    // получить список годов начала работы в компании
    this.years = [...new Set(this._workers.map(w => w.startYear).sort())];
  } // constructor

  ngOnInit(): void {}

  // вывод коллекции работников в исходном порядке
  initialize() {
    // копируем ссылку
    this._displayWorkers = this._workers;
  }


  // Упорядочить фамилии и инициалы по алфавиту
  orderByFullname() {
    this._displayWorkers = [...this._workers]
      .sort((w1, w2) => w1.fullName.localeCompare(w2.fullName));
  }

  // упорядочить копию коллекции работников по убыванию окладов
  orderBySalaryDesc() {
    this._displayWorkers = [...this._workers].sort((w1, w2) => w2.salary - w1.salary);
  } // orderBySalaryDesc

  // управляющая переменная для управления интервалом отображения
  // выделенных элементов разметки
  private _handleInterval: NodeJS.Timer = setInterval(() => {}, 1);

  // Поле класса, в которое пишем предикат
  // исходно записан предикат, возвращающий false, т.е. нет ни одной
  // выбранной строки в таблице
  predicate = (w: Worker) => false;

  // установка предиката для выборок по заданию

  // установка предиката для выборки работников с окладом, равным минимальному
  selectByMinSalary() {
    let minSalary = Math.min(...this._workers.map(w => w.salary));
    this.predicate = (w:Worker) => w.salary === minSalary;

    // остановить таймер и запуск таймера для отсчета нового интервала
    this.runInterval();
  } // selectByMinSalary

  // установка предиката для выборки работников с окладом, равным максиимальному
  selectByMaxSalary() {
    let maxSalary = Math.max(...this._workers.map(w => w.salary));
    this.predicate = (w:Worker) => w.salary === maxSalary;

    // остановить таймер и запуск таймера для отсчета нового интервала
    this.runInterval();
  } // selectByMaxSalary

  // выборка записей со стажем работы, больше заданного
  selectByExperience(experience: HTMLInputElement) {
    let experienceValue = Number.parseInt(experience.value);

    // установить предикат для выборки строк в таблице
    this.predicate = (w: Worker) => w.getExperience() > experienceValue;

    // остановить таймер и запуск таймера для отсчета нового интервала
    this.runInterval();
  } // selectByExperience

  // выборка работников с заданной должностью
  selectByPosition(postionsSelect: HTMLSelectElement) {
    this.predicate = (w: Worker) => w.position === postionsSelect.value;

    // остановить таймер и запуск таймера для отсчета нового интервала
    this.runInterval();
  } // selectByPosition

  // выборка работников с заданным годом поступления на работу
  selectByYear(yearsSelect: HTMLSelectElement) {
    let startYear = Number.parseInt(yearsSelect.value);
    this.predicate = (w: Worker) => w.startYear === startYear;

    // остановить таймер и запуск таймера для отсчета нового интервала
    this.runInterval();
  } // selectByPosition


  // остановить таймер и запуск таймера для отсчета нового интервала
  private runInterval() {
    clearInterval(this._handleInterval);
    this._handleInterval = setInterval(
      () => this.predicate = (w: Worker) => false,
      WorkersProcessComponent.showInterval
    );
  } // runInterval

}
