import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {HomeComponent, WorkersProcessComponent, HistogramComponent, NotFoundComponent} from "./index";

const routes: Routes = [
  // маршруты приложения
  {path: '', component: HomeComponent},
  {path: 'workers_process', component: WorkersProcessComponent},
  {path: 'histogram', component: HistogramComponent},
  // компонент для несуществующих путей
  { path: '**', component: NotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
