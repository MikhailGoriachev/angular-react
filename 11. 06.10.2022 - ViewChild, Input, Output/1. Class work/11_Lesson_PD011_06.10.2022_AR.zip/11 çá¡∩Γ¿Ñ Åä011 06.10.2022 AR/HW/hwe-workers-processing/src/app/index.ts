// перечисление компонентов для экспорта
export * from "./home/home.component";
export * from "./workers-process/workers-process.component";
export * from "./histogram/histogram.component";
export * from "./not-found/not-found.component";
