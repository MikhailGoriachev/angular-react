import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-pass03-ng-content',
  templateUrl: './data-pass03-ng-content.component.html',
  styleUrls: ['./data-pass03-ng-content.component.css']
})
export class DataPass03NgContentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
