import React from "react";
import AppView from "./AppView";

class Phone extends React.Component{

    constructor(props){
        super(props);
        this.state = {text: props.text};
        this.onClick = this.onClick.bind(this);
    }

    onClick(e){
        this.props.onRemove(this.state.text);
    }

    render(){
        return <div className="d-flex justify-content-between px-3 pb-3">
                <b>{this.state.text}</b>
                <button className="btn btn-warning" onClick={this.onClick}>Удалить</button>
            </div>;
    }
}

export default Phone;