import React from "react";
import Phone from "./Phone"

// Класс AppView представляет компонент верхнего уровня, в котором выводится список.
// Каждый элемент списка представлен отдельным компонентом Phone.


class AppView extends React.Component{

    constructor(props){
        super(props);
        this.state = {newItem: ""};

        this.onInputChange = this.onInputChange.bind(this);
        this.onClick = this.onClick.bind(this);
    }

    onInputChange(e){
        this.setState({newItem:e.target.value});
    }

    onClick(e){
        if(this.state.newItem){
            this.props.onAddItem(this.state.newItem);
            this.setState({newItem:" "});
        }
    }

    render(){
        let remove = this.props.onRemoveItem;

        return <div className="col-5 m-3">
            <div className="input-group">
                <input className="form-control me-3" type="text" value={this.state.newItem} onChange={this.onInputChange} />
                <button className="btn btn-success" onClick={this.onClick}>Добавить</button>
            </div>
            <h4>Список смартфонов</h4>
            <ul className="list-group">
                {
                    this.props.phones.map(function(item){
                        return <li className="list-group-item"><Phone key={item} text={item} onRemove={remove} /></li>
                    })
                }
            </ul>
        </div>;
    }
}

export default AppView;