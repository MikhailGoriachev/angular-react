// определение действий над элементами хранилища
const ActionTypes = {
    ADD_ITEM: "ADD_ITEM",
    REMOVE_ITEM: "REMOVE_ITEM"
};

export default ActionTypes;