import AppContainer from "./containers/AppContainer.js";
import React from "react";
import ReactDOM from "react-dom";

ReactDOM.render(<AppContainer/>, document.getElementById("app"));