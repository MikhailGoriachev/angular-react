
import {Container} from "flux/utils";
import React from "react";
import AppointmentStore from "../data/AppointmentStore.jsx";
import Actions from "../data/Actions.jsx";

import {BrowserRouter} from 'react-router-dom'
import {Route, Routes} from "react-router-dom";

import {Nav} from "../views/Nav";
import {Main} from "../views/Main";

import {Appointments} from "../views/Appointments.jsx";
import {AppointmentsList} from "../views/AppointmentsList.jsx";
import {AppointmentDetail} from "../views/AppointmentDetail.jsx";
import {AppointmentForm} from "../views/AppointmentForm.jsx";

function NotFound() {
    return <p className="fs-4">Ресурс не найден!</p>;
}

class AppContainer extends React.Component
{

    // Метод getStores() возвращает набор харнилищ, которые используются в приложении.
    // В нашем случае это только одно хранилище AppointmentStore
    static getStores() {
        return [AppointmentStore];
    }

    // Метод calculateState() возвращает состояние контейнера.
    static calculateState() {
        return {
            appointments: AppointmentStore.getState(),
            onAddAppointment: Actions.addItem,
            onEditAppointment: Actions.editItem,
            onRemoveAppointment: Actions.removeItem
        };
    }

    render() {
        return <>
            <BrowserRouter>
                <Nav/>
                <div className="container-fluid">
                    <div className="row-sm mt-5 p-3 container-fluid-style">
                        <div className="p-4 bg-white m-3 border-warning-top border-warning-bottom">
                            <section className="mx-5 my-4 bg-light p-3">
                                <div className="row">
                                    <Routes>
                                        <Route path='/' element={<Main/>}/>
                                        <Route path='/task01' element={<Appointments/>}>
                                            <Route index element={<AppointmentsList appointments = {this.state.appointments}  onDelete={this.state.onRemoveAppointment}/>} />
                                            <Route path=":id" element={<AppointmentDetail appointments = {this.state.appointments}/>} />

                                            <Route path='/task01/add' element={<AppointmentForm
                                                appointments={this.state.appointments}
                                                onAdd={this.state.onAddAppointment}
                                                onEdit={this.state.onEditAppointment}
                                                isAdd={true}
                                            />}/>

                                            <Route path='/task01/edit/:id' element={<AppointmentForm
                                                appointments={this.state.appointments}
                                                onAdd={this.state.onAddAppointment}
                                                onEdit={this.state.onEditAppointment}
                                                isAdd={false}
                                            />}/>
                                        </Route>
                                        <Route path="*" element={<NotFound/>}/>
                                    </Routes>
                                </div>
                            </section>
                        </div>
                    </div>
                </div>
            </BrowserRouter>

            <div className="mt-5 p-3 bg-dark text-white-50 text-center footer">
                <p>Выполнила: Таций Анна ВПД011 Донецк 2022</p>
            </div>    </>;
    }
}

export default Container.create(AppContainer);