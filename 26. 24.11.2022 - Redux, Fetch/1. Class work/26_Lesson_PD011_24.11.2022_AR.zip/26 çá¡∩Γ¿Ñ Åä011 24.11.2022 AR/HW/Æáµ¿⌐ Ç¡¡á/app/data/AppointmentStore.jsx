
import Immutable from "immutable";
import {ReduceStore} from "flux/utils";
import ActionTypes from "./ActionTypes.jsx";

import AppointmentDispatcher from "./AppointmentDispatcher.jsx";
import Appointment from "../models/Appointment.jsx";

class AppointmentStore extends ReduceStore{

    // В конструкторе хранилища в конструктор базового
    // класса передается объект диспетчера.

    constructor() {
        super(AppointmentDispatcher);
    }

    getInitialState() {

        //если локальное хранилище пустое
        if(!localStorage.getItem("appointments")){

            //записать данные в локальное хранилище
            localStorage.setItem("appointments", JSON.stringify(this.getArr()));
        }

        // получить данные из локального хранилища
        let data = JSON.parse(localStorage.getItem("appointments")).map(a => new Appointment().assign(a));

        return Immutable.List.of(...data);
    }

    //сохранение изменений в лок хранилище
    save(data) {
        localStorage.setItem("appointments", JSON.stringify(data));
        return data;
    }

    //исходные данные
    getArr() {
        return [
            new Appointment(1,new Date(),"Белоусов М. М.","Гришин А. М.","Ортопед",2000,20,3),
            new Appointment(2,new Date(),"Филиппов Г. Д.","Назаров С. А.","Нейрохирург",3000,25,23),
            new Appointment(3,new Date(),"Дроздов С. А.","Анисимова А. Д.","Ревматолог",2500,26,11),
            new Appointment(4,new Date(),"Фадеев В. М.","Селезнева Ф. Д.","Психиатр",2500,29,14),
            new Appointment(5,new Date(),"Данилова Т. Т.","Дмитриев А. И.","Диетолог",4000,22,1),
            new Appointment(6,new Date(),"Вешняков А. К.","Моисеева Т. А.","Стоматолог",5000,21,18),
            new Appointment(7,new Date(),"Ермаков А. А.","Бондарева Е. Т.","Дерматолог",6000,23,16),
            new Appointment(8,new Date(),"Овчинников Т. К.","Филатова М. М.","Эндокринолог",3000,25,14),
            new Appointment(9,new Date(),"Муратова В. С.","Петровская С. М.","Онколог",4000,26,12),
            new Appointment(10,new Date(),"Никитина Я. В.","Медведева Э. Д.","Гомеопат",2000,23,21),
            new Appointment(11,new Date(),"Жукова Е. И.","Ковалев Л. Г.","Вирусолог",3000,30,22),
            new Appointment(12,new Date(),"Щеглов Р. А.","Полякова Н. Ф.","Терапевт",1500,50,20)

        ];
    }

    // обработка события для изменения данных
    reduce(state, action) {

        let index;

        switch (action.type) {

            case ActionTypes.ADD_ITEM:
                if (action.appointment) {
                    return state.push(action.appointment);
                }
                return state;

            case ActionTypes.EDIT_ITEM:
                index = state.findIndex((a) => a.id === action.appointment.id);

                if (index > -1) {
                    return this.save(state.set(index,action.appointment));
                } // if

                return state;

            case ActionTypes.REMOVE_ITEM:
                index = state.findIndex((a) => a.id === action.appointment);

                if (index > -1) {
                    return this.save(state.delete(index));
                } // if

                return state;

            default:
                return state;
        } // switch
    }
}

export default new AppointmentStore();