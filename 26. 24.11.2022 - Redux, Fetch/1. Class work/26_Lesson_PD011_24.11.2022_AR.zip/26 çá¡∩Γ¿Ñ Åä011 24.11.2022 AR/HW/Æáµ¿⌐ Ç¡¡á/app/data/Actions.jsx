import ActionTypes from "./ActionTypes.jsx";
import AppointmentDispatcher from "./AppointmentDispatcher.jsx";

const Actions = {

    // добавление в коллекцию
    addItem(appointment) {
        AppointmentDispatcher.dispatch({
            type: ActionTypes.ADD_ITEM,
            appointment,
        });
    },

    // изменение в коллекции
    editItem(appointment) {
        AppointmentDispatcher.dispatch({
            type: ActionTypes.EDIT_ITEM,
            appointment,
        });
    },

    // удаление из коллекции
    removeItem(appointment) {
        AppointmentDispatcher.dispatch({
            type: ActionTypes.REMOVE_ITEM,
            appointment,
        });
    }
};

export default Actions;