import React from "react";
import {useParams} from "react-router-dom";

export function AppointmentDetail(props){
    // получаем параметры
    const params = useParams();
    const id = params.id;

    const appointment = props.appointments.find(p => p.id == id);
    if(appointment === undefined)
        return <div className="alert alert-warning">
            <strong>Прием {id}</strong><br/>
            Сведений об этом приеме не найдено
        </div>;
    else
        return <div className="card w-25 mx-auto">
            <div className="card-header">
                <h4 className="text-center">Прием {appointment.id} за {appointment.date.toLocaleDateString()}</h4>
            </div>
            <ul className="list-group list-group-flush">
                <li className="list-group-item d-flex justify-content-between">
                    <span>Пациент:</span>
                    <b><span>{appointment.patient}</span></b>
                </li>
                <li className="list-group-item d-flex justify-content-between">
                    <span>Доктор:</span>
                    <b><span>{appointment.doctor}</span></b>
                </li>
                <li className="list-group-item d-flex justify-content-between">
                    <span>Кабинет:</span>
                    <b><span>{appointment.cabinet}</span></b>
                </li>
            </ul>
            <div className="card-footer d-flex justify-content-between">
                <span>На руки:</span> <b><span>{appointment.salary()}</span></b>
            </div>
        </div>;
} // AppointmentDetail