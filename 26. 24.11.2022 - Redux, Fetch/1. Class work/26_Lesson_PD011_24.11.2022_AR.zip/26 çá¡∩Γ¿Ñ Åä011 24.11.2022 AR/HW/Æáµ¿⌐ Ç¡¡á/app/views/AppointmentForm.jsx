import React, {useEffect, useState, createRef} from "react";
import {Link, useNavigate, useParams} from "react-router-dom";
import Appointment from "../models/Appointment.jsx";

export function AppointmentForm(props){

    const [appointments] = useState(props.appointments);
    const {id} = useParams();

    const navigate = useNavigate();

    //приём для добавления/редактирования
    let app = new Appointment();

    // ссылки на поля формы
    const doctorField = createRef(null);
    const patientField = createRef(null);
    const specialityField = createRef(null);
    const cabinetField = createRef(null);
    const priceField = createRef(null);
    const percentField = createRef(null);
    const dateField = createRef(null);

    // режим измения записи
    if (!props.isAdd)
        app = appointments.find(a => a.id === +id);

    useEffect(() => {

        if (!props.isAdd) {
            doctorField.current.value = app.doctor;
            patientField.current.value = app.patient;
            specialityField.current.value = app.speciality;
            cabinetField.current.value = app.cabinet;
            priceField.current.value = app.price;
            percentField.current.value = app.percent;
            dateField.current.value = app.date.toISOString().substring(0, 10);
        }
    }, []);

    // обработка события добавления
    const onSubmit = (e) => {
        e.preventDefault();

        let item = new Appointment(
            props.isAdd ? (props.appointments.count() > 0 ? Math.max(...props.appointments.map(d => d.id)) + 1 : 1) : +id,
            new Date(dateField.current.value),
            patientField.current.value,
            doctorField.current.value,
            specialityField.current.value,
            +priceField.current.value,
            +percentField.current.value,
            +cabinetField.current.value,
        );

        if (props.isAdd)
            props.onAdd(item);
        else
            props.onEdit(item);

        navigate("/task01");
    }

    return (
        <form onSubmit={onSubmit} className="w-50 mx-auto">
            <p className="fs-4">{props.isAdd ? "Добавление" : "Изменение"} приёма</p>

                <div className={`form-floating my-2`}>
                    <input ref={doctorField}
                            className="form-control"
                            placeholder="Доктор" required/>
                    <label className="form-label">Доктор</label>
                </div>

                <div className={`form-floating my-2`}>
                    <input type="text" ref={patientField}
                           className="form-control"
                           placeholder="Пациент" required/>
                    <label className="form-label">Пациент</label>
                </div>

                <div className={`form-floating my-2`}>
                    <input ref={specialityField}
                            className="form-control"
                            placeholder="Специальность" required/>
                    <label className="form-label">Специальность</label>
                </div>

                <div className={`form-floating my-2`}>
                    <input type="number" ref={cabinetField}
                           className="form-control"
                           min={1}
                           placeholder="Кабинет" required/>
                    <label className="form-label">Кабинет</label>
                </div>

                <div className={`form-floating my-2`}>
                    <input type="number" ref={priceField}
                           className="form-control"
                           min={1000}
                           placeholder="Стоимость приёма" required/>
                    <label className="form-label">Стоимость приёма</label>
                </div>

                <div className={`form-floating my-2`}>
                    <input type="number" ref={percentField}
                           className="form-control"
                           min={1} max={100}
                           placeholder="Процент отчисления врачу" required/>
                    <label className="form-label">Процент отчисления врачу</label>
                </div>

                <div className={`form-floating my-2`}>
                    <input type="date" ref={dateField}
                           className="form-control"
                           placeholder="Дата приёма" required/>
                    <label className="form-label">Дата приёма</label>
                </div>

                <div>
                    <input type="submit" className="btn btn-success w-10rem me-3"
                           value={props.isAdd ? "Добавить" : "Сохранить"}/>
                    <Link className="btn btn-primary w-10rem" to={`/task01`}>Назад</Link>
                </div>

        </form>
    )
}