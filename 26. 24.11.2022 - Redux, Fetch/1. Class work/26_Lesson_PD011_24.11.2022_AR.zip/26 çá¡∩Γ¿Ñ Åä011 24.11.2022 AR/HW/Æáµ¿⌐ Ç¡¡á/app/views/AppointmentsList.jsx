import React, {useEffect,useState} from "react";
import { NavLink } from "react-router-dom";

// вывод массива
export function AppointmentsList(props){

    // общая стоимость
    const [cost, setCost] = useState(0);

    // обновление общей стоимости
    useEffect(() => setCost(props.appointments.reduce((p, c) => p + c.price, 0)), [props.appointments]);

    return <div>

        <p>Общая стоимость: {cost} ₽</p>

        <div className="d-flex justify-content-end">
            <NavLink className="btn btn-success" to={`/task01/add`}>Добавить</NavLink>

        </div>

        <table className="mt-5 table">
            <thead>
            <tr>
                <th>Дата</th>
                <th>Пациент</th>
                <th>Врач</th>
                <th>Специальность</th>
                <th>Cтоимость</th>
            </tr>
            </thead>
            <tbody>
            {
                props.appointments.map(function(item){
                    return( <tr key={item.id}>
                            <td>{item.date.toLocaleDateString()}</td>
                            <td>{item.patient}</td>
                            <td>{item.doctor}</td>
                            <td>{item.speciality}</td>
                            <td>{item.price}</td>
                            <td><NavLink className= "btn btn-secondary" to={`/task01/${item.id}`}>Детали</NavLink></td>
                            <td><button className="btn btn-danger" onClick={() => props.onDelete(item.id)}>Удалить</button></td>
                            <td><NavLink className="btn btn-success" to={`/task01/edit/${item.id}`}>Изменить</NavLink></td>
                        </tr>

                    )

                })
            }
            </tbody>
        </table>
    </div>;
}