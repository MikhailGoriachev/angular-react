import React from "react";
import { NavLink } from "react-router-dom";

export function Nav(){

    // callback для NavLink
    const setActive = ({ isActive }) => "link-item " + (isActive ? "active" : "");

    return (
        <div className="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
            <div className="container-fluid">
                <div style={{width: '70%', margin: 'auto', fontWeight: '500px'}}>
                    <div className="navbar-collapse">
                        <ul className="navbar-nav fs-4" id="nav">
                            <li className="nav-item pt-1">
                                <NavLink to="/" className={setActive} >Страница с заданием</NavLink>
                            </li>
                            <li className="nav-item pt-1 ps-3">
                                <NavLink className={setActive} to="/task01">Задание 1</NavLink>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>);
}