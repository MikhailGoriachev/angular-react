import React from "react";
import {Outlet} from "react-router-dom";

export function Appointments() {
    return (
        <div>
            <p className="fs-4">Врачебные приемы:</p>
            <Outlet/>
        </div>
    );
}