import React from "react";

class Appointment {
    constructor(id, date, patient, doctor, speciality, price, percent, cabinet) {

        this.id = id;
        this.date = date;
        this.patient = patient;
        this.doctor = doctor;
        this.speciality = speciality;
        this.price = price;
        this.percent = percent;
        this.cabinet = cabinet;
    }

    // вычисление зарплаты доктора, получаемой на руки
    // Стоимость приема * Процент отчисления от стоимости приема на зарплату врача.
    // Из этой суммы вычитается подоходный налог, составляющий 13% от суммы
    salary() {
        let sum = this.price * this.percent / 100;
        return 0.87 * sum;
    }

    assign(obj) {
        Object.assign(this, obj);
        this.date = new Date(obj.date);
        return this;
    }

}

export default Appointment;
