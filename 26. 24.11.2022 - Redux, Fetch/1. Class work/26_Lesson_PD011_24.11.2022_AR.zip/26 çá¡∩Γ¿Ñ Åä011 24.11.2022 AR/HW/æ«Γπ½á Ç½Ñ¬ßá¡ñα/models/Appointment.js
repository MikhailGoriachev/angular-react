import React from "react";

// прием
class Appointment{
    constructor(id, date, doctor, speciality, percent, patient, price, cabinet){
        this.id = id;
        this.date = date;
        this.patient = patient;
        this.doctor = doctor;
        this.speciality = speciality;
        this.price = price;
        this.percent = percent;
        this.cabinet = cabinet;
    }

    calcSalary() {
        let accrued = this.price * (this.percent / 100);
        let sumTax = (accrued / 100) * 13;
        return accrued - sumTax;
    }

}

export default Appointment;