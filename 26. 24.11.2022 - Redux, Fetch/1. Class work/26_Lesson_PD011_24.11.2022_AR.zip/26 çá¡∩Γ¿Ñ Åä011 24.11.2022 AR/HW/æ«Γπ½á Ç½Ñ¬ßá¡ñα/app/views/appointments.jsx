import React from "react";
import AppointmentComponent from "./appointmentComponent";

// компонент отображения таблицы
function Appointments(props) {

    // список приемов
    const [data, setData] = React.useState(props.appointments);

    // action удаления
    let remove = props.onRemove;

    // изменение заголовка
    React.useEffect(() => {
        let str = "Список приемов";
        document.title = str;
        document.getElementById("head").innerText = str;
    });

    return (
        <>
            <table className='table table-hover'>
                <thead>
                <tr>
                    <th>Дата приема</th>
                    <th>Пациент</th>
                    <th>Доктор</th>
                    <th>Специальность</th>
                    <th>Стоимость</th>
                    <th>Управление</th>
                </tr>
                </thead>
                <tbody>{
                    data.map(function (item) {
                        return <AppointmentComponent key={item.id} appointment={item} onRemove={remove}/>
                    })
                }</tbody>
            </table>
        </>
    );
}

export default Appointments;

