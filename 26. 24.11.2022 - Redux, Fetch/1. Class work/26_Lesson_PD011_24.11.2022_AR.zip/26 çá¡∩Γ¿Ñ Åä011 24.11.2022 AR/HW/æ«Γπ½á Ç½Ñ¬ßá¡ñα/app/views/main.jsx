import React, {useState} from "react";
import Header from "./header";
import Footer from "./footer";
import Task from "./task";
import Appointments from "./appointments";
import AddAppointment from "./addAppointment";
import {Route, Routes} from "react-router-dom";

// основной компонент отображения
function Main(props) {

    // приемы
    const[data, setData] = React.useState(props.appointments);

    // action удаления
    let remove = props.onRemoveAppointment;

    return (
        <>
            <Header/>
            <div className="row container-fluid bg-body h-100">
                <div className="col-sm-1"></div>

                <div className="col-sm-10">
                    <Routes>
                        <Route path="/" element={<Task/>}/>
                        <Route path="/appointments" element={<Appointments appointments={data} onRemove={remove}/>}/>

                        <Route path="/addAppointment" element={<AddAppointment/>}/>

                        {/*<Route path="/*" element={<UnknownRoute/>}/>*/}
                    </Routes>

                </div>

                <div className="col-sm-1"></div>
            </div>
            <Footer/>
        </>
    );
}

export default Main;