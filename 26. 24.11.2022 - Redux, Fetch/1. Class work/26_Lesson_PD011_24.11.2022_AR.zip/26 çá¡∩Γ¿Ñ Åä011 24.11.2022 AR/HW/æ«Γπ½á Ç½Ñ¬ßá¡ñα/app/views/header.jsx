import React from "react";
import {NavLink} from "react-router-dom";

// компонент навигационной панели
function Header() {
    const setActive = ({isActive}) => "nav-link " + (isActive ? "active" : "");

    return (
        <>
            <header className="container-fluid bg-black text-white text-center p-3 mt-5">
                <div id="head" className="h1"></div>
            </header>
            <nav className="navbar navbar-expand-sm bg-black navbar-dark fixed-top">
                <div className="container-fluid">
                    <a className="navbar-brand" href="app/views/header#">
                        <img src="img/react.png" alt="logo"/>
                    </a>
                    <button className="navbar-toggler" type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#navbar-hide">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbar-hide">
                        <ul className='navbar-nav'>

                            <li className='nav-item'>
                                <NavLink className={setActive} to="/">Главная страница</NavLink>
                            </li>

                            <li className='nav-item'>
                                <NavLink className={setActive} to="/appointments">Приемы</NavLink>
                            </li>

                            <li className='nav-item'>
                                <NavLink className={setActive} to="/addAppointment">Добавить прием</NavLink>
                            </li>

                        </ul>
                    </div>
                </div>
            </nav>
        </>
    );
}

export default Header;