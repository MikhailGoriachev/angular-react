import React from "react";
import {NavLink} from "react-router-dom";

// компонент отображения приема в виде строки таблицы
function AppointmentComponent(props) {
    // состояние
    const [appointment, setAppointment] = React.useState(props.appointment);

    // обработчик
    function onClickDelete(e){
        props.onRemove(appointment)
    }

    return (
        <tr>
            <td>{new Date(appointment.date).toLocaleDateString()}</td>
            <td>{appointment.patient}</td>
            <td>{appointment.doctor}</td>
            <td>{appointment.speciality}</td>
            <td>{appointment.price}</td>
            <td>
                <NavLink className="btn btn-outline-dark" to={`/appointments/${appointment.id}`}>Детали</NavLink>
                <button className="btn btn-outline-danger" onClick={onClickDelete}>Удалить</button>
            </td>
        </tr>
    )
}
export default AppointmentComponent;