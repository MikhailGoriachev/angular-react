import React from "react";

// компонент для добавления заявки
function AddAppointment(){
    // изменение заголовка
    React.useEffect(() => {
        let str = "Добавить новый прием";
        document.title = str;
        document.getElementById("head").innerText = str;
    });

    return (
        <p>форма для добавления нового приема</p>
    );
}

export default AddAppointment;