import React from "react";

// компонент подвала
function Footer() {
    return (
        <>
            <footer className="footer text-center text-white bg-black p-3 mt-auto">
                <div className="container">
                    <p className="m-0">Сотула Александр. ПД011. Донецк-2022.</p>
                    <a href="mailto:alexander.sotula@gmail.com">Эл. почта для связи</a>
                </div>
            </footer>
        </>
    )
}

export default Footer;