// определение действий
const ActionsType = {
    // добавить
    ADD_APPOINTMENT: "ADD_APPOINTMENT",

    // редактировать
    EDIT_APPOINTMENT: "EDIT_APPOINTMENT",

    // удалить
    REMOVE_APPOINTMENT: "REMOVE_APPOINTMENT",
}

export default ActionsType;