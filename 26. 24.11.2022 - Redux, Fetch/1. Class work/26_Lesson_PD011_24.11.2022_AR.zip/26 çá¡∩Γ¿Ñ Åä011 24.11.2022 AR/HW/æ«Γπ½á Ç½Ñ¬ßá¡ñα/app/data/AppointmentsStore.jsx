import {ReduceStore} from "flux/utils";
import AppointmentsDispatcher from "./AppointmentsDispatcher"
import ActionsType from "./actionsType";
import Appointment from "/models/Appointment"

// хранилище
class AppointmentsStore extends ReduceStore {
    constructor() {
        super(AppointmentsDispatcher);
    }


    // установка состояния хранилища
    getInitialState() {
        // ключ в локальном хранилище
        this.key = 'appointments'

        // список данных
        let data = localStorage.getItem(this.key);

        // заполнение локального хранилища
        if (!data) {
            let array = [
                new Appointment(1, new Date(2022, 10, 4), "Симонов О.П.", "Хирург", 25, "Федорова В.П.", 2000, 7),
                new Appointment(2, new Date(2022, 10, 6), "Михайлова И.В.", "Терапевт", 15, "Николаев А.В.", 3000, 15),
                new Appointment(3, new Date(2022, 10, 2), "Симонов О.П.", "Хирург", 25, "Костюк П.П.", 2500, 7),
                new Appointment(4, new Date(2022, 10, 3), "Самойлова Д.Д.", "Стоматолог", 20, "Конюхова О.Н.", 4200, 4),
                new Appointment(5, new Date(2022, 10, 2), "Михайлова И.В.", "Терапевт", 15, "Романец В.Н.", 1200, 15),
                new Appointment(6, new Date(2022, 10, 5), "Симонов О.П.", "Хирург", 25, "Коц М.В.", 2300, 7),
                new Appointment(7, new Date(2022, 10, 2), "Самойлова Д.Д.", "Стоматолог", 20, "Петрова Ю.Н.", 2300, 4),
                new Appointment(8, new Date(2022, 10, 6), "Симонов О.П.", "Хирург", 25, "Иванов И.И.", 1200, 7),
                new Appointment(9, new Date(2022, 10, 5), "Самойлова Д.Д.", "Стоматолог", 20, "Дмитров А.И.", 4700, 4),
                new Appointment(10, new Date(2022, 10, 4), "Михайлова И.В.", "Терапевт", 15, "Коваль А.Н.", 3000, 15),
            ];

            data = JSON.stringify(array);
            localStorage.setItem(this.key, data);
        }

        // получение данных о приемах
        data = JSON.parse(data);
        let resultData = [];

        for (const a of data) {
            resultData.push(new Appointment(a.id, a.date, a.doctor, a.speciality, a.percent, a.patient, a.price, a.cabinet));
        }

        return resultData;
    }

    // обработка
    reduce(state, action) {
        switch (action.type) {

            // добавить
            case ActionsType.ADD_APPOINTMENT:
                state.push(action.data);
                localStorage.setItem(this.key, JSON.stringify(state));
                return state;

                // редактировать
            case ActionsType.EDIT_APPOINTMENT:
                console.log("Edit appointment");
                return state;

                // удалить
            case ActionsType.REMOVE_APPOINTMENT:
                let id = action.appointment.id;
                state = state.filter(a => a.id !== id);
                localStorage.setItem(this.key, JSON.stringify(state));
                return state;

            default:
                return state;

        }
    }
}

export default new AppointmentsStore();