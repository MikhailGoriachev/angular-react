import ActionsType from "./actionsType";
import AppointmentsDispatcher from "./AppointmentsDispatcher";

// действия
const Actions = {

    // добавить
    addAppointment(appointment) {
        AppointmentsDispatcher.dispatch({
            type:ActionsType.ADD_APPOINTMENT,
            appointment
        });
    },

    // редактировать
    editAppointment(appointment) {
        AppointmentsDispatcher.dispatch({
            type: ActionsType.EDIT_APPOINTMENT,
            appointment
        });
    },

    // удалить
    removeAppointment(appointment) {
        AppointmentsDispatcher.dispatch({
            type: ActionsType.REMOVE_APPOINTMENT,
            appointment
        })
    }
}

export default Actions;