import React from "react";
import {BrowserRouter} from 'react-router-dom'
import Main from "../views/main";
import AppointmentsStore from "../data/AppointmentsStore";
import {Container} from "flux/utils";
import Actions from "../data/actions";

// контейнер
class AppContainer extends React.Component {

    // хранилище
    static getStores() {
        return [AppointmentsStore];
    }

    // состояние
    static calculateState() {
        return {
            appointments: AppointmentsStore.getState(),
            onAddAppointment: Actions.addAppointment,
            onRemoveAppointment: Actions.removeAppointment,
            onEditAppointment: Actions.editAppointment,
        }
    }

    render() {
        return <>
            <BrowserRouter>
                <Main appointments={this.state.appointments}
                      onAddAppointment={this.state.onAddAppointment}
                      onRemoveAppointment={this.state.onRemoveAppointment}
                      onEditAppointment={this.state.onEditAppointment}
                />
            </BrowserRouter>
        </>
    }
}

export default Container.create(AppContainer);