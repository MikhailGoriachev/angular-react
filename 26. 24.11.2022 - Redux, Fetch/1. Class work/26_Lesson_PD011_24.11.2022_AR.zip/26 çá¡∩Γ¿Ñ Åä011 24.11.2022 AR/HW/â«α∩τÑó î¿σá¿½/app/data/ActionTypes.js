// определение действий над элементами хранилища
export const ActionTypes = {
    ADD_ITEM: "ADD_ITEM",
    EDIT_ITEM: "EDIT_ITEM",
    REMOVE_ITEM: "REMOVE_ITEM"
};