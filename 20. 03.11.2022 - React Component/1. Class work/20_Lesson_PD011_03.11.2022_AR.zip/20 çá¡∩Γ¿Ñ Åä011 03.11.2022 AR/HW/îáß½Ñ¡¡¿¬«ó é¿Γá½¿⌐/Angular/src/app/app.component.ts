import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ActivationStart, Router } from "@angular/router";
import {routes as Routes} from "./app-routing.module";
import { AuthService } from "./services/auth.service";
import { UntilDestroy, untilDestroyed } from "@ngneat/until-destroy";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
@UntilDestroy()
export class AppComponent implements OnInit{
  routes = Routes.slice(0, -1);
  year: number;
  
  loginBtnText: string = "";
  isAuth: any;

  constructor(private router: Router, 
              private authService: AuthService) {
    this.year = new Date().getFullYear();
  }
  
  ngOnInit(): void {
    this.changeLoginBtnText();    
  }

  changeLoginBtnText() {
    this.authService.isLoggedIn()
        .then((isAuth: any) => {
          this.isAuth = isAuth;
          this.loginBtnText = this.isAuth ? "Выйти" : "Войти";
        })
  }

  login() {
    this.authService.loginService();
    this.changeLoginBtnText();
  }

  logout() {
    this.authService.logoutService();
    this.changeLoginBtnText();
    this.router.navigate(["/"]);
  }
}
