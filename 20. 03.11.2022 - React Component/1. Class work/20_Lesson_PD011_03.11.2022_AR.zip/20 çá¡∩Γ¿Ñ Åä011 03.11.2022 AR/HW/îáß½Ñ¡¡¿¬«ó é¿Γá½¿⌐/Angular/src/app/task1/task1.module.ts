import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from "@angular/forms";
import { SharedModule } from "../shared/shared.module";
import { StudentsComponent } from './students/students.component';
import { NgxBootstrapIconsModule } from "ngx-bootstrap-icons";
import { StudentFormComponent } from './student-form/student-form.component';
import { BsDropdownModule } from "ngx-bootstrap/dropdown";
import { Task1RoutingModule } from "./task1-routing.module";


@NgModule({
    declarations: [
        StudentsComponent,
        StudentFormComponent,
    ],
    imports: [
        CommonModule,
        Task1RoutingModule,
        ReactiveFormsModule,
        SharedModule,
        NgxBootstrapIconsModule,
        BsDropdownModule
    ]
})
export class Task1Module {
}
