import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgxBootstrapIconsModule } from 'ngx-bootstrap-icons';
import { arrowDownShort, arrowUpShort, trashFill, plusCircle, square, checkSquare, pencilSquare } from "ngx-bootstrap-icons";

import { AppRoutingModule } from './app-routing.module';
import { Task1Module } from "./task1/task1.module";

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';

import { HttpClientModule } from "@angular/common/http";
import { BackendService } from "./services/backend.service";
import { ModalModule } from "ngx-bootstrap/modal";
import { InMemoryWebApiModule } from "angular-in-memory-web-api";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";


const icons = { arrowDownShort, arrowUpShort, plusCircle, trashFill, square, checkSquare, pencilSquare };

@NgModule({
    declarations: [
        AppComponent,
        HomeComponent,
    ],
    imports: [
        HttpClientModule,
        Task1Module,
        InMemoryWebApiModule.forRoot(BackendService, {passThruUnknownUrl: true, delay: 0}),
        ModalModule.forRoot(),
        NgxBootstrapIconsModule.pick(icons),
        BrowserModule,
        BrowserAnimationsModule,
        AppRoutingModule,
    ],
    providers: [],
    exports: [
    ],
    bootstrap: [AppComponent]
})

export class AppModule {
}
