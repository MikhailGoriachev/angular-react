import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private isAuth = false;
  
  constructor() { }

  loginService(){
    this.isAuth = true;
    console.log("logined");
  }

  logoutService(){
    this.isAuth = false;
    console.log("logouted");
  }

  isLoggedIn(){
    return new Promise(resolve => {
      setTimeout(() => {
        resolve(this.isAuth)
      }, 200);
    })
  }
}
