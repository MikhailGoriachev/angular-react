import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { Rank, Student, Trainer } from "../../services/backend.service";
import { SportClubService } from "../services/sport-club.service";
import { UntilDestroy, untilDestroyed } from "@ngneat/until-destroy";
import { IconNamesEnum } from "ngx-bootstrap-icons";
import { BsModalRef, BsModalService } from "ngx-bootstrap/modal";
import {  AbstractControlOptions, FormBuilder, Validators } from "@angular/forms";
import { ColumnOption } from "../../shared/types";
import { Observable } from "rxjs";
import { formatInputDate, getAge } from "../../shared/helpers";
import { BsDropdownConfig } from "ngx-bootstrap/dropdown";
import { max, min } from "radash";
import { rangeValidator } from "../../shared/validators";


type trainersFormType = StudentsComponent["trainersForm"];
type dobFormType = StudentsComponent["dobForm"];
type ranksRangeFormType = StudentsComponent["ranksRangeForm"];
type ageRangeFormType = StudentsComponent["ageRangeForm"];

@UntilDestroy()
@Component({
    selector: 'app-students',
    templateUrl: './students.component.html',
    providers: [{ provide: BsDropdownConfig, useValue: { isAnimated: true, autoClose: true } }]
})
export class StudentsComponent implements OnInit {
    students: Student[] = [];

    @ViewChild("modal")
    modalElement!: TemplateRef<any>;        // ссылка на элемент модального окна в разметке
    modalRef!: BsModalRef;                  // ссылка на объект модального окна для управления
    modalContent!: TemplateRef<any> | null; // ссылка на текущий контент модального окна
    modalTitle: string = "";

    editStudent!: Student;

    trainers$!: Observable<Trainer[]>;
    ranks$!: Observable<Rank[]>;

    trainersForm = this.fb.group({
        trainerId: this.fb.control<number>(1, Validators.required)
    });

    dobForm = this.fb.group({
        dob: this.fb.control<string>("", Validators.required)
    });

    ranksRangeForm = this.fb.group({
        from: this.fb.control<number>(1,[Validators.required]),
        to: this.fb.control<number>(1,[Validators.required])
    }, { asyncValidators: rangeValidator("from", "to")} as AbstractControlOptions);

    ageRangeForm = this.fb.group({
        from: this.fb.control<number>(1,[Validators.required, Validators.min(14)]),
        to: this.fb.control<number>(1,[Validators.required, Validators.min(14)])
    }, {asyncValidators: rangeValidator("from", "to")});

    columns: ColumnOption<Student>[] = [
        { name: 'Id', sortProp: (s: Student) => s.id },
        { name: 'Фамилия И.', sortProp: (s: Student) => s.fullName },
        { name: 'Группа', sortProp: (s: Student) => s.group.name },
        { name: 'Категория', sortProp: (s: Student) => s.rank.id },
        { name: 'Тренер', sortProp: (s: Student) => s.group.trainer.fullName },
        { name: 'Дата рождения', sortProp: (s: Student) => s.dob },
        { name: 'Телефон', sortProp: (s: Student) => s.phone },
        { name: 'Электронная почта', sortProp: (s: Student) => s.email },
    ];

    constructor(private sportClub: SportClubService,
                private fb: FormBuilder,
                private modalService: BsModalService) {
    }

    ngOnInit(): void {
        this.getStudents();
        this.trainers$ = this.sportClub.getTrainers();
        this.ranks$ = this.sportClub.getRanks();

        this.dobForm.patchValue({dob: formatInputDate(new Date())});
    }

    getStudents() {
        this.sportClub.getStudents()
            .pipe(untilDestroyed(this))
            .subscribe(x => this.students = x);
    }

    orderGroupThenRank() {
        this.students.sort((a, b) => {
            let result = a.group.name.localeCompare(b.group.name);
            if (!result) result = b.rank.id - a.rank.id;
            if (!result) result = a.fullName.localeCompare(b.fullName);

            return result;
        })
    }

    onAddStudent(modalContent: TemplateRef<any>) {
        this.showModal(modalContent, "Добавить информацию о студенте");
    }

    onEditStudent(id: number, modalContent: TemplateRef<any>) {
        this.sportClub.getStudentById(id)
            .pipe(
                untilDestroyed(this),
            ).subscribe(student => {
            this.editStudent = student;
            this.showModal(modalContent, "Редактировать информацию о студенте");
        })
    }

    onRemoveStudent(id: number) {
        this.sportClub.deleteStudent(id)
            .pipe(untilDestroyed(this))
            .subscribe(_ => this.getStudents());
    }

    onSubmitAdd(student: Student) {
        this.sportClub.addStudent(student)
            .pipe(untilDestroyed(this))
            .subscribe(_ => {
                this.getStudents();
                this.modalRef.hide();
            });
    }

    onSubmitEdit(student: Student) {
        this.sportClub.editStudent(student)
            .pipe(untilDestroyed(this))
            .subscribe(_ => {
                this.getStudents();
                this.modalRef.hide();
            });
    }

    showModal(content: TemplateRef<any>, title: string = "") {
        this.modalContent = content;
        this.modalTitle = title;
        this.modalRef = this.modalService.show(this.modalElement!, { class: 'modal-dialog-centered' });
    }

    //region Выборки

    selectByTrainer(trainersForm: trainersFormType) {
        this.sportClub.getStudents()
            .pipe(untilDestroyed(this))
            .subscribe(x => {
                this.students = x.filter(s => s.group.trainer.id == trainersForm.value.trainerId);
                this.modalRef.hide();
            })
    }

    selectByDob(dobForm: dobFormType) {
        this.sportClub.getStudents()
            .pipe(untilDestroyed(this))
            .subscribe(x => {
                this.students = x.filter(s => formatInputDate(s.dob) == dobForm.value.dob);
                this.modalRef.hide();
            })
    }

    selectByRank(ranksRangeForm: ranksRangeFormType) {
        this.sportClub.getStudents()
            .pipe(untilDestroyed(this))
            .subscribe(x => {
                this.students = x.filter(s => s.rank.id >= ranksRangeForm.value.from! && s.rank.id <= ranksRangeForm.value.to!);
                this.modalRef.hide();
            })
    }

    selectByAge(ageRangeForm: ageRangeFormType) {
        this.sportClub.getStudents()
            .pipe(untilDestroyed(this))
            .subscribe(x => {
                this.students = x.filter(s => {
                    const age = getAge(s.dob);
                    return age >= ageRangeForm.value.from! && age <= ageRangeForm.value.to!;
                });
                this.modalRef.hide();
            })
    }

    selectYoungest() {
        this.sportClub.getStudents()
            .pipe(untilDestroyed(this))
            .subscribe(x => {
                let maxDob = max(x.map(s => s.dob));
                this.students = x.filter(s => s.dob == maxDob);
                this.modalRef.hide();
            })
    }

    selectOldest() {
        this.sportClub.getStudents()
            .pipe(untilDestroyed(this))
            .subscribe(x => {
                let minDob = min(x.map(s => s.dob));
                this.students = x.filter(s => s.dob == minDob);
                this.modalRef.hide();
            })
    }
    //endregion
}
