export type ColumnOption<T> = {
    name: string,
    sortProp?: (obj: T) => string | number | Date
}
