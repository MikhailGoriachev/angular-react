﻿// Класс Уровень мастерства спортсмена
export class Level {
    constructor(public name: string,
                public value: number) {
    }
}
