import {Component, OnInit} from '@angular/core';
import {Product} from "../../models/task3/product";

@Component({
  selector: 'app-task3',
  templateUrl: './task3.component.html',
  styleUrls: ['./task3.component.css']
})

export class Task3Component implements OnInit {

  product: Product = new Product("Монитор 24\" AOC C24G2AE", "monitor.jpeg", 15590, 5);

  constructor() {
  }

  ngOnInit(): void {
  }

}
