import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task2',
  templateUrl: './task2.component.html',
  styleUrls: ['./task2.component.css']
})
export class Task2Component implements OnInit {

  text = 'Angular представляет фреймворк от компании Google для создания клиентских приложений. Прежде всего он нацелен на разработку SPA-решений (Single Page Application), то есть одностраничных приложений. В этом плане Angular является наследником другого фреймворка AngularJS. В то же время Angular это не новая версия AngularJS, а принципиально новый фреймворк.Angular предоставляет такую функциональность, как двустороннее связывание, позволяющее динамически изменять данные в одном месте интерфейса при изменении данных модели в другом, шаблоны, маршрутизация и так далее.'

  constructor() { }

  ngOnInit(): void {
  }

  minWord(): string {
    let minLength = Math.min(...this.wordsList(this.text)
      .map(v => v.length));
    let result = new Set(this.wordsList(this.text)
      .filter(v => v.length == minLength)
      .map(v => v.toLowerCase()));
    return Array.from(result).join(', ');
  }

  maxWord(): string {
    let maxLength = Math.max(...this.wordsList(this.text)
      .map(v => v.length));
    let result = new Set(this.wordsList(this.text)
      .filter(v => v.length == maxLength)
      .map(v => v.toLowerCase()));
    return Array.from(result).join(', ');
  }


  wordsList(text: string): string[] {
    return text.match(/[а-яёА-ЯЁ]+/gi)!;
  }

}
