import {Component, OnInit} from '@angular/core';
import {getRandom} from "../../util/randoms";

@Component({
  selector: 'app-task1',
  templateUrl: './task1.component.html',
  styleUrls: ['./task1.component.css']
})
export class Task1Component implements OnInit {

  private minValue = 1;
  private maxValue = 10;

  alpha = getRandom(this.minValue,this.maxValue);

  constructor() {
  }

  ngOnInit(): void {
  }

  calcZ1(): number {
    const part1 = Math.PI / 8,
        part2 = this.alpha / 4;

    return Math.cos(3 * part1 - part2) ** 2 - Math.cos(11 * part1 + part2) ** 2;
  }

  calcZ2(): number {
    return Math.sqrt(2) * Math.sin(this.alpha / 2) / 2;
  }

}
