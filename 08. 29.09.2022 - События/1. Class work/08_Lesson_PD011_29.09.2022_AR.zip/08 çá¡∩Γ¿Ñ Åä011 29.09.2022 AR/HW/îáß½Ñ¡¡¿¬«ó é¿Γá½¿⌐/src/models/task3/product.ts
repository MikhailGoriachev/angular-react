﻿// Модель данных о товаре
export class Product {
    constructor(public name: string,
                public image: string,
                public price: number,
                public amount: number) {
    }
}
