import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {RouterModule, RouterOutlet, Routes} from "@angular/router";

// импорт компонентов приложения - главного и всех остальных
import { AppComponent } from './app.component';
import { Comp1Component } from './comp1/comp1.component';
import { Comp2Component } from './comp2/comp2.component';
import { Comp3Component } from './comp3/comp3.component';
import { TaskComponent } from './task/task.component';

// маршруты приложения (компонента app - по сути, приложения)
const routes: Routes = [
  {path: '', component: TaskComponent},
  {path: 'component1', component: Comp1Component},
  {path: 'component2', component: Comp2Component},
  {path: 'component3', component: Comp3Component},
];

@NgModule({
  declarations: [
    AppComponent,
    Comp1Component,
    Comp2Component,
    Comp3Component,
    TaskComponent
  ],
    imports: [
        BrowserModule,
        RouterOutlet,

        // регистрация маршрутов приложения
        RouterModule.forRoot(routes)
    ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
