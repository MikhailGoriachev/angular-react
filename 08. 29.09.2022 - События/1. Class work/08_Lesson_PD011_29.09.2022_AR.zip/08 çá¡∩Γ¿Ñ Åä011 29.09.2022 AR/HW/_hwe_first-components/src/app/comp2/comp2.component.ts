// Компонент 2.
// В произвольном тексте, заданном присваиванием в классе компонента, найти
// самое длинное и самое короткое слово. Вывести текст и эти слова в разметку
// компонента.
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp2',
  templateUrl: './comp2.component.html',
  styleUrls: ['./comp2.component.css']
})
export class Comp2Component implements OnInit {

  // строки текста для обработки по заданию
  private static text: string[] = [
    'Если у вас до сих пор присутствуют классовые компоненты можно переписать их на функциональные',
    'Все это получается через пропсы и далее передается в последующие компоненты которые используются в компоненте Main',
    'Мемеоизация включает в себя отслеживание входных данных для функции и сохранение входных данных и результатов для дальнейшего использования. ',
  ];

  // строка для обработки
  str: string;

  // кратчайшее и длинннейшее слова
  shortest: string;
  longest: string;

  // в конструкторе выбираем строку для обработки
  constructor() {
    // выбор строки для обработки
    this.str = Comp2Component.text[Math.floor((Comp2Component.text.length-1) * Math.random())];

    // инициализация полей для хранения результатов
    this.shortest = this.longest = "";
  } // constructor

  // в событии инициализации выполнение обработки по заданию
  ngOnInit(): void {
    // получить массив слов
    let words = this.str
      .split(' ')
      .filter(w => w.length > 0);

    // массив длин слов
    let wordsLen = words.map(w => w.length);

    // ищем первое слово минимальной длины
    let minLen = Math.min(...wordsLen);
    this.shortest = words[words.findIndex(w => w.length == minLen)];

    // ищем первое слово максимальной длины
    let maxLen = Math.max(...wordsLen);
    this.longest = words[words.findIndex(w => w.length == maxLen)];
  } // ngOnInit

} // class Comp2Component
