// Компонент 3.
// Хранение и вывод данных о товаре – наименование, цена, количество,
// изображение товара.
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp3',
  templateUrl: './comp3.component.html',
  styleUrls: ['./comp3.component.css']
})
export class Comp3Component implements OnInit {

  // свойства компонента для хранения данных о товаре
  name: string;
  price: number;
  quantity: number;
  image: string;

  constructor() {
    this.name = this.image = "";
    this.price = this.quantity = 0;
  }

  // присвоить значения свойствам для отображения данных о товаре
  ngOnInit(): void {
    this.name = 'Адаптер Perfeo USB Type-C - HDMI - USB 3.0 (PF-Type-C-11)';
    this.price = 530;
    this.quantity = 15;
    this.image = 'hdmi-condensator.jpg';
  } // ngOnInit

} // class Comp3Component
