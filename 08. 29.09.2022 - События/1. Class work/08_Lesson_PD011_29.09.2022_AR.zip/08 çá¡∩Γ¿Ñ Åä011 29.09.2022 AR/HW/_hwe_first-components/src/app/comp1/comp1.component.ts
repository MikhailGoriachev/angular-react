// Компонент 1.
// В классе компонента разработать метод для вычисления и вывода в разметку
// значений z1, z2 по заданию. В качестве исходных данных примите случайные
// значения, формируемые в классе компонента.
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp1',
  templateUrl: './comp1.component.html',
  styleUrls: ['./comp1.component.css']
})
export class Comp1Component implements OnInit {

  // параметр для вычислений
  a: number;

  // результаты вычислений
  z1: number = 0;
  z2: number = 0;

  constructor() {
    this.a = this.getRand(-10, 10);
  } // constructor

  // в событии инициализации компонента вычисляем z1, z2 по заданию
  ngOnInit(): void {
    this.z1 = Math.pow(Math.cos(3*Math.PI/8 - this.a/4), 2) -
              Math.pow(Math.cos(11*Math.PI/8 + this.a/4), 2);
    this.z2 = Math.SQRT2/2 * Math.sin(this.a/2);
  } // ngOnInit

  // формирование случайного числа для использования в компоненте
  private getRand(lo: number, hi: number): number {
    return lo + (hi - lo)*Math.random();
  } // getRand

} // class Comp1Component222200
