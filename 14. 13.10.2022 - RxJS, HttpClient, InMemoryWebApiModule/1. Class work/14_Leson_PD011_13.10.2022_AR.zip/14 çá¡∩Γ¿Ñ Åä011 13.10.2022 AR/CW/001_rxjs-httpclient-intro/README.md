# RxjsHttpclientIntro

Введение в RxJS, HttpVClientModule
