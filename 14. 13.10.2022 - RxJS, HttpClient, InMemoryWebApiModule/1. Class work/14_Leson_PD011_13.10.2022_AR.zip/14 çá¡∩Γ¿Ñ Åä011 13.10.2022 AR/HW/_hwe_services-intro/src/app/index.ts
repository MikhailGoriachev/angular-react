// перечисление компонентов для экспорта
export * from "./app.component";
export * from "./home/home.component";
export * from "./c1/c1.component";
export * from "./fleet/fleet.component";
export * from "./gallery/gallery.component";
export * from "./not-found/not-found.component";

