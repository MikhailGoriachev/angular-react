import { Component, OnInit } from '@angular/core';
import {FleetService} from "../services/fleet.service";
import {FleetComponent} from "../fleet/fleet.component";

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
})
export class GalleryComponent implements OnInit {

  // коллекция названий файлов с изображениями кораблей
  photos: string[];

  constructor(fleetService: FleetService) {
    this.photos = (fleetService.exists() // данные есть в локальном хранилище?
      ?fleetService.loadFromLocalStore() // да - читаем
      :fleetService.getShips())          // нет - формируем
      .map(s => s.photo);         // получить массив имен файлов
  }

  ngOnInit(): void { }
  flag = 0;
  firstActive(): number{
    return this.flag++;
  }
}
