import { Component, OnInit } from '@angular/core';
import {FleetService} from "../services/fleet.service";
import {Ship} from "../../models/ship";

@Component({
  selector: 'app-fleet',
  templateUrl: './fleet.component.html',
})
export class FleetComponent implements OnInit {

  // отображаемое свойство
  public fleetForShow: Ship[];

  // fleetService - ссылка на сервис
  constructor(public fleetService: FleetService) {
    this.fleetForShow = this.fleetService. getShips();
  }

  ngOnInit(): void { }

  // чтение из сервиса коллекции в исходном порядке
  getFleet() {
    this.fleetForShow = this.fleetService.getShips();
  } // getFleet

  // удаление из коллекции по id
  removeById(id: number) {
    this.fleetService.removeById(id);
  }

  // упорядочивание по возрастанию года изготовления,
  // вывод в компонент
  orderByYear() {
    this.fleetForShow = this.fleetService.orderBy((s1, s2) => s1.builtYear - s2.builtYear);
  } // orderByYear


  // упорядочение по убыванию водоизмещения
  // вывод в компонент
  orderByDisplacement() {
    this.fleetForShow = this.fleetService.orderBy((s1, s2) => s2.displacement - s1.displacement);
  } // orderByDisplacement

  // упорядочивание по названиям кораблей
  // вывод в компонент
  orderByName() {
    this.fleetForShow = this.fleetService.orderBy((s1, s2) => s1.name.localeCompare(s2.name));
  } // orderByName

  // Добавление корабля в коллекцию
  addShip() {
    let id = this.fleetService.getMaxId() + 1;
    this.fleetService.add(new Ship(id, "линейный корабль", "Айдахо", 270, 33, 58_000, 1942, "Iowa.jpg"));
  } // addShip
}
