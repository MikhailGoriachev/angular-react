import { Injectable } from '@angular/core';

// Сервис для выполнения вычислений
// директива для создания:
// ng g s services/calculate
@Injectable({
  providedIn: 'root'
})
export class CalculateService {

  constructor() { }

  // формирование случайного числа в заданном диапазоне
  getRand(low: number = -10, high: number = 10): number {
    return low + (high - low)* Math.random();
  } // getRand

  // выдача двух случайных чисел, по заданию
  getCouple(low: number, high: number): number[] {
    return [this.getRand(low, high), this.getRand(low, high)]
  } // getCouple

  // вычисление в сервисе по заданию
  calculate(a: number, b: number): number[] {
    let z1 = (Math.cos(a) - Math.cos(b))**2 - (Math.sin(a) - Math.sin(b))**2;
    let z2 = -4 * Math.sin((a - b)/2)**2 * Math.cos(a + b);

    return [z1, z2];
  } // calculate
} // class CalculateService
