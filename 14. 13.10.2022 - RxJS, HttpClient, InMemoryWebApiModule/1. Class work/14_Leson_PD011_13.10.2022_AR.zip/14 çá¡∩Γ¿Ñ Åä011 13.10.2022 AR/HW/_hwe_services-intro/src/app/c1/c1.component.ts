import {Component, OnInit, ViewChild} from '@angular/core';
import {C2Component} from "./c2/c2.component";
import {C3Component} from "./c3/c3.component";
import {CalculateService} from "../services/calculate.service";

@Component({
  selector: 'app-c1',
  templateUrl: './c1.component.html',
  providers: [CalculateService]
})
export class C1Component implements OnInit {

  public a: number = 0;
  public b: number = 0;
  calculateService: CalculateService;

  constructor(calculateService: CalculateService) {
    this.calculateService = calculateService
  }
  ngOnInit(): void { }

  // получить ссылку на дочерний компонент C3
  @ViewChild('appC3') appC3: C3Component = null!;

  // обработчик клика по кнопке - генерация случайных чисел
  // и запуск вычислений
  calc() {
    // сформировать данные для вычислений
    [this.a, this.b] = this.calculateService.getCouple(-10, 10);
  }
} // class C1Component
