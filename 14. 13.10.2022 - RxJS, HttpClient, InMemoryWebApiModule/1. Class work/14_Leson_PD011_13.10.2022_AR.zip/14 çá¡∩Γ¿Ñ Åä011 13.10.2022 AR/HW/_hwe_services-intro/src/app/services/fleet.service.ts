// сведения о коллекции кораблей
import {Ship} from "../../models/ship";

import { Injectable } from '@angular/core';

// Сервис для выполнения вычислений
// директива для создания:
// ng g s services/fleet
@Injectable({
  providedIn: 'root'
})
export class FleetService {
  // массив сведений о кораблях
  ships: Ship[];

  constructor() {
    this.ships = [];
    if (this.exists())
      this.loadFromLocalStore();
    else {
      this.ships = [
        new Ship(101, "авианосец", "Дзюйкаку", 236.1, 29.8, 32_105, 1941, "Zuikaku.jpg"),
        new Ship(102, "авианосец", "Уосп", 226, 34.1, 19_716, 1940, "Wasp.jpg"),
        new Ship(103, "эскадренный миноносец", "Быстрый", 156.5, 17.2, 8_000, 1985, "Bystryi.jpg"),
        new Ship(104, "линейный корабль", "Айова", 270, 33, 58_000, 1942, "Iowa.jpg"),
        new Ship(105, "линейный корабль", "Тирпиц", 253.6, 36, 53_570, 1941, "Tirpitz.jpg"),
        new Ship(106, "линейный корабль", "Марат", 184.9, 26.9, 26_900, 1914, "Marat.jpg"),
        new Ship(107, "линейный корабль", "Миссури", 271, 33, 57_000, 1944, "Missouri.jpg"),
        new Ship(108, "линейный корабль", "Ямато", 263, 38.9, 72_808, 1941, "Yamato.jpg"),
        new Ship(109, "авианосец", "Интрепид", 265.9, 45, 36_960, 1943, "Intrepid.jpg"),
        new Ship(110, "авианосец", "Акаги", 249, 31, 41_300, 1927, "Akagi.jpg"),
      ];

      // сохранить массив кораблей в локальном хранилище
      this.saveToLocalStore();
    }
  }

  // формирование коллекции сведений о кораблях
  getShips() {
    // вернуть массив кораблей
    return this.ships;
  } // getShips

  // проверка наличия коллекции в локальном хранилище
  exists(): boolean {
    return window.localStorage['lv-fleet-vl'] != undefined;
  } // exists

  // запись коллекции в локальное хранилище
  saveToLocalStore() {
    window.localStorage['lv-fleet-vl'] = JSON.stringify(this.ships);
  } // saveToLocalStore

  // чтение коллекции из локального хранилища
  loadFromLocalStore(): Ship[]  {
    // прочитать строку из хранилища и распарсить ее в объект
    // сформировать коллекцию сведений о кораблях из сохраненных данных
    JSON
      .parse(window.localStorage["lv-fleet-vl"])
      .forEach((s: Ship) => this.ships.push(new Ship().assign(s)));
    return this.ships;
  } // loadFromLocalStore

  // сортировка копии коллекции
  orderBy(comparer: (s1: Ship, s2: Ship) => number): Ship[] {
    return [...this.ships].sort(comparer)
  } // orderBy

  // добавление сведений о корабле в коллекцию
  add(ship: Ship): void {
    this.ships.unshift(ship);
    this.saveToLocalStore();
  }

  // удаление сведений о корабле из коллекции
  removeById(id: number): void {
    let index = this.ships.findIndex(s => s.id === id);
    this.removeAt(index);
  } // removeById

  // удаление сведений о корабле по индексу
  removeAt(index: number): void {
    if (index < 0 || index > this.ships.length-1) return;

    this.ships.splice(index, 1);
    this.saveToLocalStore();
  } // removeAt

  // возвращает максимальный идентификатоо
  getMaxId() {
    return Math.max(...this.ships.map(s => s.id));
  } // getMaxId
}
