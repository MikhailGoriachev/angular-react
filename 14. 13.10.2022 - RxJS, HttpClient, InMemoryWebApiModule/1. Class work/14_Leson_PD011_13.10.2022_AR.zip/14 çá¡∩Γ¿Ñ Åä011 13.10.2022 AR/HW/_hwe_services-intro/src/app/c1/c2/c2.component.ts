import {Component, EventEmitter, OnInit, OnChanges, Output} from '@angular/core';
import {CalculateService} from "../../services/calculate.service";

@Component({
  selector: 'app-c2',
  templateUrl: './c2.component.html',
  inputs: ['a', 'b'],

  providers: [CalculateService]
})
export class C2Component implements OnInit, OnChanges {
  // исходные данные для вычислений
  a: number = 0;
  b: number = 0;

  calculateSerice: CalculateService;

  constructor(calculateSerice: CalculateService) {
    this.calculateSerice = calculateSerice;
  }
  ngOnInit(): void {  }

  // событие, зажигаемое после вычисления по заданию
  @Output() resultReadyEvent: EventEmitter<number[]> = new EventEmitter();

  // вычисление по заданию, зажигание события по окончании вычислений
  ngOnChanges(): void {
    // вычисление
    let [z1, z2] = this.calculateSerice.calculate(this.a, this.b);

    // зажигаем событие
    this.resultReadyEvent.emit([z1, z2]);
  } // ngOnChanges
} // class C2Component
