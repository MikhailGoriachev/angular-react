import { Component, OnInit } from '@angular/core';
import { Ship } from "../../../models/ship";
import { FleetService } from "../../services/fleet.service";

@Component({
  selector: 'app-fleet',
  templateUrl: './fleet.component.html'
})
export class FleetComponent implements OnInit {

  displayShips: Ship[];
  
  constructor(private fleet: FleetService) {
    this.displayShips = this.fleet.getShips();
  }

  ngOnInit(): void {
  }

  addShip() {
    this.fleet.add(this.fleet.randomShip());
  }

  removeShip(id: number) {
    this.fleet.remove(id);
  }
}
