import { Injectable } from '@angular/core';
import { getRandom } from "../../util/randoms";

@Injectable({
    providedIn: 'root'
})
export class CalculateService {
    private readonly min: number = 1;
    private readonly max: number = 10;


    constructor() {
    }

    getAlphaBeta(): { a: number, b: number } {
        return { a: getRandom(this.min, this.max), b: getRandom(this.min, this.max) };
    }

    calc(a: number, b: number) {
        return [
            (Math.cos(a) - Math.cos(b)) ** 2 - (Math.sin(a) - Math.sin(b)) ** 2,
            -4 * Math.sin((a - b) / 2) ** 2 * Math.cos(a + b)
        ];
    }

}
