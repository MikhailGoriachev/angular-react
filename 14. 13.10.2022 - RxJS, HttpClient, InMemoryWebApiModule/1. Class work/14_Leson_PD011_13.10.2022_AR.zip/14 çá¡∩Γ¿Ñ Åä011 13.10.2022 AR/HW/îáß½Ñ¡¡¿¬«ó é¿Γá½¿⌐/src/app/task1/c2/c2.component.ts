import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CalculateService } from "../../services/calculate.service";

@Component({
  selector: 'app-c2',
  templateUrl: './c2.component.html',
  providers: [CalculateService]
})
export class C2Component implements OnInit {
  // исходные данные для вычислений
  @Input() a: number = 0;
  @Input() b: number = 0;

  constructor(private calcService: CalculateService) { }
  ngOnInit(): void {  }

  // событие, зажигаемое после вычисления по заданию
  @Output() onCalculated: EventEmitter<number[]> = new EventEmitter();

  // вычисление по заданию
  calculate(): void {
    this.onCalculated.emit(this.calcService.calc(this.a, this.b));
  }
}
