import { Component, OnInit, ViewChild } from '@angular/core';
import { C3Component } from "../c3/c3.component";
import { getRandomInt } from "../../../util/randoms";
import { CalculateService } from "../../services/calculate.service";

@Component({
    selector: 'app-c1',
    templateUrl: './c1.component.html',
    providers: [CalculateService]
})
export class C1Component implements OnInit {
  
    @ViewChild('C3') c3comp: C3Component = new C3Component();

    constructor(private calcService: CalculateService) {  }

    ngOnInit(): void {  }

    calc() {
        this.c3comp.runCalculate(this.calcService.getAlphaBeta());
    }
}
