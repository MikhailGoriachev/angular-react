import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from "./home/home.component";
import { C1Component } from "./task1/c1/c1.component";
import { FleetComponent } from "./task2/fleet/fleet.component";
import { ShipsPhotosComponent } from "./task2/ships-photos/ships-photos.component";

const routes: Routes = [
    { path: '', component: HomeComponent, data: { title: 'Главная' } },
    { path: 'calcs', component: C1Component, data: { title: 'Вычисления' } },
    { path: 'fleet', component: FleetComponent, data: { title: 'Вычисления' } },
    { path: 'carousel', component: ShipsPhotosComponent, data: { title: 'Карусель' } },
    { path: '**', redirectTo: '/' },];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule {
    
}
