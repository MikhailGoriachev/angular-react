import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { IconNamesEnum } from "ngx-bootstrap-icons";
import { Ship } from "../../../models/ship";
import { sortBy } from "../../../util/array";

@Component({
  selector: 'app-ships-table',
  templateUrl: './ships-table.component.html'
})
export class ShipsTableComponent implements OnInit {

  iconNames = IconNamesEnum;

  @Input() ships: Ship[] = [];

  @Output() onAddShip = new EventEmitter();
  @Output() onRemoveShip = new EventEmitter<number>();

  // настройка колонок
  columns = [
    { name: 'Id', sortProp: (s: Ship) => s.id },
    { name: 'Фото', sortProp: null },
    { name: 'Название', sortProp: (s: Ship) => s.name },
    { name: 'Тип', sortProp: (s: Ship) => s.type },
    { name: 'Длина, м', sortProp: (s: Ship) => s.length },
    { name: 'Ширина, м', sortProp: (s: Ship) => s.width },
    { name: 'Водоизмещение, л', sortProp: (s: Ship) => s.displacement },
    { name: 'Год постройки', sortProp: (s: Ship) => s.year },
  ];

  isOrderDescend: boolean = false;   // текущий порядок сортировки в таблице   
  lastSorted: string = "Id";         // последний сортированный столбец


  constructor() {
  }

  ngOnInit(): void {
  }


  addShip() {
    this.onAddShip.emit();
  }

  removeShip(id: number) {
    this.onRemoveShip.emit(id);
  }

  // сортировка таблицы
  onOrderChanged(columnName: string, propGetter: (s: Ship) => number | string) {

    if (columnName == this.lastSorted)
      this.isOrderDescend = !this.isOrderDescend;

    this.lastSorted = columnName;

    sortBy(this.ships, propGetter, this.isOrderDescend);
  }

}
