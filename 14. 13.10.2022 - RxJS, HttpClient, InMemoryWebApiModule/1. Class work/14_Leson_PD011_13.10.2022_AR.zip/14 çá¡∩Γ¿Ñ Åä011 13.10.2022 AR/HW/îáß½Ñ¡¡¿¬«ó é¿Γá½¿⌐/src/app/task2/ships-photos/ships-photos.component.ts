import { Component, OnInit } from '@angular/core';
import { FleetService } from "../../services/fleet.service";
import { Ship } from "../../../models/ship";

@Component({
    selector: 'app-ships-photos',
    templateUrl: './ships-photos.component.html',
    styles: [` .text-shadow {
        text-shadow: 2px 2px #000
    } `]
})
export class ShipsPhotosComponent implements OnInit {
    ships: Ship[];

    constructor(private fleet: FleetService) {
        this.ships = fleet.getShips();
    }

    ngOnInit(): void {
    }
}
