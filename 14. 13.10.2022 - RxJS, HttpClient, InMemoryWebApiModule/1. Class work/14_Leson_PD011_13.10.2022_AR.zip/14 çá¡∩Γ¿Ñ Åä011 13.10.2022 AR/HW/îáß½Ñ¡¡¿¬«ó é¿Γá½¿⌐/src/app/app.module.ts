import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgxBootstrapIconsModule } from 'ngx-bootstrap-icons';
import { arrowDownShort, arrowUpShort, recycle, trashFill, plusCircle } from "ngx-bootstrap-icons";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HomeComponent } from './home/home.component';

import { Task1Module } from "./task1/task1.module";
import { Task2Module } from "./task2/task2.module";

const icons = { arrowDownShort, arrowUpShort, recycle, plusCircle, trashFill };

@NgModule({
    declarations: [
        AppComponent,
        HomeComponent,
        HeaderComponent,
        FooterComponent,
        NavbarComponent,
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        NgxBootstrapIconsModule.pick(icons),
        Task1Module,
        Task2Module
    ],
    providers: [],
    bootstrap: [AppComponent]
})

export class AppModule {
}
