﻿
function renderShipStack(stack: Stack<Ship>, outElement: JQuery) {
    const iter = stack.iterStack();

    outElement.empty();

    if(stack.peek() === undefined) {
        outElement.append($("<tr/>").append($("<td/>")
            .attr("colspan", "8")
            .text("Элементы отсутствуют")));
        return;
    }

    let row = 1;
    for (const stackElement of iter) {
        outElement.append(stackElement.toHtmlTableRow(row++));
    }
}

function initTask3() {
    let table = $("<table/>").addClass("table table-striped w-auto caption-top mt-3 mb-5")
        .append($("<caption/>").addClass("fs-5")
            .text("Элементы стека:"))
        .append($("<thead/>")
            .append($("<tr/>").addClass("text-center")
                .append($("<th/>").addClass("px-3").text("№"))
                .append($("<th/>").addClass("px-3").text("Категория"))
                .append($("<th/>").addClass("px-3").text("Координаты"))
                .append($("<th/>").addClass("px-3").text("Цена, руб"))
                .append($("<th/>").addClass("px-3").text("Скорость, км/ч"))
                .append($("<th/>").addClass("px-3").text("Год изг."))
                .append($("<th/>").addClass("px-3").text("Кол-во пассаж."))
                .append($("<th/>").addClass("px-3").text("Высота полета / порт приписки"))
            ))
        .append($("<tbody/>").addClass("color-2")
            .attr("id", "output"));
    
    $("#main").append(table);

    let stack = new Stack<Ship>(),
        $output = $("#output"),
        $push = $("#push"),
        $pop = $("#pop");

    let ships = [new Ship("корабль",{latitude: 13.123, longitude: -13.199}, 123_000_000, 60, 1998, 460, "Новороссийск"),
        new Ship("корабль",{latitude: -93.3, longitude: -123.9}, 89_000_000, 40, 2012, 120, "Керчь"),
        new Ship("корабль", {latitude: -113.3, longitude: 90.9}, 18_000_000, 20, 1995, 20, "Новоазовск")]

    $push.on("click", e => {
        let ship = ships[getRandomInt(0, ships.length - 1)];
        stack.push(ship);
        $pop.removeAttr("disabled")
        renderShipStack(stack, $output);
    })    
   
    $pop.on("click", e => {
        stack.pop();

        if(stack.peek() === undefined)
            $pop.attr("disabled", "true");

        renderShipStack(stack, $output);
    })

    renderShipStack(stack, $output);
}

$(initTask3)