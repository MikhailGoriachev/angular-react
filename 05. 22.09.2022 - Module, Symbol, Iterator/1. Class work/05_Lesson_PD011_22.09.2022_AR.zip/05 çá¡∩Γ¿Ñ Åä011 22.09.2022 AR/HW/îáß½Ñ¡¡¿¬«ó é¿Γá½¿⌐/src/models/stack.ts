﻿class Stack<T> {
    private _data: T[] = [];

    push(item: T) {
        this._data.push(item);
    }

    pop(): T | undefined {
        return this._data.pop();
    }

    public peek(): T | undefined {
        return this._data.at(-1) as T | undefined;
    }

    // но это же массив....
    *iterStack<T>() {
        for(let item of this._data) {
            yield item;
        }
    }
}