﻿type Coord = { latitude: number, longitude: number };

// Базовый класс, описывающий транспортное средство
abstract class Vehicle {
    protected constructor(protected _category: string, protected _coordinates: Coord,
                          protected _price: number, protected _velocity: number, protected _year: number) {
    }

    get category(): string { return this._category; }
    set category(value: string) { if (value) this._category = value; }

    get coordinates(): Coord { return this._coordinates; }
    set coordinates(value: Coord) {
        if ((-180 <= value.latitude || value.latitude <= 180) &&
            (-180 <= value.longitude || value.longitude <= 180))
            this._coordinates = value;
    }

    get price(): number { return this._price; }
    set price(value: number) { if (value > 0) this._price = value; }

    get velocity(): number { return this._velocity; }
    set velocity(value: number) { if (value > 0) this._velocity = value; }

    get year(): number { return this._year; }
    set year(value: number) { if (value > 0) this._year = value; }

    toHtmlTableRow(row: number): JQuery {
        return $("<tr/>").addClass("text-end")
            .append($("<td/>").addClass("text-center").text(row))
            .append($("<td/>").addClass("text-start")
                .text(this._category))
            .append($("<td/>").text(`${this._coordinates.latitude}; ${this._coordinates.longitude}`))
            .append($("<td/>").text(this._price))
            .append($("<td/>").text(this._velocity))
            .append($("<td/>").text(this._year))
    };
}

// Класс описывающий корабль
class Ship extends Vehicle {
    constructor(category: string, coordinates: Coord,
                price: number, velocity: number, year: number, private _pax: number, private _homePort: string) {
        super(category, coordinates, price, velocity, year);
    }

    get homePort() { return this._homePort; }
    set homePort(value) { this._homePort = value; }

    get pax() { return this._pax; }
    set pax(value) { if (value > 0) this._pax = value; }

    toHtmlTableRow(row: number): JQuery {
        return super.toHtmlTableRow(row)
            .append($("<td/>").text(this._pax))
            .append($("<td/>").text(this._homePort).addClass("text-center"))
    }
}
