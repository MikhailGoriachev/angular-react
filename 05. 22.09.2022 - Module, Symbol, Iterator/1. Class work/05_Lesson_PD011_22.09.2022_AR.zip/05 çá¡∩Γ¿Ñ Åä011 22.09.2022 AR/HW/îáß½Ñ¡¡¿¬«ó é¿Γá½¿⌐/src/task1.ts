﻿
function renderNumberStack(stack: Stack<number>, outElement: JQuery) {
    const iter = stack.iterStack();
    
    outElement.empty();
    
    if(stack.peek() === undefined) {
        outElement.removeClass("border border-2 border-dark")
            .append($("<span/>")
            .addClass("color-2")
            .text("Элементы отсутствуют"));
        return;
    }
    
    for (const stackElement of iter) {
        outElement.addClass("border border-2 border-dark")
            .append($("<span/>")
            .addClass("badge bg-secondary fs-3 ms-2 mt-2")
            .text(stackElement));
    }
}

function initTask1() {
    const minValue = -10, 
          maxValue = 10;
    
    let stack = new Stack<number>(),
        $output = $("#output"),
        $push = $("#push"),
        $pop = $("#pop");

    $push.on("click", e => {
        stack.push(getRandomInt(minValue, maxValue));
        $pop.removeAttr("disabled")
        renderNumberStack(stack, $output);
    })

    $pop.on("click", e => {
        stack.pop();
        
        if(stack.peek() === undefined)
            $pop.attr("disabled", "true");
        
        renderNumberStack(stack, $output);
    })

    renderNumberStack(stack, $output);
}

$(initTask1);