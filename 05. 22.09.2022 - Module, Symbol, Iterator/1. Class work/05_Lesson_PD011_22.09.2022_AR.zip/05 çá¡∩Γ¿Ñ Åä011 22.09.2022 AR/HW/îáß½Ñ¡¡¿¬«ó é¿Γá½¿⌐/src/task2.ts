﻿
function renderStringStack(stack: Stack<string>, outElement: JQuery) {
    const iter = stack.iterStack();

    outElement.empty();

    if(stack.peek() === undefined) {
        outElement.append($("<span/>")
                .addClass("color-2")
                .text("Элементы отсутствуют"));
        return;
    }

    for (const stackElement of iter) {
        outElement.append($("<span/>")
                .addClass("ms-2 mt-2 color-1")
                .text(stackElement));
    }
}

function initTask2() {

    let stack = new Stack<string>(),
        $output = $("#output"),
        $push = $("#push"),
        $pop = $("#pop"),
        $inpPush = $("#inpPush");

    $push.on("click", e => {
        const value = $inpPush.val() as string;
        
        if(!value) return;
        
        stack.push(value);
        
        $pop.removeAttr("disabled");
        $inpPush.val("");
        
        renderStringStack(stack, $output);
        
        $inpPush.focus();
    })

    $pop.on("click", e => {
        $("#popOutput").text(stack.pop() ?? "");

        if(stack.peek() === undefined)
            $pop.attr("disabled", "true");

        renderStringStack(stack, $output);
    })

    renderStringStack(stack, $output);
}

$(initTask2);