// координаты  (географические) транспортного средства
class Coordinates {
    constructor(private _longitude: number, private _latitude: number) {
    }

    // аксессор долготы
    get longitude(): number { return this._longitude;}
    set longitude(value: number) { this._longitude = value; }

    // аксессор широты
    get latitude(): number { return this._latitude;}
    set latitude(value: number) { this._latitude = value; }
} // class Coordinates