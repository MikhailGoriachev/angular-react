// транспортное средство
// категория, координаты, цена, скорость, год выпуска
abstract class Vehicle {
    constructor(
        protected _category: string, protected _coordinates: Coordinates,
        protected _price: number,  protected _velocity: number, protected _year: number)
    { } // constructor


    get category(): string { return this._category; }
    set category(value: string) {
        this._category = value;
    }

    get coordinates(): Coordinates { return this._coordinates; }
    set coordinates(value: Coordinates) {
        this._coordinates = value;
    }

    get price(): number { return this._price; }
    set price(value: number) {
        this._price = value;
    }

    get velocity(): number { return this._velocity;    }
    set velocity(value: number) {
        this._velocity = value;
    }

    get year(): number { return this._year; }
    set year(value: number) {
        this._year = value;
    }

    // вывод строкового представления данных транспортного средства
    toString(): string {
        return `${this._category}: (${this._coordinates.latitude}:${this._coordinates.longitude}); ` +
            `${this._velocity} км/ч ${this._price} руб., ${this._year} г.`;
    }
} // class Vehicle
