// обобщенный класс Stack - реализация доступа к массиву LIFO
class Stack<T> {
    // конструктор получает массив данных или, по умолчанию, создает пустой массив
    constructor(private _data: T[] = []) { }

    // Добавление на вершину стека
    push(...values: T[]): void { this._data.push(...values); }

    // Извлечение с вершины стека
    pop(): T | undefined {
        if (this._data.length == 0) return undefined;

        return this._data.pop();
    } // pop

    // Чтение вершины стека
    top(): T | undefined {
        if (this._data.length == 0) return undefined;

        return this._data[this._data.length-1];
    } // top

    // Метод-генератор для просмотра стека
    *getItems() {
        for (let i = this._data.length-1; i >= 0; i--) {
            yield this._data[i];
        } // for i
    } // getItems

    // Показать стек в консоли
    static showInConsole<T>(stack: Stack<T>, title: string="Стек для демонстрации:") {
        console.log(title);

        // собственно вывод стека в консоль
        let iterator = stack.getItems();
        for (const item of iterator) {
            console.log(item.toString())   ;
        } // for item
    } // showInConsole

} // class Stack