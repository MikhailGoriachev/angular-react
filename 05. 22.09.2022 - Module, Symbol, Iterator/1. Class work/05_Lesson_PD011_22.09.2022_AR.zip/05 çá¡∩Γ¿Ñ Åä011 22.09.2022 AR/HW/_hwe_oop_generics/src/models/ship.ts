// корабль, добавляются свойства: количество пассажиров, порт приписки
class Ship extends Vehicle {
    constructor(coordinates: Coordinates, price: number, velocity: number, year: number,
                private _paxes: number, private _homePort: string) {
        super("корабль", coordinates, price, velocity, year);
    } // constructor


    get paxes(): number {  return this._paxes; }
    set paxes(value: number) {
        this._paxes = value;
    }

    get homePort(): string { return this._homePort; }
    set homePort(value: string) {
        this._homePort = value;
    }

    // вывод строкового представления данных о корабле
    toString(): string {
        return `${super.toString()} ${this._paxes} чел., ${this._homePort}`;
    } // toString
} // class Ship