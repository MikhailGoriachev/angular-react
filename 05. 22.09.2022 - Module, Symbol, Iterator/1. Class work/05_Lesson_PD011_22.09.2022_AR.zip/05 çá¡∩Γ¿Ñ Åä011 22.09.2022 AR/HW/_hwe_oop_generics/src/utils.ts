// функция - генератор случайных чисел, все значения по модулю меньшие 1
// заменяем нулями
function getRand(from: number, to: number): number {
    let value: number = from + (to - from)*Math.random();
    if (Math.abs(value) < 1) {
        value = 0;
    } // if

    return value
} // getRand


// поиск элемента DOM-дерева по его идентификатору
function $(id: string) {
    return document.getElementById(id);
} // $
