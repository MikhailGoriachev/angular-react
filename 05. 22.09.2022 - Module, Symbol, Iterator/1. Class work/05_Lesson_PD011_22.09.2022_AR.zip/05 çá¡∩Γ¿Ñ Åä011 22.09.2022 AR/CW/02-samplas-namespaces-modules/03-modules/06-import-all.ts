import * as validators from "01-validators"; // импорт всего содержимого модуля в переменную validators

let ccValidtor = new validators.CreditCardValidator();
let urlValidtor = new validators.UrlValidator();