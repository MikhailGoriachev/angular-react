import { MyEmailValidator } from "03-export-statement";

let x: MyEmailValidator = new MyEmailValidator();