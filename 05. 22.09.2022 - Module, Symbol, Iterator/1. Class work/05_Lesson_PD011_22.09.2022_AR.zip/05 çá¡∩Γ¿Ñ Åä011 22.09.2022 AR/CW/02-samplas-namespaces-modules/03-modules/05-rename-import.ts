// импорт с указанием другого имени
import { MyEmailValidator as MEV } from "03-export-statement";

let x: MEV = new MEV();