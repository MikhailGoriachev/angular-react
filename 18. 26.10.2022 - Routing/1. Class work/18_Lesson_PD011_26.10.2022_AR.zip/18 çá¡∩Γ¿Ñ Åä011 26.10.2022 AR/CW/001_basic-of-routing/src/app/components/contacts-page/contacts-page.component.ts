import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contacts-page',
  templateUrl: './contacts-page.component.html'
})
export class ContactsPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
