import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page404',
  templateUrl: './page404.component.html',
  styles: [`h2{
    text-align: center;
    font-size: 40px;
    background: pink;
}`]
})
export class Page404Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
