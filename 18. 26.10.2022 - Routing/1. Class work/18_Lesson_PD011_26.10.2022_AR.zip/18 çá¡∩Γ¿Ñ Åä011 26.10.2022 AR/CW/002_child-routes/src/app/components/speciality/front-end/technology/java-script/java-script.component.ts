import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-java-script',
  templateUrl: './java-script.component.html'
})
export class JavaScriptComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
