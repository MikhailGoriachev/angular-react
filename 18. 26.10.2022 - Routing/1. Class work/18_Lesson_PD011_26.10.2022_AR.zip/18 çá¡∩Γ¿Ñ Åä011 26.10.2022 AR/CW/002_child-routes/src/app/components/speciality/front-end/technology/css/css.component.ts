import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-css',
  templateUrl: './css.component.html'
})
export class CssComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
