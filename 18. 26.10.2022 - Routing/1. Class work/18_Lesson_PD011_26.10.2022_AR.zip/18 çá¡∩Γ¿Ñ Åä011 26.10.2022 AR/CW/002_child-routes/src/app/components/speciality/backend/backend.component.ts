import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-backend',
  templateUrl: './backend.component.html'
})
export class BackendComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
