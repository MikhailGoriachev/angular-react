import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theory',
  templateUrl: './theory.component.html'
})
export class TheoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
