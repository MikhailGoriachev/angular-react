import { Component, ContentChild, Directive, EventEmitter, Input, OnChanges, OnInit, Output, TemplateRef } from '@angular/core';
import { ColumnOption } from "../types";
import { isNumber } from "radash";
import { IconNamesEnum } from "ngx-bootstrap-icons";
import { UntilDestroy } from "@ngneat/until-destroy";


type ListItemTemplateContext<T> = {
    $implicit: T;
};


@Directive({
    selector: 'ng-template[row-item]'
})
export class ListItemDirective<T> {
    @Input("row-item") item!: T[];

    static ngTemplateContextGuard<TContext>(
        directive: ListItemDirective<TContext>,
        context: unknown
    ): context is ListItemTemplateContext<TContext> {
        return true;
    }
}

@UntilDestroy()
@Component({
    selector: 'app-table[items][columns]',
    templateUrl: './table.component.html'
})
export class TableComponent<T extends { id: number; }> implements OnInit, OnChanges {
    iconNames = IconNamesEnum;

    @Input() items: T[] = [];
    @Input() columns: ColumnOption<T>[] = [];
    @Input() isControlled: boolean = true;

    @Output() onAdd = new EventEmitter();
    @Output() onEdit = new EventEmitter<number>();
    @Output() onRemove = new EventEmitter<number>();

    @ContentChild(ListItemDirective, { read: TemplateRef })
    rowItem: TemplateRef<T> | null = null;

    isOrderDescend: boolean = false;
    lastSorted: string = this.columns[0]?.name;

    constructor() {
    }

    ngOnInit(): void {   }

    ngOnChanges() {
        this.isOrderDescend = false;
        this.lastSorted = this.columns[0]?.name;
    }

    onOrderChanged(name: string, property: (item: T) => number | string | Date) {
        if (name == this.lastSorted)
            this.isOrderDescend = !this.isOrderDescend;

        this.lastSorted = name;
        this.sortBy(this.items, property, this.isOrderDescend);
    }

    sortBy(array: T[],
           get: (item: T) => number | string | Date,
           isDescend: boolean = false) {
        array.sort((a, b) => get(a).toString()
                .localeCompare(get(b).toString(), undefined, { numeric: isNumber(get(a)) })
            * (isDescend ? -1 : 1));
    }
}
