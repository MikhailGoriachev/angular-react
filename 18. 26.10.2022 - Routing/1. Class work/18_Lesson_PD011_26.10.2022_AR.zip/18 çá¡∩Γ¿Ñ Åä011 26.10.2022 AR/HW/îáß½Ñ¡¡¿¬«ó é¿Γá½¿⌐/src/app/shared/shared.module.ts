import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ValidateMessageComponent } from './validate-message/validate-message.component';
import { TableComponent, ListItemDirective } from './table/table.component';
import { NgxBootstrapIconsModule } from "ngx-bootstrap-icons";



@NgModule({
  declarations: [
    ValidateMessageComponent,
    TableComponent,
    ListItemDirective
  ],
  exports: [
    ValidateMessageComponent,
    TableComponent,
    ListItemDirective
  ],
  imports: [
    CommonModule,
    NgxBootstrapIconsModule
  ]
})
export class SharedModule { }
