import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Group, Rank, Student, Trainer } from "../../services/backend.service";
import { Observable } from "rxjs";

@Injectable({
    providedIn: 'root'
})
export class SportClubService {

    constructor(private http: HttpClient) {
    }

    getStudents() {
        return this.http.get<Student[]>('api/students');
    }

    getStudentById(id: number) {
        return this.http.get<Student>(`api/students/${id}`);
    }

    addStudent(student: Student) {
        return this.http.post('api/students', { ...student });
    }

    editStudent(student: Student){
        return this.http.put(`api/students/${student.id}`, student);
    }

    deleteStudent(id: number): Observable<Student>{
        return this.http.delete<Student>(`api/students/${id}`);
    }

    getTrainers() {
        return this.http.get<Trainer[]>('api/trainers');
    }

    getTrainerById(id: number) {
        return this.http.get<Trainer>(`api/trainers/${id}`);
    }

    getGroups() {
        return this.http.get<Group[]>('api/groups');
    }

    getGroupById(id: number) {
        return this.http.get<Group>(`api/groups/${id}`);
    }

    getRanks() {
        return this.http.get<Rank[]>('api/ranks');
    }

    getRankById(id: number) {
        return this.http.get<Rank>(`api/ranks/${id}`);
    }
}
