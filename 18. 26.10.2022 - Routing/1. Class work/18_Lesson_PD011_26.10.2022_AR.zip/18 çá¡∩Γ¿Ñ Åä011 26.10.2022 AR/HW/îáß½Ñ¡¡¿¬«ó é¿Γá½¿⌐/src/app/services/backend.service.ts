import {Injectable} from '@angular/core';
import {InMemoryDbService} from "angular-in-memory-web-api";
import {draw, random, unique} from "radash";

export type Rank = {
    id: number,
    name: string
};

export type Trainer = {
    id: number,
    fullName: string
};

export type Group = {
    id: number,
    name: string,
    trainer: Trainer
};

export type Student = {
    id: number,
    fullName: string,
    dob: Date,
    phone: string,
    email: string,
    rank: Rank,
    group: Group,
};

@Injectable({
    providedIn: 'root'
})
export class BackendService implements InMemoryDbService {

    constructor() {
    }

    createDb() {

        const ranks: Rank[] = [
            {id: 1, name: "10 кю"},
            {id: 2, name: "9 кю"},
            {id: 3, name: "8 кю"},
            {id: 4, name: "7 кю"},
            {id: 5, name: "6 кю"},
            {id: 6, name: "5 кю"},
            {id: 7, name: "4 кю"},
            {id: 8, name: "3 кю"},
            {id: 9, name: "2 кю"},
            {id: 10, name: "1 кю"},
            {id: 11, name: "1 дан"},
            {id: 12, name: "2 дан"},
        ]

        const trainers: Trainer[] = [
            {id: 1, fullName: "Терентьев Т. М."},
            {id: 2, fullName: "Калинин Л. Б."},
            {id: 3, fullName: "Рябов И. Г."},
            {id: 4, fullName: "Макаров Д. С."},
        ]

        const groups: Group[] = [
            {id: 1, name: "У-01", trainer: trainers[0]},
            {id: 2, name: "У-02", trainer: trainers[1]},
            {id: 3, name: "Д-01", trainer: trainers[0]},
            {id: 4, name: "Д-02", trainer: trainers[1]},
            {id: 5, name: "В-01", trainer: trainers[2]},
            {id: 6, name: "В-02", trainer: trainers[3]},
        ]

        const students: Student[] = [
            {id:  1, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "sbalistreri@cormier.com", fullName: "Архипов Г."},
            {id:  2, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "jaron07@gmail.com", fullName: "Коровин Л."},
            {id:  3, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "ierdman@yahoo.com", fullName: "Панков М."},
            {id:  4, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "gwunsch@wilderman.com", fullName: "Попов А."},
            {id:  5, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "eula.champlin@gmail.com", fullName: "Моисеев В."},
            {id:  6, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "adolph.jacobi@yahoo.com", fullName: "Голиков М."},
            {id:  7, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "huels.nella@gmail.com", fullName: "Спиридонов Д."},
            {id:  8, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "geo33@wisoky.net", fullName: "Хохлов Д."},
            {id:  9, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "rrutherford@considine.org", fullName: "Поликарпов М."},
            {id: 10, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "jayne42@breitenberg.com", fullName: "Филатов Г."},
            {id: 11, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "jace.johnston@hotmail.com", fullName: "Шишкин М."},
            {id: 12, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "evangeline33@gmail.com", fullName: "Черкасов А."},
            {id: 13, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "lourdes50@waters.com", fullName: "Громов П."},
            {id: 14, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "bert52@yahoo.com", fullName: "Макаров А."},
            {id: 15, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "aufderhar.myrtle@schoen.biz", fullName: "Исаев А."},
            {id: 16, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "perry43@collins.com", fullName: "Демьянов П."},
            {id: 17, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "pollich.stewart@kulas.net", fullName: "Родионов А."},
            {id: 18, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "wkozey@yahoo.com", fullName: "Глушков П."},
            {id: 19, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "shanny69@yahoo.com", fullName: "Иванов С."},
            {id: 20, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "jaycee14@walter.com", fullName: "Васильев С."},
            {id: 21, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "sabbott@kuvalis.com", fullName: "Романов А."},
            {id: 22, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "crona.dillan@rogahn.com", fullName: "Ковалев Л."},
            {id: 23, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "stark.odell@gmail.com", fullName: "Давыдов А."},
            {id: 24, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "alicia07@gmail.com", fullName: "Черный Г."},
            {id: 25, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "gabriel.kris@lowe.biz", fullName: "Макаров М."},
            {id: 26, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "fkrajcik@hudson.biz", fullName: "Морозов М."},
            {id: 27, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "wehner.franco@emmerich.biz", fullName: "Фомин Р."},
            {id: 28, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "uwill@anderson.com", fullName: "Наумов Я."},
            {id: 29, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "feeney.lexus@yahoo.com", fullName: "Иванов М."},
            {id: 30, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "lockman.deion@hotmail.com", fullName: "Большаков Р."},
            {id: 31, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "sigrid07@considine.biz", fullName: "Котов Д."},
            {id: 32, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "mueller.marlene@kuhlman.com", fullName: "Соколов А."},
            {id: 33, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "fahey.graciela@gmail.com", fullName: "Петров Г."},
            {id: 34, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "graham.gaston@oreilly.info", fullName: "Назаров П."},
            {id: 35, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "janick37@mosciski.info", fullName: "Орлов А."},
            {id: 36, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "altenwerth.alanis@ward.com", fullName: "Левин Г."},
            {id: 37, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "turcotte.nakia@yahoo.com", fullName: "Зотов М."},
            {id: 38, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "goyette.jeromy@gmail.com", fullName: "Васильев А."},
            {id: 39, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "adolphus.kovacek@bradtke.com", fullName: "Васильев Ф."},
            {id: 40, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "austin.fritsch@yahoo.com", fullName: "Столяров А."},
            {id: 41, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "schultz.santa@boehm.com", fullName: "Лебедев А."},
            {id: 42, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "wisozk.erich@yahoo.com", fullName: "Панин С."},
            {id: 43, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "andreanne.gerlach@gleichner.com", fullName: "Ковалев Е."},
            {id: 44, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "victoria77@hotmail.com", fullName: "Захаров В."},
            {id: 45, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "stanton.reta@hotmail.com", fullName: "Иванов А."},
            {id: 46, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "heidenreich.scottie@stroman.com", fullName: "Кудрявцев А."},
            {id: 47, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "trinity.cole@yahoo.com", fullName: "Воронков А."},
            {id: 48, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "zcollins@wilkinson.com", fullName: "Кузнецов М."},
            {id: 49, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "rberge@wehner.net", fullName: "Старостин А."},
            {id: 50, dob: this.randomDate(), phone: this.randomPhone(), rank: draw(ranks), group: draw(groups), email: "unienow@yahoo.com", fullName: "Кузнецов Д."},
        ]

        return {ranks, trainers, groups, students};
    }

    randomDate(from: Date = new Date(1947, 9, 22), to: Date = new Date(2008,9,22)) {
        return new Date(from.getTime() + Math.random() * (to.getTime() - from.getTime()));
    }

    randomPhone() {
        return `+7-949-${random(100,999)}-${random(10,99)}-${random(10,99)}`;
    }
}
