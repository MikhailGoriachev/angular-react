import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { Group, Rank, Student } from "../../services/backend.service";
import { FormBuilder, Validators } from "@angular/forms";
import { SportClubService } from "../services/sport-club.service";
import { forkJoin,  Observable, of, switchMap } from "rxjs";
import { UntilDestroy, untilDestroyed } from "@ngneat/until-destroy";
import { capitalize } from "radash";
import { formatInputDate } from "../../shared/helpers";

@UntilDestroy()
@Component({
    selector: 'app-student-form',
    templateUrl: './student-form.component.html'
})
export class StudentFormComponent implements OnInit, OnChanges {
    @Input() student?: Student;

    @Output() onSubmit = new EventEmitter<Student>();

    form = this.fb.group({
        id: this.fb.control<number | null>(null),
        fullName: this.fb.control<string>("",
            [Validators.required, Validators.pattern(new RegExp(/^[а-яё]+ ([а-яё]+|[а-яё]\.)$/i))]),
        dob: this.fb.control<string>("", [Validators.required]),
        phone: this.fb.control<string>("",[Validators.required]),
        email: this.fb.control<string>("",[Validators.required, Validators.email]),
        rank: this.fb.control<number>(1),
        group: this.fb.control<number>(1)
    });

    ranks$!: Observable<Rank[]>;
    groups$!: Observable<Group[]>;

    constructor(private fb: FormBuilder,
                private sportClub: SportClubService) {
        this.form.patchValue({ dob: formatInputDate(new Date()) });
    }

    ngOnInit(): void {
        this.ranks$ = this.sportClub.getRanks();
        this.groups$ = this.sportClub.getGroups();
    }

    submit() {
        of({ rank: this.form.value.rank!, group: this.form.value.group! })
            .pipe(
                untilDestroyed(this),
                switchMap(values =>
                    forkJoin([this.sportClub.getRankById(values.rank), this.sportClub.getGroupById(values.group)])),
            ).subscribe(x => {
            this.onSubmit.emit({
                id: this.form.value.id!,
                fullName: this.processName(this.form.value.fullName!),
                phone: this.form.value.phone!,
                email: this.form.value.email!,
                dob: new Date(this.form.value.dob!),
                rank: x[0],
                group: x[1]
            })
        });
    }

    ngOnChanges(): void {
        this.form.patchValue({
            rank: this.student?.rank.id,
            group: this.student?.group.id,
            id: this.student?.id,
            dob: formatInputDate(this.student?.dob!),
            email: this.student?.email,
            phone: this.student?.phone,
            fullName: this.student?.fullName!
        });
    }

    processName(value: string) {
        let processed = value.split(' ');

        processed[0] = capitalize(processed[0]);
        processed[1] = capitalize(processed[1]);

        if(!/^[А-Я]\.$/.test(processed[1]))
            processed[1] = `${processed[1][0]}.`;

        return processed.join(' ');
    }
}
