import { formatDate } from "@angular/common";
import * as moment from "moment/moment";

export function formatInputDate(date: Date) {
    return formatDate(date, "yyyy-MM-dd", "en");
}

export function getAge(date: Date){
    return parseInt(moment.duration({years: moment(Date.now()).diff(date, "years", false)})
        .humanize());
}