import { AbstractControl, AsyncValidatorFn, ValidationErrors, ValidatorFn } from "@angular/forms";
import { of } from "rxjs";

// Валидатор проверки "значение > value"
export function greaterThanValidator(value: number): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
        return isEmptyInputValue(control.value) || control.value > value
            ? null
            : { greaterThan: { value, message: `Параметр должен быть более ${value}.` } };
    }
}

// Валидатор проверки диапазона "нижняя граница <= верхней"
export function rangeValidator(fromName: string, toName: string): AsyncValidatorFn {
    return (form: AbstractControl) => {
        const from = form.value[fromName];
        const to = form.value[toName];

        if (isEmptyInputValue(from) || isEmptyInputValue(to)) {
            return of(null);
        }

        return of(from <= to
            ? null
            : {invalidRange: {from, to, message: `Неверный диапазон`}} as ValidationErrors);
    }
}

 // версия с промисом
/*export function rangeValidator(fromName: string, toName: string) {
    return (form: AbstractControl) => {
        return new Promise(resolve => {
            let from = form.value[fromName];
            let to = form.value[toName];

            if (isEmptyInputValue(from) || isEmptyInputValue(to)) {
                resolve(null);
            }

            from <= to
                ? resolve(null)
                : resolve({ invalidRange: { from, to, message: `Неверный диапазон` } } )
        });
    }
}*/


export function isEmptyInputValue(value: any): boolean {
    return value == null ||
        ((typeof value === 'string' || Array.isArray(value)) && value.length === 0);
}
