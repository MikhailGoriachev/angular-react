import {Component, OnInit, TemplateRef, ViewChild} from '@angular/core';
import {HttpClientBookService} from "../../services/http-client-book.service";
import {Book} from "../../services/http-client-book.service";
import {sortBy} from "../../../../util/array";
import {IconNamesEnum} from "ngx-bootstrap-icons";
import {Observable, Subscription} from "rxjs";
import {min} from "radash";
import {BsModalRef, BsModalService} from "ngx-bootstrap/modal";
import {BsDropdownConfig} from "ngx-bootstrap/dropdown";
import {AutoUnsubscribe} from "ngx-auto-unsubscribe-decorator";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {minValidator, rangeValidator, requiredValidator} from "../../../shared/validators";

type BookFormType = BooksComponent["bookForm"];
type SelectTitlePriceForm = BooksComponent["selectTitlePriceForm"];
type SelectPriceRangeForm = BooksComponent["selectPriceRangeForm"];


@Component({
    selector: 'app-books',
    templateUrl: './books.component.html',
    providers: [{ provide: BsDropdownConfig, useValue: { isAnimated: true, autoClose: true } }]
})
export class BooksComponent implements OnInit {
    iconNames = IconNamesEnum;

    @ViewChild("modal")
    modalElement!: TemplateRef<any>;        // ссылка на элемент модального окна в разметке 
    modalRef!: BsModalRef;                  // ссылка на объект модального окна для управления
    modalContent!: TemplateRef<any> | null; // ссылка на текущий контент модального окна
    modalTitle: string = "";

    // Ссылка на подписку
    @AutoUnsubscribe() // https://www.npmjs.com/package/ngx-auto-unsubscribe-decorator
    booksSubscription!: Subscription;

    // Коллекция данных
    books!: Book[];

    // Ссылка на метод подтверждения формы
    onSubmitBook = (_: FormGroup) => {};

    // Наблюдаемая коллекция списка авторов
    authors$!: Observable<string[]>;

    // настройка колонок
    columns = [
        { name: 'Id', sortProp: (b: Book) => b.id },
        { name: 'Название', sortProp: (b: Book) => b.title },
        { name: 'Автор', sortProp: (b: Book) => b.author },
        { name: 'Год издания', sortProp: (b: Book) => b.year },
        { name: 'Цена, ₽', sortProp: (b: Book) => b.price },
    ];
    isOrderDescend: boolean = false;   // текущий порядок сортировки в таблице   
    lastSorted: string = "Id";         // последний сортированный столбец

    // Форма для фильтра
    selectTitlePriceForm  = this.fb.group({
        title: ["", Validators.required,],
        priceMax: [null, [Validators.required, Validators.min(0)]]
    });

    // Форма для фильтра
    selectPriceRangeForm= this.fb.group({
        priceFrom: [null, [Validators.required, Validators.min(0)]],
        priceTo: [null, [Validators.required, Validators.min(0)]]
    }, {validators: [rangeValidator("priceFrom", "priceTo")]});

    // Форма ввода данных книги
    bookForm = this.fb.group({
        id: [0],
        title: ["", [Validators.required]],
        author: ["", [Validators.required]],
        year: [0, [Validators.required, Validators.min(0)]],
        price: [0, [Validators.required, Validators.min(0)]]
    });

    constructor(private bookClient: HttpClientBookService,
                private fb: FormBuilder,
                private modalService: BsModalService) {
    }

    ngOnInit(): void {
        this.getSourceData();
        this.authors$ = this.bookClient.getAuthors();
    }

    // Отобразить модальное окно с указанным контентом
    showModal(content: TemplateRef<any>, title: string = "Фильтр") {
        this.modalContent = content;
        this.modalTitle = title;
        this.modalRef = this.modalService.show(this.modalElement!, { class: 'modal-dialog-centered' });
    }

    // сортировка таблицы
    onOrderChanged(name: string, property: (b: Book) => number | string) {
        if (name == this.lastSorted)
            this.isOrderDescend = !this.isOrderDescend;

        this.lastSorted = name;
        sortBy(this.books, property, this.isOrderDescend);
    }

    // Загрузить исходные данные
    getSourceData() {
        this.resetData();
        this.booksSubscription = this.bookClient.getBooks()
            .subscribe(res => this.books = res);
    }

    // Инициация добавления данных
    initAddBook(modalContent: TemplateRef<any>) {
        this.bookForm.reset();
        this.onSubmitBook = this.addBook;
        this.showModal(modalContent, "Добавить информацию о книге");
    }

    // Добавление данных
    addBook(form: BookFormType) {
        this.booksSubscription = this.bookClient.addBook(form.value as Book)
            .subscribe(_ => {
                this.getSourceData();
                this.modalRef.hide();
            });
    }

    // Инициация редактирования данных
    initEdit(id: number, modalContent: TemplateRef<any>) {
        this.onSubmitBook = this.editBook;

        this.booksSubscription = this.bookClient.getBookById(id)
            .subscribe(res => this.bookForm.patchValue(res))

        this.showModal(modalContent, "Редактировать информацию о книге");
    }

    // Редактирование данных
    editBook(form: BookFormType) {
        this.booksSubscription = this.bookClient.editBook(form.value as Book)
            .subscribe(_ => {
                this.getSourceData();
                this.modalRef.hide();
            });
    }

    // Удаление данных
    deleteBook(id: number) {
        this.booksSubscription =  this.bookClient.deleteBook(id)
            .subscribe(_ => this.getSourceData());
    }

    // Отбор по автору
    selectByAuthor(value: string) {
        this.proceedSelection(() => this.bookClient.getBooksByAuthor(value)
            .subscribe(res => this.books = res));
    }

    // Отбор по названию и цене "до"
    selectByTitlePrice(form: SelectTitlePriceForm) {
        this.proceedSelection(() => this.bookClient.getBooksByTitle(form.value.title!)
            .subscribe(res => this.books = res.filter(v => v.price <= form.value.priceMax!)));
    }

    // Отбор по диапазону цены
    selectByPriceRange(form: SelectPriceRangeForm) {
        this.proceedSelection(() => this.bookClient.getBooks()
            .subscribe(res => this.books = res.filter(v => v.price <= form.value.priceTo! && v.price >= form.value.priceFrom!)));
    }

    // Самые недорогие книги
    selectCheapestBooks() {
        this.proceedSelection(() => this.bookClient.getBooks()
            .subscribe(res => {
                const minPrice = min(res.map(v => v.price));
                return this.books = res.filter(v => v.price == minPrice);
            }));
    }

    // Самые старые книги
    selectOldestBooks() {
        this.proceedSelection(() => this.bookClient.getBooks()
            .subscribe(res => {
                const oldestYear = min(res.map(v => v.year));
                return this.books = res.filter(v => v.year == oldestYear);
            }));
    }

    // Последовательность действий при выборке
    proceedSelection(callback: () => Subscription) {
        this.resetData();

        this.booksSubscription = callback();

        this.modalRef!.hide();
    }

    // Отписаться и сбросить настройки сортировки
    resetData() {
        this.isOrderDescend = false;
        this.lastSorted = "Id";
        this.booksSubscription?.unsubscribe();
    }
}

