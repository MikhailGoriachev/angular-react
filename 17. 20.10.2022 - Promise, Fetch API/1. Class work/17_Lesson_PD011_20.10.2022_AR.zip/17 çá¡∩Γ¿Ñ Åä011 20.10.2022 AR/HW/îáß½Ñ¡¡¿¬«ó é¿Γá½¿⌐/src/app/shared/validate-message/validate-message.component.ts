import {Component, Input, OnInit} from '@angular/core';
import {AbstractControl} from "@angular/forms";

@Component({
  selector: 'app-validate-message[control]',
  templateUrl: './validate-message.component.html'
})
export class ValidateMessageComponent implements OnInit {
  @Input() control!: AbstractControl<any, any> | null;

  constructor() { }

  ngOnInit(): void {
  }

}
