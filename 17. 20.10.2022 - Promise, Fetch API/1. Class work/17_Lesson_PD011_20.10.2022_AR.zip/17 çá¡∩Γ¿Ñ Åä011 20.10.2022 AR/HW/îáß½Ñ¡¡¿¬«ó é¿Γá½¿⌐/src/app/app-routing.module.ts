import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from "./home/home.component";
import { BooksComponent } from "./task2/components/books/books.component";
import {ExpressionsComponent} from "./task1/expressions/expressions.component";

export const routes: Routes = [
    { path: '', component: HomeComponent, title: 'Главная', data: { title: 'Главная' } },
    { path: 'expressions', component: ExpressionsComponent, title: 'Выражения', data: { title: 'Выражения' } },
    { path: 'books', component: BooksComponent, title: 'Книги', data: { title: 'Книги' } },
    { path: '**', redirectTo: '/' },];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule {

}
