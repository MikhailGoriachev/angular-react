import { Injectable } from '@angular/core';
import { InMemoryDbService } from "angular-in-memory-web-api";
import {random, unique } from "radash";
import {Book} from "../task2/services/http-client-book.service";

@Injectable({
  providedIn: 'root'
})
export class BackendService implements InMemoryDbService{

  constructor() { }

  createDb() {
    const books: Book[] = [
        {id: 1,  title: "451° по Фаренгейту",             author: "Брэдбери Рэй",       year: 1953, price: random(4,20) * 100},
        {id: 2,  title: "Изучаем Java",                   author: "Бейтс Берт",         year: 2019, price: random(4,20) * 100},
        {id: 3,  title: "Программирование на JavaScript", author: "Васильев А.Н.",      year: 2019, price: random(4,20) * 100},
        {id: 4,  title: "1С: Предприятие. Практическое пособие разработчика",  author: "Радченко Н.А.", year: 2012,price: random(4,20) * 100},
        {id: 5,  title: "Путь программиста", 		      author: "Сонмез Джон",        year: 2016, price: random(4,20) * 100},
        {id: 6,  title: "Путь самурая (Хагакурэ)", 	      author: "Цунэтомо Ямамото",   year: 2019, price: random(4,20) * 100},
        {id: 7,  title: "Совершенный код", 			      author: "Макконнелл Стив",    year: 1993, price: random(4,20) * 100},
        {id: 8,  title: "Искусство программирования",     author: "Кнут Эрвин",         year: 1968, price: random(4,20) * 100},
        {id: 9,  title: "Refactoring", 				      author: "Бек Кент",           year: 1999, price: random(4,20) * 100},
        {id: 10, title: "Философия Java", 			      author: "Эккель Брюс",        year: 1998, price: random(4,20) * 100},
        {id: 11, title: "Собачье счастье", 			      author: "Фролова Анна",       year: 2021, price: random(4,20) * 100},
        {id: 12, title: "JavaScript с нуля", 		      author: "Чиннатхамби Кирупа", year: 2021, price: random(4,20) * 100},
        {id: 13, title: "Design Patterns", 			      author: "Гамма Эрих",         year: 1994, price: random(4,20) * 100},
        {id: 14, title: "Паттерны проектирования", 	      author: "Фриман Эрик",        year: 2004, price: random(4,20) * 100}
    ];

    const authors = unique(books.map(b => b.author)).sort();

    return {
      books,
      authors
    };
  }
}
