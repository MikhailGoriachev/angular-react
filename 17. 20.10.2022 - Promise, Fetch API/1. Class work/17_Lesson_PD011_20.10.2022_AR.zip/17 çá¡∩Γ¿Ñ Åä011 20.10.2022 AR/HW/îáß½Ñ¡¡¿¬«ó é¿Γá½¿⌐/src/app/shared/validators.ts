import {AbstractControl, ValidationErrors, ValidatorFn} from "@angular/forms";

// Валидатор проверки "значение > x"
export function greaterThanValidator(value: number): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
        return isEmptyInputValue(control.value) || control.value > value
            ? null
            : {greaterThan: {value, message: `Параметр должен быть более ${value}.`}};
    }
}

// Валидатор проверки диапазона "нижняя граница <= верхней"
export function rangeValidator(fromName: string, toName: string): ValidatorFn {
    return (form: AbstractControl): ValidationErrors | null => {
        const from = form.value[fromName];
        const to = form.value[toName];

        if (isEmptyInputValue(from) || isEmptyInputValue(to)) {
            return null;
        }

        return  from <= to
            ? null
            : {invalidRange: {from, to, message: `Неверный диапазон`}};
    }
}


// Репродукция исходников стандартного requiredValidator c добавленным сообщения в результате
export function requiredValidator(control: AbstractControl): ValidationErrors | null {
    return isEmptyInputValue(control.value) ? {required: {message: "Обязательное поле."}} : null;
}

// Репродукция исходников стандартного minValidator c добавленным сообщением в результате
export function minValidator(min: number): ValidatorFn {
    return (control: AbstractControl): ValidationErrors|null => {
        if (isEmptyInputValue(control.value) || isEmptyInputValue(min)) {
            return null;
        }
        const value = parseFloat(control.value);

        return !isNaN(value) && value < min
            ? {'min': {'min': min, 'actual': control.value, message: `Значение не может быть меньше ${min}`}}
            : null;
    };
}

function isEmptyInputValue(value: any): boolean {
    return value == null ||
        ((typeof value === 'string' || Array.isArray(value)) && value.length === 0);
}
