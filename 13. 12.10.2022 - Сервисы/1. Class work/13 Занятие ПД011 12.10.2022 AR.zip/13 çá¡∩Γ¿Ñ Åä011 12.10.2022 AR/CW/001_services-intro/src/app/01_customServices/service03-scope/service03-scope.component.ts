import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service03-scope',
  templateUrl: './service03-scope.component.html',
  styleUrls: ['./service03-scope.component.css']
})
export class Service03ScopeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
