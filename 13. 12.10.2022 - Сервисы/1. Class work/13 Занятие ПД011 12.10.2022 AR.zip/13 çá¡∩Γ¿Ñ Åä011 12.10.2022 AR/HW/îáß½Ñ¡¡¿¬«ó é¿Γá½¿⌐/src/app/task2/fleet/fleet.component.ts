import { Component, OnInit } from '@angular/core';
import { Fleet } from "../../../models/fleet";
import { Ship } from "../../../models/ship";

@Component({
  selector: 'app-fleet',
  templateUrl: './fleet.component.html'
})
export class FleetComponent implements OnInit {
  private readonly storageKey: string = "mv_ships";
  
  fleet: Fleet = new Fleet()
  
  displayShips: Ship[];
  
  constructor() { 
    if(!this.fleet.load(this.storageKey))
      this.fleet.init().store(this.storageKey);
    
    this.displayShips = this.fleet.ships;
  }

  ngOnInit(): void {
  }

  addShip() {
    this.fleet.add(Fleet.randomShip());
    this.fleet.store(this.storageKey);
  }

  removeShip(id: number) {
    this.fleet.remove(id);
    this.fleet.store(this.storageKey);
  }
}
