import { Component, OnInit, ViewChild } from '@angular/core';
import { C3Component } from "../c3/c3.component";
import { getRandomInt } from "../../../util/randoms";

@Component({
    selector: 'app-c1',
    templateUrl: './c1.component.html'
})
export class C1Component implements OnInit {
    private readonly min: number = 1;
    private readonly max: number = 10;

    @ViewChild('C3') c3comp: C3Component = new C3Component();

    constructor() {  }

    ngOnInit(): void {  }

    calc() {
        this.c3comp.runCalculate(getRandomInt(this.min, this.max), getRandomInt(this.min, this.max));
    }
}
