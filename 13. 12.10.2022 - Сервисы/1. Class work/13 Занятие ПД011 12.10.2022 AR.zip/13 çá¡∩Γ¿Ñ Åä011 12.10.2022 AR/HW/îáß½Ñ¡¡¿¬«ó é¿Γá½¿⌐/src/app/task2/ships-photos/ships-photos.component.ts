import { Component, OnInit } from '@angular/core';
import { Fleet } from "../../../models/fleet";

@Component({
    selector: 'app-ships-photos',
    templateUrl: './ships-photos.component.html',
    styles: [` .text-shadow { text-shadow: 2px 2px #000 } `]
})
export class ShipsPhotosComponent implements OnInit {
    private readonly storageKey: string = "mv_ships";

    fleet: Fleet = new Fleet()

    constructor() {
        if (!this.fleet.load(this.storageKey))
            this.fleet.init().store(this.storageKey);
    }

    ngOnInit(): void {
    }
}
