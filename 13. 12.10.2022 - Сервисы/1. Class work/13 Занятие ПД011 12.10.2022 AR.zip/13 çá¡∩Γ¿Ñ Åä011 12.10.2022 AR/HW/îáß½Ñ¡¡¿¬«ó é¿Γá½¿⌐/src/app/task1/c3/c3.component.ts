import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { C2Component } from "../c2/c2.component";

@Component({
    selector: 'app-c3',
    templateUrl: './c3.component.html'
})
export class C3Component implements OnInit {

    // результаты вычислений
    z1: number | undefined;
    z2: number | undefined;

    // признак успешного вычисления
    success = false;

    constructor() {  }
    
    ngOnInit(): void {  }

    @ViewChild('C2') c2comp!: C2Component;

    runCalculate(a:number, b: number) {
        this.c2comp.a = a;
        this.c2comp.b = b;
        this.c2comp.calculate();
    }

    calculateEventHandler($event: [number, number]) {
        [this.z1, this.z2] = $event;
        this.success = Math.abs(this.z1 - this.z2) < 1e-10;
    }
}
