import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-c2',
  templateUrl: './c2.component.html'
})
export class C2Component implements OnInit {
  // исходные данные для вычислений
  @Input() a: number = 0;
  @Input() b: number = 0;

  constructor() { }
  ngOnInit(): void {  }

  // событие, зажигаемое после вычисления по заданию
  @Output() onCalculated: EventEmitter<[number, number]> = new EventEmitter();

  // вычисление по заданию
  calculate(): void {
    const tmp1 = 2 * this.b
    const tmp2 = tmp1 - this.a;
    
    const z1: number = (Math.sin(this.a) + Math.cos(tmp2)) / (Math.cos(this.a) - Math.sin(tmp2));
    const z2: number = (1 + Math.sin(tmp1)) / Math.cos(tmp1);

    this.onCalculated.emit([z1, z2]);
  }
}
