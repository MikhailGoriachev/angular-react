import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FleetComponent } from './fleet/fleet.component';
import { ShipsTableComponent } from './ships-table/ships-table.component';
import { NgxBootstrapIconsModule } from "ngx-bootstrap-icons";
import { ShipsPhotosComponent } from './ships-photos/ships-photos.component';
import { CarouselModule } from "ngx-bootstrap/carousel";



@NgModule({
  declarations: [
    FleetComponent,
    ShipsTableComponent,
    ShipsPhotosComponent
  ],
    imports: [
        CommonModule,
        NgxBootstrapIconsModule,
        CarouselModule
    ]
})
export class Task2Module { }
