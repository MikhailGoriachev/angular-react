﻿// Коллекция кораблей
import { Ship } from "./ship";
import { getRandomInt } from "../util/randoms";
import { draw, max } from "radash";

export class Fleet {
    
    constructor(public ships: Ship[] = []) {
    }
        
    init(ships: Ship[] = [...Fleet.sourceData]): Fleet {
        this.ships = ships;
        return this;
    }
    
    add(ship: Ship) {
        ship.id = this.ships?.length ? max(this.ships.map(v => v.id)) + 1 : 1;
        this.ships.unshift(ship);
    }
    
    remove(id: number) {
        let index = this.ships.findIndex(s => s.id == id);
        if (index > -1)
            this.ships.splice(index, 1);
    }
    
    // Сохранить в локальное хранилище
    store(key: string) {
        localStorage.setItem(key, JSON.stringify(this.ships));
    }

    // Загрузить из локального хранилища
    load(key: string): boolean {
        const load = localStorage.getItem(key);

        if(!load) return false;

        this.ships = (JSON.parse(load) as Ship[]).map((s) => new Ship().assign(s));
        
        return true;
    }
    
    static randomShip(): Ship {
        return draw(Fleet.sourceData);
    }
    
    static readonly sourceData: Ship[] =  [
        new Ship(1,"Адмирал Трибуц", "большой противолодочный корабль", 163, 19, 7408, 1983, "tributz.jpg"),
        new Ship(2,"Бурный ", "эскадренный миноносец", 156.5, 17.2, 7904, 1986, "burniy.jpg"),
        new Ship(3,"Быстрый ", "эскадренный миноносец", 156.5, 17.2, 7904, 1987, "bystryy.jpg"),
        new Ship(4,"Адмирал Нахимов", "ракетный крейсер", 230, 250.1, 23750, 1986, "admnahim.jpg"),
        new Ship(5,"Варяг ", "ракетный крейсер", 186.4, 20.8, 11490, 1983, "varyag.jpg"),
        new Ship(6,"Адмирал Виноградов", "фрегат", 163, 19, 7408, 1987, "vinogradov.jpg"),
        new Ship(7,"Маршал Шапошников", "фрегат", 163, 19, 7408, 1984, "shaposhnikov.jpg"),
        new Ship(8,"Громкий ", "корвет", 104.5, 13, 2250, 2018, "gromkiy.jpg"),
        new Ship(9,"Гремящий ", "корвет", 106.3, 13, 2430, 2017, "gremyashchy.jpg"),
        new Ship(10,"Кореец", "малый противолодочный корабль", 71.12, 10.15, 1220, 1987, "koreetz.jpg"),
        new Ship(11,"Пересвет", "большой десантный корабль", 112.5, 15, 4080, 1991, "peresvet.jpg"),
        new Ship(12,"Иван Карцов", "десантный катер", 45, 8.6, 280, 2013, "kravtzov.jpg"),
        new Ship(13,"Вице-адмирал Захарьин", "морской тральщик", 61, 10.2, 852, 2006, "zaharyin.jpeg"),
    ]
}