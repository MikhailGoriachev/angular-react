﻿// Данные о корабле
export class Ship {
    constructor(public id: number = 0,
                public name: string = "",
                public type: string = "",
                public length: number = 0,
                public width: number = 0,
                public displacement: number = 0,
                public year: number = 0,
                public image: string = "") {
    }


    assign(m: Ship) {
        Object.assign(this, m);
        return this;
    }
}