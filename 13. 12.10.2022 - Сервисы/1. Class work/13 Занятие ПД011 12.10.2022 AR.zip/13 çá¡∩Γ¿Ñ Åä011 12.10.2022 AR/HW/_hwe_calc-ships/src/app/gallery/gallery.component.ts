import { Component, OnInit } from '@angular/core';
import {Fleet} from "../../models/fleet";

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html'
})
export class GalleryComponent implements OnInit {

  // коллекция названий файлов с изображениями кораблей
  photos: string[];

  constructor() {
    this.photos = (Fleet.exists() // данные есть в локальном хранилище?
      ?Fleet.loadFromLocalStore() // да - читаем
      :Fleet.getShips())          // нет - формируем
      .map(s => s.photo);         // получить массив имен файлов
  }

  ngOnInit(): void { }
  flag = 0;
  firstActive(): number{
    return this.flag++;
  }
}
