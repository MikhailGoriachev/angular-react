﻿import {IComparable} from "../task1/iComparable";
import {genLimits, getRandomInt, names} from "./utils";

export class Person implements IComparable<Person> {

    constructor(public fullName: string, public age: number, public salary: number) {
    }

    // Компаратор для сортировки
    compareTo(other: Person): number {
        return this.age - other.age;
    }

    // Правила работы с объектом как с примитивами (для сравнения и представления как строки)
    [Symbol.toPrimitive](hint: string | number) {
        if (hint === 'number') {
            return this.salary;
        }
        if (hint === 'string') {
            return `Фамилия И.О.: ${this.fullName}, возраст: ${this.age}, оклад: ${this.salary}\n`;
        }
        return true;
    }

    // Сгенерировать объект
    static random(): Person {
        return new Person(names[getRandomInt(0, names.length - 1)],
            getRandomInt(genLimits.ageMin, genLimits.ageMax),
            getRandomInt(genLimits.salaryMin, genLimits.salaryMax));
    }
}