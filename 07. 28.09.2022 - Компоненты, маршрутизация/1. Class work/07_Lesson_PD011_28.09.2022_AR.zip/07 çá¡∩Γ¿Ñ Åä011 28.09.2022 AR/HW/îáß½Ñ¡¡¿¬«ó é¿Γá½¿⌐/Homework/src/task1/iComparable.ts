﻿
export interface IComparable<T> {
    compareTo: (arg: T) => number;
}