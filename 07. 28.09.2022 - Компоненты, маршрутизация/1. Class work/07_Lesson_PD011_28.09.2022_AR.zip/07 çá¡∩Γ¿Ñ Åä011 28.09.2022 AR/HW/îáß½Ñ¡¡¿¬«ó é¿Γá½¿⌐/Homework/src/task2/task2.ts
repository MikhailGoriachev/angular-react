﻿import {genLimits, getRandomInt} from "../common/utils";
import {Depot} from "./depot";
import {Bus} from "./bus";
import {Person} from "../common/person";

export function initTask2() {
    // Данные для инициализации
    const buses: Bus[] = [
        new Bus("О140ТВ", new Person("Филатов А. Д.", getRandomInt (genLimits.ageMin, genLimits.ageMax), getRandomInt(genLimits.salaryMin, genLimits.salaryMax)), "42"),
        new Bus("Р261ОХ", new Person("Быков М. Р.", getRandomInt (genLimits.ageMin, genLimits.ageMax), getRandomInt(genLimits.salaryMin, genLimits.salaryMax)), "42a"),
        new Bus("Х821НО", new Person("Денисов Д. М.", getRandomInt (genLimits.ageMin, genLimits.ageMax), getRandomInt(genLimits.salaryMin, genLimits.salaryMax)), "37"),
        new Bus("Р697АЕ", new Person("Волков А. А.", getRandomInt (genLimits.ageMin, genLimits.ageMax), getRandomInt(genLimits.salaryMin, genLimits.salaryMax)), "73"),
        new Bus("М825СН", new Person("Лукьянов Д. Б.", getRandomInt (genLimits.ageMin, genLimits.ageMax), getRandomInt(genLimits.salaryMin, genLimits.salaryMax)), "41"),
        new Bus("О085КЕ", new Person("Одинцов М. Т.", getRandomInt (genLimits.ageMin, genLimits.ageMax), getRandomInt(genLimits.salaryMin, genLimits.salaryMax)), "10"),
        new Bus("Т341АУ", new Person("Коновалов А. М.", getRandomInt (genLimits.ageMin, genLimits.ageMax), getRandomInt(genLimits.salaryMin, genLimits.salaryMax)), "35"),
        new Bus("Е432ОО", new Person("Смирнов А. Ф.", getRandomInt (genLimits.ageMin, genLimits.ageMax), getRandomInt(genLimits.salaryMin, genLimits.salaryMax)), "73б"),
        new Bus("Т906КА", new Person("Алексеев Г. М.", getRandomInt (genLimits.ageMin, genLimits.ageMax), getRandomInt(genLimits.salaryMin, genLimits.salaryMax)), "17"),
        new Bus("В029АК", new Person("Зимин Я. А.", getRandomInt (genLimits.ageMin, genLimits.ageMax), getRandomInt(genLimits.salaryMin, genLimits.salaryMax)), "37"),
        new Bus("Н283ОР", new Person("Комаров И. М.", getRandomInt (genLimits.ageMin, genLimits.ageMax), getRandomInt(genLimits.salaryMin, genLimits.salaryMax)), "54"),
        new Bus("С874АМ", new Person("Маслов Г. И.", getRandomInt (genLimits.ageMin, genLimits.ageMax), getRandomInt(genLimits.salaryMin, genLimits.salaryMax)), "25"),
        new Bus("М711АЕ", new Person("Сурков Д. С.", getRandomInt (genLimits.ageMin, genLimits.ageMax), getRandomInt(genLimits.salaryMin, genLimits.salaryMax)), "77"),
        new Bus("О180ВТ", new Person("Федоров А. Б.", getRandomInt (genLimits.ageMin, genLimits.ageMax), getRandomInt(genLimits.salaryMin, genLimits.salaryMax)), "76"),
        new Bus("Т306ЕУ", new Person("Сергеев М. Д.", getRandomInt (genLimits.ageMin, genLimits.ageMax), getRandomInt(genLimits.salaryMin, genLimits.salaryMax)), "84"),
    ];    
    
    let busDepot = new Depot(),
        $selBus = $("#selBus");
    
    busDepot.init([...buses]);
    
    // Рендеринг данных об автобусах в html таблицы
    const renderTables = () => {
        $("#tab-parked").empty().append(busDepot.parkedToHtml());
        $("#tab-routed").empty().append(busDepot.routedToHtml());
    };
    
    // Заполнение select-списка номерами автобусов, находящихся в депо
    const selectListParked = () => {
        $selBus.empty();
        busDepot.parkBuses.forEach(v => $selBus.append($("<option>").val(v.regNum).text(v.regNum)));
    };

    // Заполнение select-списка номерами автобусов, находящихся на маршруте
    const selectListRouted = () => {
        $selBus.empty();
        busDepot.routeBuses.forEach(v => $selBus.append($("<option>").val(v.regNum).text(v.regNum)));
    };
    
    // Кнопка инициализации
    $("#btnInit").on("click", () => {
        busDepot.init([...buses]);
        renderTables();
        $("#btnTabParked").trigger("click");
    })
    
    // Кнопка упорядочить по номеру автобуса
    $("#btnOrderBusNum").on("click", () => {
        $("#tab-parked").empty().append(busDepot.parkedToHtml(Depot.orderBusRegNum));
        $("#tab-routed").empty().append(busDepot.routedToHtml(Depot.orderBusRegNum));
    })

    // Кнопка упорядочить по номеру маршрута
    $("#btnOrderRouteNum").on("click", () => {
        $("#tab-parked").empty().append(busDepot.parkedToHtml(Depot.orderRouteNum));
        $("#tab-routed").empty().append(busDepot.routedToHtml(Depot.orderRouteNum));
    })
    
    // Кнопка отправить автобус на маршрут
    $("#btnDepartureBus").on("click", () => {
        debugger
        busDepot.departureBus($selBus.val() as string);
        
        renderTables();
        selectListParked();
        
        if(!busDepot.parkBuses.length)
            $("#btnDepartureBus").addClass("disabled");
    })

    // Кнопка отправить автобус в депо
    $("#btnParkBus").on("click", () => {
        busDepot.parkBus($selBus.val() as string);
        
        renderTables();
        selectListRouted();

        if(!busDepot.parkBuses.length)
            $("#btnParkBus").addClass("disabled");
    })

    // Кнопка перехода на таблице с автобусами в депо
    $("#btnTabParked").on("click", () => {
        $("#btnDepartureBus").removeClass("disabled")
            .addClass(!busDepot.parkBuses.length ? "disabled" : "");
        $("#btnParkBus").addClass("disabled");
        
        selectListParked();
    });

    // Кнопка перехода на таблице с автобусами на маршруте
    $("#btnTabRouted").on("click", () => {
        $("#btnParkBus").removeClass("disabled")
            .addClass(!busDepot.routeBuses.length ? "disabled" : "");
        $("#btnDepartureBus").addClass("disabled");
        selectListRouted();
    });

    
    renderTables();
    selectListParked();
}
