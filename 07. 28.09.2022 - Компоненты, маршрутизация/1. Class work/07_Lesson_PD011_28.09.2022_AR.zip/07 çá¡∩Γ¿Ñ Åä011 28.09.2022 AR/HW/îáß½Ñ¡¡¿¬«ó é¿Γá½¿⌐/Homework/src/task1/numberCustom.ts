﻿import {IComparable} from "./iComparable";
import {getRandomInt} from "../common/utils";


export class NumberCustom extends Number implements IComparable<NumberCustom> {
   
    compareTo<T extends Number | number>(other: T): number {
        return this.valueOf() - other.valueOf();
    }

    static random(min: number = -20, max: number = 20): NumberCustom {
        return new NumberCustom(getRandomInt(min, max));
    }
}