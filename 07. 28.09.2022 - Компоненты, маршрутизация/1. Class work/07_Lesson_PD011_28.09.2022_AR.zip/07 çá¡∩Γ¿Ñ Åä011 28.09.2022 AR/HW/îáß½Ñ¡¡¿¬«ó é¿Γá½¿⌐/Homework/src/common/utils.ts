﻿
// Генерация случайного целого числа
export function getRandomInt(min: number, max: number): number {
    return Math.floor(Math.random() * (max - min + 1) + min);
}

// Параметры для генерации данных
export const genLimits = {
    ageMin: 25,
    ageMax: 55,
    salaryMin: 20_000,
    salaryMax: 50_000
}

// Имена для исходных данных
export const names = [
    "Филатов А. Д.",
    "Быков М. Р.", 
    "Денисов Д. М.",
    "Волков А. А.",
    "Лукьянов Д. Б.",
    "Одинцов М. Т.",
    "Коновалов А. М.",
    "Смирнов А. Ф.",
    "Алексеев Г. М.",
    "Зимин Я. А.",
    "Комаров И. М.",
    "Маслов Г. И.",
    "Сурков Д. С.",
    "Федоров А. Б.",
    "Сергеев М. Д.", 
];