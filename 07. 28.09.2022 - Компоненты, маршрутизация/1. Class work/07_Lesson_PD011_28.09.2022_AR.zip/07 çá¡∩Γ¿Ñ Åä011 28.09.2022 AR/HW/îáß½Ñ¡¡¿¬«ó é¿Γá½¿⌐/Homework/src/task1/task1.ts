﻿import {IComparable} from "./IComparable";
import {NumberCustom} from "./numberCustom"
import {Person} from "../common/person"
import {ArrayCustom} from "./arrayCustom"

export function initTask1() {

    // Обработчик запуска демонстрации на числовом типе
    $("#btnNumbers").on("click", () => {
        console.clear();
        let numberArray = new ArrayCustom<NumberCustom>;
        numberArray.init(10, () => NumberCustom.random());
        demo(numberArray);
    })

    // Обработчик запуска демонстрации на объектах типа Person
    $("#btnPersons").on("click", () => {
        console.clear();
        let personArray = new ArrayCustom<Person>;
        personArray.init(10, () => Person.random());
        demo(personArray);
    })
}

function demo<T extends IComparable<T>>(array: ArrayCustom<T>) {
    
    // Вывод всех элементов
    console.log("Коллекция данных:")
    array.print();

    // Количество локальных минимумов:
    console.log(`Локальных минимумов: ${array.localMinimaCount()}`);

    // Сортировка по условию
    if (array.isFrom(Person)) {
        array.sort((a,b) => b.compareTo(a));
    } else if (array.isFrom(NumberCustom)) {
        array.sort();
    }
    console.log("Массив отсортирован:")
    array.print();

    // Удаление первого элемента
    array.shift();
    console.log("Удалён первый элемент:")
    array.print();

    // Добавление эл-та в конец массива
    if (array.isFrom(Person)) {
        array.push(Person.random());
    } else if (array.isFrom(NumberCustom)) {
        array.push(NumberCustom.random());
    }
    console.log("В конец добавлен элемент:")
    array.print();
}
