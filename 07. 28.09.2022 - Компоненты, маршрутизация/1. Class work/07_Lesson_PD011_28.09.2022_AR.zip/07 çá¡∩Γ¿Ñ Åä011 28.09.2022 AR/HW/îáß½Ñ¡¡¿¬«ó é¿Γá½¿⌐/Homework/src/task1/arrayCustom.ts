﻿import {IComparable} from "./iComparable";

// обобщенный класс с ограничениями, для хранения одномерного массива
export class ArrayCustom<T extends IComparable<T>> {
    #data: T[] = [];

    // начальная инициализация массива (заполнение в методе случайными значениями)
    init(size: number, builder: () => T) {
        this.#data = [...Array<T>(size)].map(_ => builder());
    }

    
    // проверка на соответствие типа данных типу класса, переданному в аргумент 
    isFrom<TVal extends IComparable<TVal>>(ctor: new(...args: any) => TVal): this is ArrayCustom<TVal> {
        return this.#data[0] instanceof ctor;
    }

    // вывод массива в консоль
    print() {
        console.log(this.#data.reduce((acc, cur) => acc + ` ${cur}`, ""));
    }

    // определение количества локальных минимумов в массиве (элементов, меньших своих левого и правого соседа,
    // первый и последний элементы не могут быть локальными минимумами)
    localMinimaCount(): number {
        let count = 0;

        for (let i = 1; i < this.#data.length - 1; i++) {
            if (this.#data[i] < this.#data[i - 1] && this.#data[i] < this.#data[i + 1])
                count++;
        }

        return count;
    }

    // упорядочение массива 
    sort(comparer: (a: T, b: T) => number = (a, b) => a.compareTo(b)) {
        this.#data.sort(comparer);
    }

    // удаление первого элемента массива
    shift(): T | undefined {
        return this.#data.shift();
    }

    // добавление элемента в конец массива
    push(...items: T[]) {
        this.#data.push(...items);
    }

    // итератор для перебора элементов массива циклом for … of
    [Symbol.iterator]() {
        let current = 0;
        let data = this.#data;

        return {
            next() {
                return current < data.length
                    ? {done: false, value: data[current++]}
                    : {done: true, value: null};
            }
        }
    }
}