﻿import {Person} from "../common/person";

export class Bus {

    constructor(public regNum: string, public driver: Person, public route: string) {
    }

    toHtmlTableRow(row: number): JQuery{
        return $("<tr/>")
            .append($("<td/>").text(row))
            .append($("<td/>").text(this.regNum))
            .append($("<td/>").text(this.route))
            .append($("<td/>").text(this.driver.fullName));
    }
}