﻿import {Bus} from "./bus";

export class Depot {
    public parkBuses: Bus[];
    public routeBuses: Bus[];
    
    //	формирование данных обо всех автобусах в парке в виде коллекции 
    init(garageBuses: Bus[], routeBuses?: Bus[]) {
        this.parkBuses = garageBuses;
        this.routeBuses = routeBuses ?? new Array<Bus>();
    }

    //	имитация выезда автобуса из парка: задается номер автобуса; код удаляет данные об этом автобусе из коллекции
    //	автобусов, находящихся в парке, и записывает эти данные в коллекцию автобусов, находящихся на маршруте;
    departureBus(number: string) {
        let bus = this.parkBuses.find(v => v.regNum == number);
        
        if(bus) {
            this.routeBuses.push(bus);
            this.parkBuses.splice(this.parkBuses.indexOf(bus), 1);
        }
    }

    //	имитация въезда автобуса в парк: задается номер автобуса; код удаляет данные об этом автобусе из коллекции 
    //	автобусов, находящихся на маршруте, и записывает эти данные в коллекцию автобусов, находящихся в парке;
    parkBus(number: string) {
        let bus = this.routeBuses.find(v => v.regNum == number);

        if(bus) {
            this.parkBuses.push(bus);
            this.routeBuses.splice(this.routeBuses.indexOf(bus), 1);
        }
    }
    
    parkedToHtml(comparer: (a: Bus, b: Bus) => number = (a, b) => 0): JQuery {
        return this.toHtml(this.parkBuses, comparer);
    }
    
    routedToHtml(comparer: (a: Bus, b: Bus) => number = (a, b) => 0): JQuery {
        return this.toHtml(this.routeBuses, comparer);
    }

    toHtml(buses: Bus[], comparer: (a: Bus, b: Bus) => number): JQuery {
        return $(`<table class="table my-3">
            <thead>
            <tr>
                <th>№</th>
                <th>Номер автобуса</th>
                <th>Номер маршрута</th>
                <th>Водитель</th>
            </tr>
            </thead>
            </table>`)
            .append(buses.sort(comparer).reduce((acc, cur, ind) =>
                acc.append(cur.toHtmlTableRow(ind + 1)),
                $("<tbody/>").addClass("color-2")));
    }
    
    // компараторы для сортировок
    static orderBusRegNum = (a: Bus, b: Bus): number => a.regNum.localeCompare(b.regNum);
    static orderRouteNum = (a: Bus, b: Bus): number => a.route.localeCompare(b.route);
}