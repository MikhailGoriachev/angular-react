﻿import * as task1 from "./task1/task1"
import * as task2 from "./task2/task2"

$(() => {
    if ($("#task1"))
        task1.initTask1();
	else if ($("#task2"))
        task2.initTask2();
});

