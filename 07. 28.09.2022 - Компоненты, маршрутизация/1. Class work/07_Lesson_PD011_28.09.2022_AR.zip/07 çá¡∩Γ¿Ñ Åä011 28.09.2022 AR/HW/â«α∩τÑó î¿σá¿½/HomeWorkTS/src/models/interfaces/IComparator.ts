﻿// Интерфейс Компаратор
export interface IComparator<T> {
    compareTo(item: T): number
}
