﻿// состояние автобуса
export enum BusState {
    busFleet,
    busRoute
}
