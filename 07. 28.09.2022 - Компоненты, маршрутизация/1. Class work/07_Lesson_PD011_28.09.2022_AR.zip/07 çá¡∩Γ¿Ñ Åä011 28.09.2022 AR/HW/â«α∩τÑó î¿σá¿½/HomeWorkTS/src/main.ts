﻿// задание 1
import {pageInitTask01} from "./task01";

// инициализация страницы
pageInitTask01();

// задание 2
import {pageInitTask02} from "./task02";

// инициализация страницы
pageInitTask02();
