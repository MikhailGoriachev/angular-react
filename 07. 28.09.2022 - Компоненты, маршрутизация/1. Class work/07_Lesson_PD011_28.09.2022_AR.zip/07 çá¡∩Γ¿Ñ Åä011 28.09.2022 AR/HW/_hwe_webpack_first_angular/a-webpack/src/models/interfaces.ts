// интерфейс для реализации ограничения - требуем наличия
// метода compareTo(), принимающего произвольный тип и
// возвращающий числовое значение
// (имя метода указывать не обязательно)
export interface Comparable<T> {
    compareTo(other: T): number;
} // Comparable

// Интерфейс для генерации значений для типа T
export interface Generable<T> {
    generate(): void;
} // Generable
