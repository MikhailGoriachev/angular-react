// формальная точка входа в приложение - для webpack
import {$} from  "./utils"
import {task1num} from "./task1/task1num";
import {task1person} from "./task1/task1person";

// при загрузке страницы выполнить соответсвующую задачу
// страницу определяем по идентификатору поля вывода
window.addEventListener('load', () => {
    if ($("task1num")) {
        task1num();
    } else if ($("task1person")) {
        task1person();
    } // if
}, false);