import {Comparable, Generable} from "./interfaces";
import {getRand} from "../utils";

// т.к. имя класса Number конфликтует со стандартным типом Number (намеренно, да :) )
// размещаем свой класс в пространстве имен Task1
export namespace Task1 {

    // класс для хранения числа в обобщенном классе Vector
    export class Number implements Comparable<Task1.Number>, Generable<Task1.Number> {
        constructor(private _value: number = 0, private _lo: number = -10, private _hi: number = 10) {
        } // constructor

        // аксессор для значения
        get value(): number { return this._value; }
        set value(value: number) {
            this._value = value;
        }

        // реализация интерфейса Comparable<Number> для сортировки методом
        // массива sort()
        compareTo(other: Number): number {
            return this._value - other._value;
        } // compareTo

        // реализация интерфейса Generable<Number>
        generate(): void {
            this._value = getRand(this._lo, this._hi);
        } // generate

        // переопределение valueOf() для работы операций сравнения и отношения
        // при поиске локального минимума (< <= == === 1== != >= >)
        valueOf(): number { return this.value; }

        // переопределение toString() - метода Object - для удобного вывода в консоль, например
        toString(): string { return `${this._value.toFixed(3)}`;  } // toString

    } // class Number
} // namespace Task1