// функция - генератор случайных чисел, все значения по модулю меньшие 1
// заменяем нулями
export function getRand(from: number, to: number): number {
    let value: number = from + (to - from)*Math.random();
    if (Math.abs(value) < 1) {
        value = 0;
    } // if

    return value
} // getRand


// поиск элемента DOM-дерева по его идентификатору
export function $(id: string) {
    return document.getElementById(id);
} // $

// получить случайное значение из массива полных имен
export function getRandFullName(): string {
    let fullNames: string[] = [
        "Гритченко С.А.",    "Танич Ю.С.",           "Денисенко Д.И.",
        "Никитин С.А.",      "Фиалка М.Ю.",          "Колесова З.В.",
        "Кошель К.В.",       "Комиссаровский А.В.",  "Кузьменко Д.А.",
        "Ладик С.В.",        "Мелашенко А.А.",        "Чернявская А.А.",
        "Михайловский Д.Д.", "Пакун Д.М.",            "Рудукан С.А.",
        "Рядинский Э.А.",    "Садомова А.В.",         "Сотников А.В.",
        "Судовский Е.С.",    "Ролик Д.В.",            "Каскаев М.Н."
    ];

    return fullNames[Math.floor(getRand(0, fullNames.length-1))];
} // getRandFullName


