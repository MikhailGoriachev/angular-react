import {Comparable, Generable} from "./interfaces";
import {getRand, getRandFullName} from "../utils";

// Person (fullName: string, age: number, salary: number) – хранит полное
// имя, возраст, оклад.  Локальный минимум ищем по окладу, упорядочение
// по убыванию возраста

export class Person implements Comparable<Person>, Generable<Person> {
    constructor(private _fullName: string = "", private _age: number = 1, private _salary: number = 0) {}

    //<editor-fold desc="аксессоры">
    get fullName(): string { return this._fullName; }
    set fullName(value: string) {
        this._fullName = value;
    }

    get age(): number { return this._age; }
    set age(value: number) {
        this._age = value;
    }

    get salary(): number { return this._salary; }
    set salary(value: number) {
        this._salary = value;
    }
    //</editor-fold>

    // реализация интерфейса Comparable для сортировки по убыванию возраста
    compareTo(other: Person): number {
        return other._age - this._age;
    } // compareTo

    // реализация интерфейса Generable для формирования полей экземпляра
    generate(): void {
        this._fullName = getRandFullName();
        this._age = Math.floor(getRand(18, 65));
        this._salary = Math.floor(getRand(18, 65)) * 1000;
    } // generate

    // переопределение valueOf() для поиска локального минимума
    valueOf(): number { return this._salary; } // valueOf

    // переопределение toString() - метода Object - для удобного вывода в консоль, например
    toString(): string {
        return `${this._fullName}, возраст (лет): ${this._age}, оклад: ${this._salary.toFixed(2)} руб.`;
    } // toString

} // class Person