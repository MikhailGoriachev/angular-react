// Обобщенный класс (дженерик) с ограничениями, для хранения одномерного
// массива. Класс имеет следующий функционал:
//     • начальная инициализация массива (заполнение в методе случайными
//       значениями)
//     • вывод массива в консоль
//     • определение количества локальных минимумов в массиве (элементов,
//       меньших своих левого и правого соседа, первый и последний
//       элементы не могут быть локальными минимумами)
//     • упорядочение массива по возрастанию
//     • удаление первого элемента массива
//     • добавление элемента в конец массива
//     • итератор для перебора элементов массива циклом for … of
import {Comparable, Generable} from "./interfaces";

// тип T должен реализовывать интерфейсы Comparable<T>, Generable<T>
export class Vector<T extends Comparable<T> & Generable<T>> {
    // конструктор с объявлением свойства - контейнера для хранения данных
    // массив не создаем в конструкторе, получаем ссылку - внедрение
    // зависимости
    constructor(private _data: T[]) { }

    // начальная инициализация массива (заполнение в методе случайными
    // значениями)
    initialize() {
        console.log(this._data);
        for (let i = 0; i < this._data.length; ++i) {
            this._data[i].generate();
        } // for i
    } // initialize

    // вывод массива в консоль/на страницу разметки
    static showInConsole<T extends Comparable<T> & Generable<T>>(
        vector: Vector<T>, title: string = "Массив для демонстрации:") {
        console.log(title);

        // собственно вывод массива в консоль при помощи символа-итератора
        for (const item of vector) {
            console.log(item.toString());
        } // for item
    } // showInConsole

    // возвращает true, если элемент с индексом i является локальным минимумом
    private isLocMin(i: number): boolean {
        // первый и последний элементы массива не являются локальными минимумами
        if (i == 0 || i >= this._data.length - 1) return false;

        // проверка на локальный минимум, для работы операций <, <=, ==, !=, >, >=
        // неявно вызывается метод valueOf(), этот метод переопределен для
        // классов Task1.Number, Person
        let item: T = this._data[i];
        return this._data[i - 1] >= item && item <= this._data[i + 1];
    } // isLocMin

    // определение количества локальных минимумов в массиве (элементов,
    // меньших своих левого и правого соседа, первый и последний
    // элементы не могут быть локальными минимумами)
    numberLocMinimums(): number {
        let counter: number = 0;

        for (let i = 1; i < this._data.length - 2; i++) {
            if (this.isLocMin(i)) ++counter;
        } // if

        return counter;
    } // numberLocMinimums

    // упорядочение массива по возрастанию
    sort() {
        this._data.sort();
    }

    // удаление первого элемента массива
    deque(): T | undefined {
        return this._data.shift();
    } // deque

    // добавление элемента в конец массива
    enqueue(...values: T[]) {
        this._data.push(...values);
    }

    // итератор для перебора элементов вектора в цикле for .. of
    // Symbol - cредство ES6, предоставляющее уникальный идентификатор
    [Symbol.iterator]() {
        let current: number = 0;
        let data = this._data;

        // по соглашению, итератор должен возвращать объект,
        // содержащий метод next(), который возвращает объект
        // {done: boolean, value: T}
        // и обеспечивает продвижение итератора по коллекции
        return {
            next: function () {
                let obj: { done: boolean, value: T } = {done: true, value: null};

                if (current < data.length) {
                    obj = {done: false, value: data[current++]};
                } // if

                return obj;
            } // next
        }
    } // [Symbol.iterator]
} // class Vector
