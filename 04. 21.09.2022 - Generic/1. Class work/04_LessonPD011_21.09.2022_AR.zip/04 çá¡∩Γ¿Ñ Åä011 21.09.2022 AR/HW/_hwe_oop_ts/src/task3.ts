﻿/* 
* Задача 3.
*     * Создать интерфейсы и иерархию классов по следующему заданию:
*     • Интерфейс ПлоскаяФигура с методами для вычисления площади и периметра,
*       вывода в разметку и свойством для хранения изображения фигуры
*     • Класс Фигура – базовый класс иерархии
*     • Треугольник, наследует от Фигура, реализует интерфейс ПлоскаяФигура
*     • Прямоугольник, наследует от Фигура, реализует интерфейс ПлоскаяФигура
*     • Окружность, наследует от Фигура, реализует интерфейс ПлоскаяФигура
* Реализовать по три объекта каждого типа в массиве объектов c интерфейсом
* ПлоскаяФигура. Для массива выполнить:
*     • Упорядочить массив по убыванию площади
*     • Упорядочить массив по возрастанию площади
*     • Выбрать фигуры с минимальной площадью
*     • Выбрать фигуры с максимальной площадью
*
* */

// настройка события загрузки страницы на слушателя этого события
window.addEventListener('load', task3, true);

// обработчик события - вычисление по заданию
// TODO: завершить производные классы
function task3() {
    let figures: IFlatFigure[] = [
        new Triangle(1),
        new Triangle(2),
        new Triangle(3),
        new Circle(1),
        new Circle(2),
        new Circle(3),
        new Rectangle(1),
        new Rectangle(2),
        new Rectangle(3),
    ];

    console.log(figures);
} // task3

// Интерфейс и иерархия классов по заданию

// Интерфейс ПлоскаяФигура с методами для вычисления площади и периметра,
// вывода в разметку и свойством для хранения изображения фигуры
interface IFlatFigure {
    // изображение фигуры
    image: string;

    // категория фигуры
    category: string;

    // методы для вычисления площади и периметра, вывода в разметку
    area: () => number;
    perimeter: () => number;
    toHtml: () => string;
} // IFlatFigure

// Класс Фигура – базовый класс иерархии
abstract class Figure {
    constructor(protected _a: number) {  }

    get a(): number { return this._a; }
    set a(value: number) {
        this._a = value;
    }
} // class Figure

// Треугольник, наследует от Фигура, реализует интерфейс ПлоскаяФигура
class Triangle extends Figure implements IFlatFigure {
    area(): number {
        return 0;
    }

    category: string;
    image: string;

    perimeter(): number {
        return 0;
    }

    toHtml(): string {
        return "";
    }

}

// Прямоугольник, наследует от Фигура, реализует интерфейс ПлоскаяФигура
class Rectangle extends Figure implements IFlatFigure {
    area(): number {
        return 0;
    }

    category: string;
    image: string;

    perimeter(): number {
        return 0;
    }

    toHtml(): string {
        return "";
    }

}

// Окружность, наследует от Фигура, реализует интерфейс ПлоскаяФигура
class Circle extends Figure implements IFlatFigure {

    category: string;
    image: string;

    perimeter(): number {  return 2 * Math.PI*this._a; }
    area(): number { return Math.PI*this._a**2; }


    toHtml(): string {
        return "";
    }

}
