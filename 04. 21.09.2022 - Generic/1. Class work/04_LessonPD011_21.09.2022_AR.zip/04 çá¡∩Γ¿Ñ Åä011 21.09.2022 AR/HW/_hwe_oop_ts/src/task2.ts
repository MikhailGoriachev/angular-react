﻿/* 
* Задача 2.
* Создать абстрактный класс Vehicle (транспортное средство). На его основе
* реализовать классы Plane (самолет), Саг (автомобиль) и Ship (корабль).
* Классы должны иметь возможность задавать и получать координаты и параметры
* средств передвижения (цена, скорость, год выпуска) с помощью аксессоров.
* Для самолета должна быть определена высота, для самолета и корабля —
* количество пассажиров, для корабля — порт приписки.
* Значения атрибутов производных классов получать/задавать аксессорами.
* Массив транспортных средств: 2 самолета, 3 корабля, 5 автомобилей. Массив
* вывести на страницу после ее загрузки. Также ищем в массиве транспортных
* средств, выбираем и выводим на страницу по окончании ее загрузки:
*     • самое старое транспортное средство (может быть найдено больше
*       1 транспортного средства)
*     • самое быстрое транспортное средство (может быть найдено больше
*       1 транспортного средства)
*     • самое медленное транспортное средство (может быть найдено больше
*       1 транспортного средства)
*
* */

// настройка события загрузки страницы на слушателя этого события
window.addEventListener('load', task2, true);

// обработчик события - вычисление по заданию
function task2() {
    // Массив транспортных средств: 2 самолета, 3 корабля, 5 автомобилей.
    let vehicles: Vehicle[] = [
        new Plane(new Coordinates(8, 8), 23_500_000, 800, 2002,   340, 9000),
        new Plane(new Coordinates(8, 9), 24_780_000, 820, 2012,   310, 9600),
        new Ship(new Coordinates(5, 5),  63_800_000,  26, 2003, 3_500, 'Таганрог'),
        new Ship(new Coordinates(5, 6),   3_800_000,  35, 2013,   500, 'Ейск'),
        new Ship(new Coordinates(5, 7), 3_100_000,    23, 2008,   300, 'Керчь'),
        new Car(new Coordinates(1, 2), 235_000, 80, 2012),
        new Car(new Coordinates(1, 3), 245_000, 80, 2012),
        new Car(new Coordinates(3, 2), 215_000, 70, 2003),
        new Car(new Coordinates(3, 2), 235_000, 99, 2018),
        new Car(new Coordinates(1, 1), 255_000, 60, 2017)
    ];

    // вывод массива сведений о транспортных средствах
    console.log(vehicles);

    // самое старое транспортное средство (может быть найдено больше
    // 1 транспортного средства)
    let minYear = Math.min(...vehicles.map(v => v.year));
    let selected = vehicles.filter(v => v.year === minYear);
    console.log(selected);

    // самое быстрое транспортное средство (может быть найдено больше
    // 1 транспортного средства)

    // самое медленное транспортное средство (может быть найдено больше
    // 1 транспортного средства)
} // task2

// координаты  (географические) транспортного средства
class Coordinates {
    constructor(private _longitude: number, private _latitude: number) {
    }

    // аксесор долготы
    get longitude(): number { return this._longitude;}
    set longitude(value: number) { this._longitude = value; }

    // аксесор широты
    get latitude(): number { return this._latitude;}
    set latitude(value: number) { this._latitude = value; }
} // class Coordinates

// транспортное средство
// категория, координаты, цена, скорость, год выпуска
abstract class Vehicle {
    constructor(
        protected _category: string, protected _coordinates: Coordinates,
        protected _price: number,  protected _velocity: number, protected _year: number)
    { } // constructor


    get category(): string { return this._category; }
    set category(value: string) {
        this._category = value;
    }

    get coordinates(): Coordinates { return this._coordinates; }
    set coordinates(value: Coordinates) {
        this._coordinates = value;
    }

    get price(): number { return this._price; }
    set price(value: number) {
        this._price = value;
    }

    get velocity(): number { return this._velocity;    }
    set velocity(value: number) {
        this._velocity = value;
    }

    get year(): number { return this._year; }
    set year(value: number) {
        this._year = value;
    }
} // class Vehicle

// автомобиль, не добавляет никаких свойств базовому классу
class Car extends Vehicle {
    constructor(coordinates: Coordinates, price: number, velocity: number, year: number) {
        super("автомобиль", coordinates, price, velocity, year);
    } // constructor
} // class Car


// самолет, добавляются свойства: количество пассажиров, высота
class Plane extends Vehicle {
    constructor(coordinates: Coordinates, price: number, velocity: number, year: number,
                private _paxes: number, private _height: number) {
        super("самолет", coordinates, price, velocity, year);
    } // constructor


    get paxes(): number {  return this._paxes;  }
    set paxes(value: number) {
        this._paxes = value;
    }

    get height(): number {  return this._height; }
    set height(value: number) {
        this._height = value;
    }
} // class Plane


// корабль, добавляются свойства: количество пассажиров, порт приписки
class Ship extends Vehicle {
    constructor(coordinates: Coordinates, price: number, velocity: number, year: number,
                private _paxes: number, private _homePort: string) {
        super("корабль", coordinates, price, velocity, year);
    } // constructor


    get paxes(): number {  return this._paxes; }
    set paxes(value: number) {
        this._paxes = value;
    }

    get homePort(): string { return this._homePort; }
    set homePort(value: string) {
        this._homePort = value;
    }
} // class Plane

