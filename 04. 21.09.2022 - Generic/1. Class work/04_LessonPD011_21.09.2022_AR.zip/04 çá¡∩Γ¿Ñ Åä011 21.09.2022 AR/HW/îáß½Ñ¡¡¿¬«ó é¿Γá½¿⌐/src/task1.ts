﻿// Класс по заданию
class Aeroflot {
    constructor(public destination: string, public flight: string, public plane: string) {
    }
}

function initTask1() {
    // Формирование данных
    let flights = [
        new Aeroflot("Нижний Новгород", "SU 1222", "Airbus A320neo"),
        new Aeroflot("Нижний Новгород", "SU 6225", "Superjet 100"),
        new Aeroflot("Казань ", "SU 1192", "Airbus A320"),
        new Aeroflot("Тюмень", "SU 1150", "Airbus A320"),
        new Aeroflot("Ереван", "SU 1858", "Airbus A321"),
        new Aeroflot("Баку", "SU 1854", "Superjet 100"),
        new Aeroflot("Владивосток", "SU 1700", "Boeing 777-300ER"),
    ].sort((a, b) => a.flight.localeCompare(b.flight));


    // Вывод всех данных
    $("#table1").append(flights.reduce<JQuery>((acc, cur, i) =>
            acc.append($("<tr/>")
                .append($("<td/>").text(`${i + 1}`))
                .append($("<td/>").text(`${cur.destination}`))
                .append($("<td/>").text(`${cur.flight}`))
                .append($("<td/>").text(`${cur.plane}`))),
        $("<tbody/>").addClass("color-1")));


    // Список пунктов назначений
    let destinations = flights.map<string>(v => v.destination)
        .filter((v, i, arr) => i === arr.indexOf(v));
    
    destinations.push("Пермь", "Челябинск", "Ульяновск"); // Для теста отсутствующих рейсов

    // Выбор случайного пункта назначения
    let selectedDestination = destinations[getRandomInt(0, destinations.length - 1)];

    // Найденые рейсы
    let foundDestinations = flights.filter(v => v.destination === selectedDestination);

    
    $("#t2cap").text(`Пункт назначения: ${selectedDestination}`);

    let tbody: JQuery = $("<tbody/>").addClass("color-1");
    
    // Вывод данных о найденных рейсах с выбранным пнуктом назначения
    if (foundDestinations.length) {
        tbody = foundDestinations.reduce<JQuery>((acc, cur, i) =>
            acc.append($("<tr/>")
                .append($("<td/>").text(`${i + 1}`))
                .append($("<td/>").text(`${cur.flight}`))
                .append($("<td/>").text(`${cur.plane}`))), 
            tbody)
    } else {
        tbody.append($("<tr/>")
            .append($("<td/>")
                .text("Нет данных")
                .attr("colspan", "3")));
    }

    $("#table2").append(tbody);

    // Список типов самолетов
    let planes = flights.map(v => v.plane)
        .filter((v, i, arr) => i === arr.indexOf(v));

    // Случайный тип самолета
    let selectedPlane = planes[getRandomInt(0, planes.length - 1)];

    // Найденные рейса с выбранным типом самолета
    let foundPlanes = flights.filter(v => v.plane === selectedPlane);

    $("#t3cap").text(`Тип самолёта: ${selectedPlane}`);

    // Вывод данных о рейсах с выбранным типом самолета
    $("#table3").append(foundPlanes.reduce<JQuery>((acc, cur, i) =>
            acc.append($("<tr/>")
                .append($("<td/>").text(`${i + 1}`))
                .append($("<td/>").text(`${cur.flight}`))
                .append($("<td/>").text(`${cur.destination}`))),
        $("<tbody/>").addClass("color-1")));

}

$(initTask1);