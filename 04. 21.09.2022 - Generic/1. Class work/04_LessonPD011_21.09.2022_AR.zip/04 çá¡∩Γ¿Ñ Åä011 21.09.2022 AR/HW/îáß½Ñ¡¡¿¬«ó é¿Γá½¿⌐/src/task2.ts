﻿type Coord = { latitude: number, longitude: number };

// Базовый класс, описывающий транспортное средство
abstract class Vehicle {
    protected constructor(protected _category: string, protected _coordinates: Coord,
                          protected _price: number, protected _velocity: number, protected _year: number) {
    }

    get category(): string { return this._category; }
    set category(value: string) { if (value) this._category = value; }

    get coordinates(): Coord { return this._coordinates; }
    set coordinates(value: Coord) {
        if ((-180 <= value.latitude || value.latitude <= 180) &&
            (-180 <= value.longitude || value.longitude <= 180))
            this._coordinates = value;
    }

    get price(): number { return this._price; }
    set price(value: number) { if (value > 0) this._price = value; }

    get velocity(): number { return this._velocity; }
    set velocity(value: number) { if (value > 0) this._velocity = value; }

    get year(): number { return this._year; }
    set year(value: number) { if (value > 0) this._year = value; }

    toHtmlTableRow(row: number): JQuery {
        return $("<tr/>").addClass("text-end")
            .append($("<td/>").addClass("text-center").text(row))
            .append($("<td/>").addClass("text-start")
                .text(this._category))
            .append($("<td/>").text(`${this._coordinates.latitude}; ${this._coordinates.longitude}`))
            .append($("<td/>").text(this._price))
            .append($("<td/>").text(this._velocity))
            .append($("<td/>").text(this._year))
    };
}


// Класс описывающий автомобиль
class Car extends Vehicle {
    constructor(category: string, coordinates: Coord,
                price: number, velocity: number, year: number) {
        super(category, coordinates, price, velocity, year);
    }

    public toHtmlTableRow(row: number): JQuery {
        return super.toHtmlTableRow(row)
            .append($("<td/>"))
            .append($("<td/>"));
    }
}

// Класс описывающий самолет
class Plane extends Vehicle {
    constructor(category: string, coordinates: Coord,
                price: number, velocity: number, year: number, private _pax: number, private _altitude: number) {
        super(category, coordinates, price, velocity, year);
    }

    get altitude() { return this._altitude; }
    set altitude(value) { if (value > 0) this._altitude = value; }

    get pax() { return this._pax; }
    set pax(value) { if (value > 0) this._pax = value; }

    toHtmlTableRow(row: number): JQuery {
        return super.toHtmlTableRow(row)
            .append($("<td/>").text(this._pax))
            .append($("<td/>").text(this._altitude).addClass("text-center"))
    }
}

// Класс описывающий корабль
class Ship extends Vehicle {
    constructor(category: string, coordinates: Coord,
                price: number, velocity: number, year: number, private _pax: number, private _homePort: string) {
        super(category, coordinates, price, velocity, year);
    }

    get homePort() { return this._homePort; }
    set homePort(value) { this._homePort = value; }

    get pax() { return this._pax; }
    set pax(value) { if (value > 0) this._pax = value; }

    toHtmlTableRow(row: number): JQuery {
        return super.toHtmlTableRow(row)
            .append($("<td/>").text(this._pax))
            .append($("<td/>").text(this._homePort).addClass("text-center"))
    }
}

// Класс для работы с коллекцией транспортных средств
class TransportCompany {
    constructor(private vehicles: Vehicle[]) {
    }

    // Выбрать самые старые транспортные средства
    getOldest(): Vehicle[] {
        let minYear = Math.min(...this.vehicles.map(item => item.year));
        return this.vehicles.filter(item => item.year === minYear);
    }

    // Выбрать самые медленные транспортные средства
    getSlowest(): Vehicle[] {
        let minVelocity = Math.min(...this.vehicles.map(item => item.velocity));
        return this.vehicles.filter(item => item.velocity === minVelocity);
    }

    // Выбрать самые быстрые транспортные средства
    getFastest(): Vehicle[] {
        let maxVelocity = Math.max(...this.vehicles.map(item => item.velocity));
        return this.vehicles.filter(item => item.velocity === maxVelocity);
    }

    toHtmlTable(caption: string): JQuery {
        return TransportCompany.toHtmlTable(this.vehicles, caption);
    }

    static toHtmlTable(vehicles: Vehicle[], caption: string): JQuery {
        let table = $("<table/>").addClass("table table-striped w-auto caption-top mt-3 mb-5")
            .append($("<caption/>").addClass("fs-5")
                .text(caption))
            .append($("<thead/>")
                .append($("<tr/>").addClass("text-center")
                    .append($("<th/>").addClass("px-3").text("№"))
                    .append($("<th/>").addClass("px-3").text("Категория"))
                    .append($("<th/>").addClass("px-3").text("Координаты"))
                    .append($("<th/>").addClass("px-3").text("Цена, руб"))
                    .append($("<th/>").addClass("px-3").text("Скорость, км/ч"))
                    .append($("<th/>").addClass("px-3").text("Год изг."))
                    .append($("<th/>").addClass("px-3").text("Кол-во пассаж."))
                    .append($("<th/>").addClass("px-3").text("Высота полета / порт приписки"))
                )
            );
        
        let tbody = vehicles.reduce<JQuery>((acc, cur, i) =>
                acc.append(cur.toHtmlTableRow(i + 1)),
                $("<tbody/>").addClass("color-1"));
        
        return table.append(tbody);
    }
}


function initTask2() {
    let company = new TransportCompany([
        new Plane("самолет",{latitude: 23.345, longitude: -23.345}, 13_000_000, 980, 2001, 360, 12_000),
        new Plane("самолет",{latitude: 123.123, longitude: -123.199}, 38_000_000, 1180, 2017, 160, 19_000),
        new Ship("корабль",{latitude: 13.123, longitude: -13.199}, 123_000_000, 60, 1998, 460, "Новороссийск"),
        new Ship("корабль",{latitude: -93.3, longitude: -123.9}, 89_000_000, 40, 2012, 120, "Керчь"),
        new Ship("корабль", {latitude: -113.3, longitude: 90.9}, 18_000_000, 20, 1995, 20, "Новоазовск"),
        new Car("автомобиль", {latitude: -123.3, longitude: 100.9}, 30_000, 20, 2012),
        new Car("автомобиль", {latitude: 113.3, longitude: 101.9}, 3_100_000, 120, 2019),
        new Car("автомобиль", {latitude: -129.3, longitude: 1.6}, 230_000, 50, 1998),
        new Car("автомобиль", {latitude: -132.3, longitude: 22.7}, 890_000, 90, 2002),
        new Car("автомобиль", {latitude: 33.1, longitude: 89.3}, 140_980_000, 1180, 2019)
    ]);
    
    $("#list").append(company.toHtmlTable("Список транспортных средств"));
    $("#oldest").append(TransportCompany.toHtmlTable(company.getOldest(), 'Самые старые транспортные средства'));
    $("#fastest").append(TransportCompany.toHtmlTable(company.getFastest(), 'Самые быстрые транспортные средства'));
    $("#slowest").append(TransportCompany.toHtmlTable(company.getSlowest(), 'Самые медленные транспортные средства'));
    
    
    $("a[href='#oldest']").get(0)?.click();
    $("a[href='#list']").get(0)?.click();
}

$(initTask2);