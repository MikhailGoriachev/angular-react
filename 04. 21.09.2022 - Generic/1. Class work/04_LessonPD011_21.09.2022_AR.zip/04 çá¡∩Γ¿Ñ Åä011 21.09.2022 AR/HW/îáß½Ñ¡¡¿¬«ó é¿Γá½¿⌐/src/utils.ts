﻿// Генерация случайного вещественного числа
function getRandom(min: number, max: number): number {
    return Math.random() * (max - min) + min;
}

// Генерация случайного целого числа
function getRandomInt(min: number, max: number): number {
    return Math.floor(Math.random() * (max - min + 1) + min);
}

function getCoupleRandomInts(min: number, max: number): [number, number] {
    return [this.getRandomInt(min, max), this.getRandomInt(min, max)];
}

// Генерация массива вещественных значений
function createArray(size: number, min: number, max: number): number[] {
    return [...Array(size)].map(_ => this.getRandom(min, max));
}

// Генерация массива целочисленных значений
function createIntArray(size: number, min: number, max: number): number[] {
    return [...Array(size)].map(_ => this.getRandomInt(min, max));
}

