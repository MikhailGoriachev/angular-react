﻿interface FlatFigure {
    area: () => number,
    perimeter: () => number,
    toHtmlTableRow: (row: number) => JQuery,
    image: string
}

abstract class Figure {
    protected constructor(protected _sideA: number) {
    }

    abstract type: string;
}

class Rectangle extends Figure implements FlatFigure {
    constructor(sideA: number, private _sideB: number) {
        super(sideA);
    }

    type: string = "Прямоугольник";
    image: string = "rectangle.png";

    area(): number { return this._sideA * this._sideB; }
    perimeter(): number { return 2. * (this._sideA + this._sideA); }

    toHtmlTableRow(row: number): JQuery {
        return $("<tr/>")
            .append($("<td/>").text(row))
            .append($("<td/>").append($("<img>")
                .attr("src", `../images/${this.image}`)
                .attr("alt", "Изображение фигуры")))
            .append($("<td/>").text(this.type))
            .append($("<td/>").text(`${this._sideA.toFixed(2)}`))
            .append($("<td/>").text(`${this._sideB.toFixed(2)}`))
            .append($("<td/>").text('-'))
            .append($("<td/>").text(`${this.perimeter().toFixed(2)}`))
            .append($("<td/>").text(`${this.area().toFixed(2)}`));
    }
}

class Triangle extends Figure implements FlatFigure {
    constructor(sideA: number, private _sideB: number, private _sideC: number) {
        super(sideA);
    }

    type: string = "Треугольник";
    image: string = "triangle.png";

    perimeter(): number { return this._sideA + this._sideB + this._sideC; }
    area(): number {
        const p = this.perimeter() / 2;
        return Math.sqrt(p * (p - this._sideA) * (p - this._sideB) + (p - this._sideC));
    }

    toHtmlTableRow(row: number): JQuery {
        return $("<tr/>")
            .append($("<td/>").text(row))
            .append($("<td/>").append($("<img>")
                .attr("src", `../images/${this.image}`)
                .attr("alt", "Изображение фигуры")))
            .append($("<td/>").text(this.type))
            .append($("<td/>").text(`${this._sideA.toFixed(2)}`))
            .append($("<td/>").text(`${this._sideB.toFixed(2)}`))
            .append($("<td/>").text(`${this._sideC.toFixed(2)}`))
            .append($("<td/>").text(`${this.perimeter().toFixed(2)}`))
            .append($("<td/>").text(`${this.area().toFixed(2)}`));
    }

    static isTriangle(a: number, b: number, c: number): boolean {
        return a + b > c && a + c > b && b + c > a;
    }
}

class Circle extends Figure implements FlatFigure {
    constructor(radius: number) {
        super(radius);
    }

    type: string = "Окружность";
    image: string = "circle.png";

    area(): number { return Math.PI * this._sideA ** 2; }
    perimeter(): number { return 2 * Math.PI * this._sideA; }

    toHtmlTableRow(row: number): JQuery {
        return $("<tr/>")
            .append($("<td/>").text(row))
            .append($("<td/>").append($("<img>")
                .attr("src", `../images/${this.image}`)
                .attr("alt", "Изображение фигуры")))
            .append($("<td/>").text(this.type))
            .append($("<td/>").text(`${this._sideA.toFixed(2)}`))
            .append($("<td/>").text('-'))
            .append($("<td/>").text('-'))
            .append($("<td/>").text(`${this.perimeter().toFixed(2)}`))
            .append($("<td/>").text(`${this.area().toFixed(2)}`));
    }
}


function initTask3() {
    let figures: FlatFigure[] = [];

    const minValue = 1;
    const maxValue = 10;

    // Формирование данных
    
    figures.push(...[...Array(3)].map(v =>
        new Circle(getRandom(minValue, maxValue))));

    figures.push(...[...Array(3)].map(v =>
        new Rectangle(getRandom(minValue, maxValue), getRandom(minValue, maxValue))));

    figures.push(...[...Array(3)].map(v => {
        let a: number, b: number, c: number;
        do {
            a = getRandom(minValue, maxValue);
            b = getRandom(minValue, maxValue);
            c = getRandom(minValue, maxValue);
        } while (!Triangle.isTriangle(a, b, c))
        return new Triangle(a, b, c);
    }));

    const $output = $("#output");

    // Назначение обработчиков нажатий
    
    $("#list").on("click", () => {
        $output.empty();
        figures.forEach((v, i) => $output.append(v.toHtmlTableRow(i + 1)));
    });

    $("#orderArea").on("click", function () {
        $output.empty();

        // работаем с копией массива
        [...figures].sort((a, b) => b.area() - a.area())
            .forEach((v, i) => $output.append(v.toHtmlTableRow(i + 1)))
    });

    $("#orderAreaDesc").on("click", () => {
        $output.empty();
        [...figures].sort((a, b) => a.area() - b.area())
            .forEach((v, i) => $output.append(v.toHtmlTableRow(i + 1)));
    });

    $("#minArea").on("click", () => {
        $output.empty();
        const minArea = Math.min(...figures.map(v => v.area()))
        figures.filter(v => Math.abs(v.area() - minArea) < 1E-5)
            .forEach((v, i) => $output.append(v.toHtmlTableRow(i + 1)));
    });

    $("#maxArea").on("click", () => {
        $output.empty();
        const minArea = Math.max(...figures.map(v => v.area()))
        figures.filter(v => Math.abs(v.area() - minArea) < 1E-5)
            .forEach((v, i) => $output.append(v.toHtmlTableRow(i + 1)));
    });


    $("#orderArea").trigger("click");
    $output.trigger("click");
}

$(initTask3)