
//Компонент 1 - Определить количество корней квадратного уравнения.
// Пропсы: начальные значения a, b, c. 
// Стейт: a, b, c, кол-во корней. По клику на кнопку меняем стейт
class Component1 extends React.Component {

    constructor(props) {
        super(props);

        //Задание состояний
        this.state = {summ: 1, assessments: NaN, isValid: undefined};

        //Ref для полей ввода
        this.summRef = React.createRef();

        this.submitHandler = this.submitHandler.bind(this);
        this.onChangeSumm = this.onChangeSumm.bind(this);

    }

    //Валдиация
    isValid(value){
        return value >= 1 && value <=50000;
    }

    //Submit обработчик
    submitHandler (e)  {
        e.preventDefault();

        let isValidFlag = this.state.isValidPrice;

        if (!isValidFlag && isValidFlag !== undefined)
            return;

        let summVal = +this.summRef.current.value;

        this.setState({
            summ: summVal,
            assessments: getAssessments(this.props.percentage, summVal)
        });

    }

    onChangeSumm(e){
        let summVal = Number(e.target.value);

        //Изменение state
        this.setState({summ: summVal, assessments: NaN,isValid: this.isValid(summVal)})
    }


    //Формирование разметки
    render() {
        let {summ,assessments,isValid} = this.state;

        return (
            <>

                <ul className="list-group list-group-flush mb-3">
                    <li className="list-group-item">ФИО отправителя: <b>{this.props.senderSnp}</b></li>
                    <li className="list-group-item">Номер телефона отправителя: <b>{this.props.senderPhone}</b></li>
                    <li className="list-group-item">ФИО получателя: <b>{this.props.recipientSnp}</b></li>
                    <li className="list-group-item">Номер телефона получателя: <b>{this.props.recipientPhone}</b></li>
                    <li className="list-group-item">Дата и время перевода: <b>{this.props.transactionTime}</b></li>
                    <li className="list-group-item">% отчислений банку: <b>{this.props.percentage}</b></li>
                </ul>

                <form className={" mx-auto"} onSubmit={this.submitHandler}>
                    <div className={"row"}>
                        <div className={"col-8"}>
                            <label htmlFor={"input_a"} className={"mb-2"}>Введите сумму</label>

                            <input type="number" ref={this.summRef} id={"input_a"} step="any"
                                   className={`form-control ${isValid !== undefined ? (isValid ? "is-valid":"is-invalid") : ""}`}
                                   value={summ}
                                   onChange={this.onChangeSumm}
                            />
                        </div>
                    </div>
                    <div className={"my-3"}>
                        <p>
                            Сумма отчислений банку: <b>{!isNaN(assessments) ? assessments.toFixed(3) : "---"}</b>
                        </p>
                    </div>
                    <div className={"my-2"}>
                        <input className={"btn btn-outline-success"} type="submit" value="Вычислить"/>
                    </div>
                </form>
            </>)

    }


} //Component1

// Компонент 2 - Требуется вычислять нормальную массу тела человека по его росту (по формуле Лоренца):
// Масса (кг) = (Рост (см) - 100) - (Рост (см) - 150)/2.
// Вводите исходные данные в форму, выполняйте валидацию данных.
class Component2 extends React.Component {


    constructor(props) {
        super(props);

        //Задание состояний
        this.state = {mass: NaN, height: this.props.height, isValid: undefined};

        //Ref для полей ввода
        this.heightRef = React.createRef();

    }

    //Валидация
    isValid(height){
        return height > 100 && height < 231;
    }

    onChangedH = (e) =>{
        let inputVal = +e.target.value;

        //Изменение state для привязки
        this.setState({height: inputVal,isValid: this.isValid(inputVal), mass: NaN});

    }

    //Submit обработчик
    submitHandler = (e) => {
        e.preventDefault();

        let isValidFlag = this.state.isValidPrice;

        if (!isValidFlag && isValidFlag !== undefined)
            return;

        //Получение значений
        let heightVal = +this.heightRef.current.value;


        this.setState({
            height: heightVal,
            mass: getMassFromHeight(heightVal)
        });

    }

    //Формирование разметки
    render() {
        let {height,isValid,mass} = this.state;
        return (
            <>
                <form className={"mt-auto"} onSubmit={this.submitHandler}>
                    <div className={"row"}>
                        <div className={"col-9"}>
                            <label className={"mb-2"} htmlFor={"input_a"}>Введите рост</label>

                            <input type="number" ref={this.heightRef} id="input_height"
                                   className={`form-control ${isValid !== undefined ? (isValid ? "is-valid":"is-invalid"):""}`}
                                   value={height}
                                   onChange={this.onChangedH}
                            />
                        </div>
                    </div>
                    <div className={"my-3"}>
                        <p>
                            Нормальная масса человека: <b>{isNaN(mass) ? "---" : mass}</b>
                        </p>
                    </div>
                    <div className={"my-2"}>
                        <input className={"btn btn-outline-success"} type="submit" value="Вычислить"/>
                    </div>
                </form>
            </>)

    }


} //Component2

// Компонент 3 - Определить является ли простым числом число a.
// Пропсы: начальное значение a.
// Стейт: a, результат проверки. По клику на кнопку меняем стейт
class Component3 extends React.Component {

    constructor(props) {
        super(props);

        //Задание состояний
        this.state = {salary: NaN, price: 1000, isValidPrice: undefined};

        //Ref для полей ввода
        this.priceRef = React.createRef();

        this.submitHandler = this.submitHandler.bind(this);
        this.onChangePrice = this.onChangePrice.bind(this);

    }

    //Валдация
    isValid(value){
        return value > 100 && value < 1_000_000;
    }

    //Submit обработчик
    submitHandler (e)  {
        e.preventDefault();

        let isValidFlag = this.state.isValidPrice;

        if (!isValidFlag && isValidFlag !== undefined)
            return;

        let priceVal = +this.priceRef.current.value;

        this.setState({
            price: priceVal,
            salary: countSalary(priceVal,this.props.percentage)
        });

    }

    onChangePrice(e){
        let priceVal = Number(e.target.value);

        //Изменение state
        this.setState({price: priceVal, salary: NaN,isValidPrice: this.isValid(priceVal)})
    }

    //Формирование разметки
    render() {
        let {salary,price,isValidPrice} = this.state;
        return (
            <>
                <ul className="list-group list-group-flush mb-3">
                    <li className="list-group-item">ФИО врача: <b>{this.props.doctorSnp}</b></li>
                    <li className="list-group-item">Специальность врача: <b>{this.props.specialization}</b></li>
                    <li className="list-group-item">% отчислений врачу: <b>{this.props.percentage}</b></li>
                </ul>

                <form onSubmit={this.submitHandler}>
                    <div className={"row"}>
                        <div className={"col-8"}>
                            <label className={"mb-2"} htmlFor={"input_a"}>Введите значение</label>

                            <input type="number" ref={this.priceRef} id="input_a" step="any"
                                   className={`form-control col-3 ${isValidPrice !== undefined ? (isValidPrice ? "is-valid":"is-invalid") : ""}`}
                                   value={price}
                                   onChange={this.onChangePrice}
                            />
                        </div>
                    </div>
                    <div className={"my-3"}>
                        <p>
                            Заработная плата врача: <b>{!isNaN(salary) ? salary.toFixed(2) : "---"}</b>
                        </p>
                    </div>
                    <div className={"my-2"}>
                        <input className={"btn btn-outline-success"} type="submit" value="Вычислить"/>
                    </div>
                </form>
            </>)

    }


} //Component3


//region Рендеринг
function callComponent1(){

    let date = new Date();
    let minutes = date.getMinutes();
    ReactDOM.createRoot($("component1"))
        .render(
            <Component1 senderSnp={"Пелых А.О."}
                        senderPhone={"+38 071 366 653"}
                        recipientSnp={"Яковчук А.В."}
                        recipientPhone={"+38 071 435 235"}
                        transactionTime={`[${date.getDay()}.${date.getMonth()+1}.${date.getFullYear()}] ${date.getHours()}:${minutes < 10 ? "0"+ minutes : minutes}`}
                        percentage={1.2}
            />
        )
}
function callComponent2(){

    ReactDOM.createRoot($("component2"))
        .render(
            <Component2 height={getRandomInt(140, 210)}/>
        )
}
function callComponent3(){

    ReactDOM.createRoot($("component3"))
        .render(
            <Component3 doctorSnp={"Морозова Е.К."}
                        specialization={getSpecialization()}
                        percentage={getRandomInt(8,20)}
            />
        )
}

(() => {
    callComponent1();
    callComponent2();
    callComponent3();
})()
//endregion
