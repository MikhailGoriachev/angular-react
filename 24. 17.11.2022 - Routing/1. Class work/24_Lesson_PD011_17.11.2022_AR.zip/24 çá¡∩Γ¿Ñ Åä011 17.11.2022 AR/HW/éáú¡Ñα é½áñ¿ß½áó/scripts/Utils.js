//Получение элемента
$ = (id) => {
    return document.getElementById(id);
};

//Генерация значений
function getRandomDouble(lo, hi) {
    return lo + (hi-lo)*Math.random();
}
function getRandomInt(lo, hi) {
    return  Math.round(lo + (hi-lo)*Math.random());
}

function getAssessments(percentage, summ) {
    return percentage/100 * summ;
}

//Получение нормальной массы тела человека
function getMassFromHeight (height) {return (height - 100) - (height - 150)/2 }

//Определение типа числа
function countSalary(appointmentPrice, percentage, incomeTax = 0.13) {
    if (appointmentPrice < 0 || percentage > 100)
        return ;
    let salary = appointmentPrice * (percentage/100);
    return salary - salary*incomeTax;
}

//Специализации врачей
function getSpecialization() {
    let specializations = [
        "Педиатор",
        "Дерматолог",
        "Психотерапевт",
        "Невролог",
        "Иммунолог",
    ]

    return specializations[getRandomInt(0,specializations.length-1)]
}
