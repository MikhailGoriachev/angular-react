// Компонент 1
// Отображение данных о банковском переводе:
// фамилия и инициалы отправителя,
// номер телефона отправителя,
// фамилия и инициалы получателя,
// номер телефона получателя,
// дата и время перевода (момент создания компонента),
// банковские отчисления за операцию перевода (1,2% от суммы перевода).
// Вводить сумму перевода (от 1 до 50000 руб.),
// вычислять отчисления банку.

class BankTransfer {
    constructor(fullNameSender, phoneSender, fullNameRecipient,
                phoneRecipient, transferDate, percentDeduction, transferAmount) {
        this.fullNameSender = fullNameSender;
        this.phoneSender = phoneSender;
        this.fullNameRecipient = fullNameRecipient;
        this.phoneRecipient = phoneRecipient;
        this.transferDate = transferDate;
        this.percentDeduction = percentDeduction
        this.transferAmount = transferAmount;
    }
} // class BankTransfer

let bankTransfer = new BankTransfer("Митин В.П.", "+79894852494", "Павлов С.Д.", "+79494828497", "10.11.2022 12:15:37", 1.2, 1);

class Component1 extends React.Component {
    constructor(props) {
        super(props);

        // копируем пропсы в стейт
        this.state = {transferAmount: props.transferAmount,
                      isValid: this.isValidTransAmount(props.transferAmount),
                      deductions: 0};


        // создание ссылок (рефов) для полей ввода
        this.transferAmountField = React.createRef();

        this.clickSolve = this.clickSolve.bind(this);
        this.onChangeTransAmount = this.onChangeTransAmount.bind(this);
    }

    // проверка валидности поля
    isValidTransAmount(n) { return n >= 1 && n < 50000; }


    // вычисляем отчисления банку
    getDeductions(transferAmount) {
        return transferAmount * 1.2/100;
    }


    // обработчик изменения поля ввода
    onChangeTransAmount(e) {
        let val = +e.target.value;
        let valid = this.isValidTransAmount(val);

        this.setState({transferAmount: val, isValid: valid, deductions: 0});
    } // onChangeTransAmount


    // клик по кнопке для решения задачи
    clickSolve(e) {
        e.preventDefault();
        if (!this.state.isValid) return;

        let transferAmount = +this.transferAmountField.current.value;

        this.setState({transferAmount: transferAmount, deductions: this.getDeductions(transferAmount)});
    } // clickSolve

    render() {
        return<>
            <div className="card h-34rem w-35rem">
                <div className="card-header">
                    <h5 className="text-center">Компонент 1</h5>
                </div>
                <ul className="list-group list-group-flush">
                    <li className="list-group-item">ФИО отправителя: <b>{this.props.fullNameSender}</b></li>
                    <li className="list-group-item">Номер тел. отправителя: <b>{this.props.phoneSender}</b></li>
                    <li className="list-group-item">ФИО получателя: <b>{this.props.fullNameRecipient}</b></li>
                    <li className="list-group-item">Номер тел. получателя: <b>{this.props.phoneRecipient}</b></li>
                    <li className="list-group-item">Дата и время перевода: <b>{this.props.transferDate}</b></li>
                    <li className="list-group-item">Банковские отчисления за перевод(%): <b>{this.props.percentDeduction}%</b></li>
                    <li className="list-group-item">Сумма перевода: <b>{this.state.transferAmount} ₽</b></li>
                    <li className="list-group-item">Отчисления банку: <b> {this.state.deductions } ₽</b></li>
                </ul>
                <div className="card-footer text-center">
                    <form className="form-group" onSubmit={this.clickSolve}>
                        <label>Введите сумму перевода: <input type="number" ref={this.transferAmountField} placeholder="перевод от 1...50000"
                                                              onChange={this.onChangeTransAmount}
                                                              className={`form-control ${this.state.isValid?' ':'is-invalid'}`} min={0}/></label><br/><br/>
                        <div className="text-center">
                            <button className="btn btn-outline-primary w-10rem" type="submit">Вычислить</button>
                        </div>
                    </form>
                </div>
            </div>
        </>
    }

} // class Component1



// Компонент 2.
// Требуется вычислять нормальную массу тела
// человека по его росту (по формуле Лоренца):
// Масса (кг) = (Рост (см) - 100) - (Рост (см) - 150)/2.
class BodyMassIndex extends React.Component {
    constructor(props) {
        super(props);

        // копируем пропсы в стейт
        this.state = {growth: props.growth, isValid: this.isValidGrowth(props.growth), weight: this.formulaLorenza(props.growth)};

        // создание ссылки на поле ввода
        this.growth = React.createRef();

        this.clickSolve = this.clickSolve.bind(this);
        this.onChangeGrowth = this.onChangeGrowth.bind(this);
    } // constructor

    // проверка валидности поля
    isValidGrowth(g) { return g > 0.7 && g < 500; }

    // обработчик изменения поля ввода
    onChangeGrowth(e) {
        let val = +e.target.value;
        let valid = this.isValidGrowth(val);

        this.setState({growth: val, isValid: valid, weight: Number.NaN});
    } // onChangeGrowth

    // вычисление по формуле Лоренца
    formulaLorenza(growth){
        return (growth - 100) - (growth - 150) / 2;
    }

    // клик по кнопке для решения задачи
    clickSolve(e) {
        e.preventDefault();

        if (!this.state.isValid) return;

        // получение числа из поля ввода формы
        let growth = +this.growth.current.value;

        this.setState({growth: growth, weight: this.formulaLorenza(growth)});
    } // clickSolve

    render() {
        // для упрощения доступа к полю состояния
        let isValid = this.state.isValid;

        return<>
            <div className="card h-18rem w-35rem">
                <div className="card-header">
                    <h5 className="text-center">Компонент 2</h5>
                </div>
                <ul className="list-group list-group-flush">
                    <li className="list-group-item" >Рост: <b>{this.state.growth}</b></li>
                    <li className="list-group-item">Индекс массы тела: <b>{Number.isNaN(this.state.weight)?"":this.state.weight}</b></li>
                </ul>
                <div className="card-footer text-center">
                    <form className="form-group" onSubmit={this.clickSolve} >
                        <label>Введите рост в сантиметрах:
                            <input type="number" ref={this.growth}
                                   onChange={this.onChangeGrowth} className={`form-control ${isValid?'':'is-invalid'}`} min={0}/>
                        </label>
                        <br/><br/>
                        <div className="text-center">
                            <button className="btn btn-outline-primary w-10rem" type="submit">Вычислить</button>
                        </div>
                    </form>
                </div>
            </div>
        </>

    }
} // class BodyMassIndex


// Компонент 3
// За каждый прием врачу отчисляется фиксированный процент от стоимости приема.
// Фамилия и инициалы врача,
// его специальность и процент отчисления
// задаются атрибутами при создании компонента.
// Размер начисляемой врачу заработной платы за каждый прием вычисляется по формуле:
// Стоимость приема * Процент отчисления от стоимости приема на зарплату врача.
// Из этой суммы вычитается подоходный налог, составляющий 13% от суммы.
// Вводите стоимость приема (с валидацией),
// выводите сумму к выдаче заработной платы врача за прием.
class Polyclinic {
    constructor(fullName, speciality, percent, price) {
        this.fullName = fullName;
        this.speciality = speciality;
        this.percent = percent;
        this.price = price;
    }
} // class Polyclinic

let polyclinic = new Polyclinic("Калиниченко С.Р.", "травматолог", 3, 0);

class Component3 extends React.Component{
    constructor(props) {
        super(props);

        // копируем пропсы в стейт
        this.state = {price: props.price, percent: props.percent, isValid: this.isValidPrice(props.price), salary: 0};

        // создание ссылок (рефов) для полей ввода
        this.priceField = React.createRef();

        this.clickSolve = this.clickSolve.bind(this);
        this.onChangePrice = this.onChangePrice.bind(this);
    }


    // проверка валидности поля
    isValidPrice(p) { return p >= 0; }


    // размер начисляемой врачу заработной платы за каждый прием
    getSalary(price, percent) {
        return 0.87 * (price * percent) / 100;
    }


    // обработчик изменения поля ввода
    onChangePrice(e) {
        let val = +e.target.value;
        let valid = this.isValidPrice(val);

        this.setState({price: val, isValid: valid, salary: 0});
    } // onChangePrice


    // клик по кнопке для решения задачи
    clickSolve(e) {
        e.preventDefault();
        if (!this.state.isValid) return;

        let price = +this.priceField.current.value;

        this.setState({price: price, salary: this.getSalary(price, this.props.percent)});
    } // clickSolve

    render() {
        return<>
            <div className="card h-25rem w-35rem">
                <div className="card-header">
                    <h5 className="text-center">Компонент 3</h5>
                </div>
                <ul className="list-group list-group-flush">
                    <li className="list-group-item">ФИО врача: <b>{this.props.fullName}</b></li>
                    <li className="list-group-item">Специальность: <b>{this.props.speciality}</b></li>
                    <li className="list-group-item">Процент отчисления(%): <b>{this.props.percent}%</b></li>
                    <li className="list-group-item">Стоимость приема: <b>{this.state.price} ₽</b></li>
                    <li className="list-group-item">Заработная плата: <b> {this.state.salary} ₽</b></li>
                </ul>
                <div className="card-footer text-center">
                    <form className="form-group" onSubmit={this.clickSolve}>
                        <label>Введите стоимость приема: <input type="number" ref={this.priceField}
                                                              onChange={this.onChangePrice}
                                                              className={`form-control ${this.state.isValid?' ':'is-invalid'}`} min={0}/></label><br/><br/>
                        <div className="text-center">
                            <button className="btn btn-outline-primary w-10rem" type="submit">Вычислить</button>
                        </div>
                    </form>
                </div>
            </div>
        </>
    }

} // class Component3


// вывод компонентов
ReactDOM.createRoot(document.getElementById("app"))
    .render(
        <div className="row p-5">
            <h5 className="text-center">Отображение данных о банковском переводе</h5>
            <Component1 fullNameSender={bankTransfer.fullNameSender} phoneSender={bankTransfer.phoneSender}
                        fullNameRecipient={bankTransfer.fullNameRecipient} phoneRecipient={bankTransfer.phoneRecipient}
                        transferDate={bankTransfer.transferDate} percentDeduction={bankTransfer.percentDeduction} transferAmount={bankTransfer.transferAmount}/>
            <br/>
            <h5 className="text-center mt-4">Вычислить нормальную массу тела человека по его росту</h5>
            <BodyMassIndex/>
            <br/>
            <h5 className="text-center mt-4">Отображение данных о банковском переводе</h5>
            <Component3 fullName={polyclinic.fullName} speciality={polyclinic.speciality} percent={polyclinic.percent} price={polyclinic.price}/>
        </div>
    );
