import React from "react";
import { Button, Col, FloatingLabel, Form, FormControl, ListGroup, Row } from "react-bootstrap";
import { Formik } from "formik";
import * as Yup from 'yup';

export class Component3 extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            salary: "",
            admissionPrice: ""
        }
        this.tax = 13;
    }

    handleSubmit = (values) => {
        let salary = (values.admissionPrice * this.props.doctor.interest / 100) * (1 - this.tax / 100);
        this.setState({ admissionPrice: values.admissionPrice, salary });
    };

    validationSchema = Yup.object({
        admissionPrice: Yup.number()
            .required("Обязательно для заполнения")
            .integer("Должно быть целым числом")
            .moreThan(0, "Стоимость приёма должна быть больше нуля")
    });

    render() {
        return <div className="bordered px-3 py-2">
            <Row className="mb-3">
                <Col md="12">
                    <div className="lead text-nowrap fs-4 ps-3">Расчет з/п за приём:</div>
                </Col>
            </Row>
            <ListGroup variant="flush">
                <ListGroup.Item><span className="color-gray">Фамилия И.О:</span> {this.props.doctor.name}</ListGroup.Item>
                <ListGroup.Item><span className="color-gray">Специальность:</span> {this.props.doctor.speciality}</ListGroup.Item>
                <ListGroup.Item><span className="color-gray">Отчисления:</span> {this.props.doctor.interest}%</ListGroup.Item>
            </ListGroup>
            <Formik
                initialValues={{ admissionPrice: "" }}
                validationSchema={this.validationSchema}
                onSubmit={this.handleSubmit}
            >
                {(formik) => (
                    <Form noValidate
                          className="mt-2"
                          onSubmit={formik.handleSubmit}>
                        <Row className="my-3 ps-3">
                            <Col md="7">
                                <FloatingLabel label="Стоимость приёма, ₽:">
                                    <FormControl className="text-end"
                                                 type="number"
                                                 step="1"
                                                 name="admissionPrice"
                                                 value={formik.values.admissionPrice}
                                                 onChange={e => {
                                                     formik.setFieldTouched('admissionPrice')
                                                     formik.handleChange(e);
                                                 }}
                                                 isInvalid={formik.touched.admissionPrice && !!formik.errors.admissionPrice}/>
                                    <Form.Control.Feedback type="invalid">
                                        {formik.errors.admissionPrice}
                                    </Form.Control.Feedback>
                                </FloatingLabel>
                            </Col>
                            <Col md="5">
                                <Button variant="outline-secondary" type="submit">Рассчитать</Button>
                            </Col>
                        </Row>
                    </Form>
                )}
            </Formik>

            {this.state.salary &&
                <ListGroup className="my-3" variant="flush">
                    <ListGroup.Item><span className="color-gray">Стоимость приёма:</span> {this.state.admissionPrice}₽</ListGroup.Item>
                    <ListGroup.Item><span className="color-gray">Начисляемая з/п:</span> {Math.floor(this.state.salary)}₽</ListGroup.Item>
                </ListGroup>}
        </div>
    }
}