import React, { useEffect } from "react";
import { Button, Col, FloatingLabel, Form, FormControl, ListGroup, Modal, Row } from "react-bootstrap";
import { Formik, useField, useFormikContext } from "formik";
import * as Yup from "yup";

export class Component1 extends React.Component {
    constructor(props) {
        super(props);
        this.state = { showResultModal: false }
        this.minTransfer = 1;
        this.maxTransfer = 50000;
    }

    showResultModal = () => this.setState({ showResultModal: true })

    closeResultModal = formik => {
        this.setState({ showResultModal: false });
        formik.resetForm();
    }

    render() {
        return <Formik
            initialValues={{
                sender: this.props.sender,
                recipient: this.props.recipient,
                dateTime: new Date(),
                commissionPercent: this.props.commissionPercent,
                transferAmount: "",
                bankCharge: ""
            }}
            validationSchema={Yup.object({
                    transferAmount: Yup.number()
                        .required("Обязательное поле")
                        .integer("Должно быть целым числом")
                        .min(this.minTransfer, `Минимальная сумма перевода: ${this.minTransfer}₽`)
                        .max(this.maxTransfer, `Максимальная сумма перевода: ${this.maxTransfer}₽`)
                })}
            onSubmit={this.showResultModal}
        >
            {(formik) => (
                <Form noValidate
                      className="mx-4 bordered px-4 pb-2 pt-3"
                      onSubmit={formik.handleSubmit}>
                    <fieldset title="Компонент 1">
                        <Row className="mb-3">
                            <Col md="12">
                                <div className="lead text-nowrap fs-4">Денежный перевод:</div>
                            </Col>
                        </Row>
                        <Row className="mb-2">
                            <Col md="6">
                                <FloatingLabel label="Отправитель:">
                                    <FormControl name="sender.name"
                                                 value={formik.values.sender.name}
                                                 disabled/>
                                </FloatingLabel>
                            </Col>
                            <Col md="6">
                                <FloatingLabel label="Тел.:">
                                    <FormControl name="sender.phone"
                                                 value={formik.values.sender.phone}
                                                 disabled/>
                                </FloatingLabel>
                            </Col>
                        </Row>
                        <Row className="mb-2">
                            <Col md="6">
                                <FloatingLabel label="Получатель:">
                                    <FormControl name="recipient.name"
                                                 value={formik.values.recipient.name}
                                                 disabled/>
                                </FloatingLabel>
                            </Col>
                            <Col md="6">
                                <FloatingLabel label="Тел.:">
                                    <FormControl name="recipient.phone"
                                                 value={formik.values.recipient.phone}
                                                 disabled/>
                                </FloatingLabel>
                            </Col>
                        </Row>
                        <Row className="mb-2">
                            <Col md="6">
                                <FloatingLabel label="Сумма перевода, ₽:">
                                    <FormControl className="text-end"
                                                 type="number"
                                                 name="transferAmount"
                                                 value={formik.values.transferAmount}
                                                 onChange={e => {
                                                     formik.setFieldTouched('transferAmount')
                                                     formik.handleChange(e);
                                                 }}
                                                 isInvalid={formik.touched.transferAmount && !!formik.errors.transferAmount}/>
                                    <Form.Control.Feedback type="invalid">
                                        {formik.errors.transferAmount}
                                    </Form.Control.Feedback>
                                </FloatingLabel>
                            </Col>
                            <Col md="6">
                                <BankChargeField name="bankCharge" min={this.minTransfer} max={this.maxTransfer}></BankChargeField>
                            </Col>
                        </Row>
                        <Row className="my-3 justify-content-end">
                            <Col md="auto">
                                <Button variant="outline-secondary" type="submit">Перевести</Button>
                            </Col>
                        </Row>
                    </fieldset>

                    <TransferResultModal
                        show={this.state.showResultModal}
                        handleClose={() => this.closeResultModal(formik)}
                        recipient={formik.values.recipient.name}
                        sender={formik.values.sender.name}
                        bankCharge={formik.values.bankCharge}
                        transferAmount={formik.values.transferAmount}
                        dateTime={formik.values.dateTime}
                    />
                </Form>
            )}
        </Formik>;
    }
}

// Компонент зависимого поля отчислений банку
const BankChargeField = (props) => {
    const {
        values: { transferAmount, commissionPercent },
        setFieldValue
    } = useFormikContext();

    const [field] = useField(props);

    useEffect(() => {
        const value = transferAmount >= props.min && transferAmount <= props.max
            ? Math.ceil(transferAmount / 100 * commissionPercent)
            : ""
        setFieldValue(props.name, value);
    }, [transferAmount, commissionPercent, setFieldValue, props.name, props.max, props.min]);

    return (
        <FloatingLabel label={`Комиссия, ₽ (${commissionPercent}%):`}>
            <FormControl className="text-end" type="number" readOnly {...props} {...field} />
        </FloatingLabel>);
};

// Компонент с контентом модального окна
const TransferResultModal = ({ show, handleClose, sender, recipient, transferAmount, bankCharge, dateTime }) => {
    if (!show) {
        return null;
    }
    return (<>
            <Modal show={show}
                   backdrop="static"
                   keyboard={false}
                   centered
                   onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title className="color-gray">Перевод средств</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <ListGroup>
                        <ListGroup.Item><b>Отправитель: </b>{sender}</ListGroup.Item>
                        <ListGroup.Item><b>Получатель: </b>{recipient}</ListGroup.Item>
                        <ListGroup.Item><b>Сумма перевода: </b>{transferAmount}₽</ListGroup.Item>
                        <ListGroup.Item><b>Комиссия: </b>{bankCharge}₽</ListGroup.Item>
                        <ListGroup.Item><b>Время операции: </b>{dateTime.toLocaleDateString()} {dateTime.toLocaleTimeString()}
                        </ListGroup.Item>
                    </ListGroup>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        Закрыть
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
};
