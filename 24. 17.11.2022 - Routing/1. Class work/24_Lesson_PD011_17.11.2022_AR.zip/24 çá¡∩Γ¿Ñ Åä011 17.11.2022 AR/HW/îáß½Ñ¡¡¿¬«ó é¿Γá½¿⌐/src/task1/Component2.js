import React from "react";
import { Col, FloatingLabel, Form, FormControl, Row } from "react-bootstrap";

export class Component2 extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            height: "",
            mass: "",
            error: ""
        }
    }

    handleChange = (e) => {
        let error = "", mass = "";

        if (e.target.value.length) {
            const value = Number(e.target.value);
            if (value <= 50) {
                error = "Допустимое значение - более 50";
            } else {
                mass = (value - 100) - (value - 150) / 2;
            }
        }

        this.setState({ height: e.target.value, mass, error });
    }

    render() {
        return <>
            <Form noValidate
                  className="mx-4 bordered px-4 pt-3 pb-4">
                <fieldset title="Компонент 1">
                    <Row className="mb-3">
                        <Col md="12">
                            <div className="lead text-nowrap fs-4">Определение массы тела по формуле Лоренца:</div>
                        </Col>
                    </Row>
                    <Row className="mb-2">
                        <Col md="6">
                            <FloatingLabel label="Рост, см:">
                                <FormControl className="text-end"
                                             type="number"
                                             name="height"
                                             value={this.state.height}
                                             onChange={this.handleChange}
                                             isInvalid={!!this.state.error}/>
                                <Form.Control.Feedback type="invalid">
                                    {this.state.error}
                                </Form.Control.Feedback>
                            </FloatingLabel>
                        </Col>
                        <Col md="6">
                            <FloatingLabel label="Масса, кг:">
                                <FormControl className="text-end"
                                             type="number"
                                             name="mass"
                                             readOnly
                                             value={this.state.mass}/>
                            </FloatingLabel>
                        </Col>
                    </Row>
                </fieldset>
            </Form>
        </>
    }
}