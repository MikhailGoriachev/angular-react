import { Accordion, Col, Row } from "react-bootstrap";
import { Component1 } from "./Component1";
import { Component2 } from "./Component2";
import { Component3 } from "./Component3";

const sender = {
    name: "Петров А.И",
    phone: "+37493254787"
};

const recipient = {
    name: "Лавров С.В",
    phone: "+37495226755"
};

const commissionPercent = 1.2;

const doctor = {
    name: "Попов И.А.",
    speciality: "Терапевт",
    interest: 20
}

export function Task1() {
    return (
        <Row className="justify-content-center">
            <Col md="8">
                <Accordion defaultActiveKey="0">
                    {[
                        <Component1 sender={sender} recipient={recipient} commissionPercent={commissionPercent}/>,
                        <Component2/>,
                        <Component3 doctor={doctor}/>
                    ].map((item, idx) =>
                        <Accordion.Item eventKey={idx} key={idx}>
                            <Accordion.Header>Компонент {idx + 1}</Accordion.Header>
                            <Accordion.Body as={Row} className="py-4 justify-content-center">
                                <Col md={"auto"}>
                                    {item}
                                </Col>
                            </Accordion.Body>
                        </Accordion.Item>
                    )}
                </Accordion>
            </Col>
        </Row>
    );
}