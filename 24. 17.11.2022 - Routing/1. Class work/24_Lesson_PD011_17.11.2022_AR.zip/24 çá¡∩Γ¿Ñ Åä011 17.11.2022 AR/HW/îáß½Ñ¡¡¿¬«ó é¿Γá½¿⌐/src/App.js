import { Container, Tabs } from "react-bootstrap";
import Tab from 'react-bootstrap/Tab';
import { Footer } from "./shared/Footer";
import { Header } from "./shared/Header";
import { Task } from "./home/Task";
import { Task1 } from "./task1/Task1";
import { useState } from "react";

const titles = {
    home: "Главная",
    task1: "Задача 1",
    task2: "Задача 2"
};

function App() {
    const [title, setTitle] = useState("Главная");

    return (
        <>
            <Header title={title}/>
            <Container className="mh-80-vh mt-4 px-5" fluid>
                <Tabs defaultActiveKey="home" onSelect={(key) => setTitle(titles[key])} className="mb-3">
                    <Tab eventKey="home" title="Главная">
                        <Task/>
                    </Tab>
                    <Tab eventKey="task1" title="Задача 1">
                        <Task1/>
                    </Tab>
                </Tabs>
            </Container>
            <Footer/>
        </>
    );
}

export default App;
